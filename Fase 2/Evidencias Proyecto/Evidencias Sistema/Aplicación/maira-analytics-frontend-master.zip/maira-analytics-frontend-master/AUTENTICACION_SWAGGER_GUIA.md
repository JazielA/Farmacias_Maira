# 🔐 Guía de Autenticación - Swagger API Docs

## ❓ Problema Identificado

**Pregunta del usuario:**

> "Cuando quiero probar el endpoint de login no funciona. La ruta en Swagger es `/auth/login` pero cuando inicio sesión entro en esta ruta `http://localhost:3000/login`"

## ✅ Explicación

Tu aplicación **NO tiene un endpoint `/api/auth/login`** porque la autenticación se maneja de manera diferente:

### 🏗️ Arquitectura de Autenticación

```
┌─────────────────────────────────────────────────────────────┐
│                    FLUJO DE AUTENTICACIÓN                    │
└─────────────────────────────────────────────────────────────┘

1. Usuario accede a: http://localhost:3000/login
   └─> Página Next.js (src/app/login/page.tsx)

2. Usuario ingresa credenciales
   └─> Email: admin@example.com
   └─> Password: password123

3. Click en "Iniciar Sesión"
   └─> Se ejecuta signIn() del AuthContext
   └─> Llama a supabase.auth.signInWithPassword()
   └─> ⚠️ NO hay llamada a /api/auth/login

4. Supabase Auth procesa el login
   └─> Valida credenciales contra Supabase Auth
   └─> Genera JWT token
   └─> Crea sesión en cookies

5. Redirección exitosa
   └─> Router.push("/")
   └─> Usuario autenticado
```

### 🔄 Comparación: Supabase Auth vs API Tradicional

| Aspecto            | Tu App (Supabase Auth)               | API Tradicional               |
| ------------------ | ------------------------------------ | ----------------------------- |
| **Endpoint Login** | ❌ No existe `/api/auth/login`       | ✅ `POST /api/auth/login`     |
| **Manejo**         | Cliente → Supabase Auth directamente | Cliente → API → Base de datos |
| **Tokens**         | JWT generado por Supabase            | JWT generado por tu backend   |
| **Sesiones**       | Manejadas por Supabase               | Manejadas por tu aplicación   |
| **Cookies**        | Automáticas (Supabase)               | Manuales (tu código)          |

---

## 📝 Cambios Realizados en Swagger

### 1. **Actualización de la Descripción**

Se agregó una nota clara en la descripción de la API:

```yaml
description: |
  ⚠️ IMPORTANTE - Autenticación:
  - El login NO se realiza mediante un endpoint de esta API
  - La autenticación se maneja directamente con Supabase Auth
  - Para probar endpoints protegidos:
    1. Inicia sesión en: http://localhost:3000/login
    2. Usa: admin@example.com / password123
    3. Copia el token desde las cookies
    4. Haz clic en "Authorize" 🔓
```

### 2. **Eliminado Endpoint Falso**

❌ **ANTES** (Incorrecto):

```yaml
paths:
  /auth/login:  # ⚠️ Este endpoint NO existe
    post:
      summary: Iniciar sesión
      ...
```

✅ **AHORA** (Correcto):

```yaml
paths:
  /auth/logout:  # ✅ Este SÍ existe
    post:
      summary: Cerrar sesión y limpiar caché
      ...

  /user/permissions:  # ✅ Este SÍ existe
    get:
      summary: Obtener permisos del usuario
      ...

  /users/sync:  # ✅ Este SÍ existe
    post:
      summary: Sincronizar usuario con BD
      ...
```

### 3. **Agregados Endpoints Reales**

Nuevos endpoints documentados:

#### `/api/auth/logout` (POST)

- Limpia el caché de permisos
- Requiere autenticación
- Retorna confirmación

#### `/api/user/permissions` (GET)

- Obtiene permisos del usuario autenticado
- Retorna: permissions[], role, user
- Usa caché optimizado

#### `/api/users/sync` (POST)

- Sincroniza usuario de Supabase con Prisma
- Crea/actualiza registro en BD
- Requiere ID y email

---

## 🧪 Cómo Probar los Endpoints en Swagger

### Paso 1: Obtener Token de Autenticación

**Opción A - Desde el Navegador:**

1. Abre: `http://localhost:3000/login`
2. Inicia sesión con:
   - Email: `admin@example.com`
   - Password: `password123`
3. Abre DevTools (F12)
4. Ve a: **Application** → **Cookies** → `localhost`
5. Busca la cookie: `sb-access-token` o similar
6. **Copia el valor** del token

**Opción B - Desde la Consola:**

```javascript
// En la consola del navegador (después de hacer login)
document.cookie
  .split("; ")
  .find((row) => row.startsWith("sb-"))
  ?.split("=")[1];
```

### Paso 2: Autorizar en Swagger

1. Ve a: `http://localhost:3000/docs`
2. Haz clic en el botón **"Authorize"** 🔓 (arriba a la derecha)
3. En el campo "Value" pega: `Bearer TU_TOKEN_AQUI`
4. Haz clic en **"Authorize"**
5. Cierra el modal

### Paso 3: Probar Endpoints

Ahora todos los endpoints con el candado 🔒 están autorizados:

**Ejemplo - Probar `/api/user/permissions`:**

1. Expande el endpoint `GET /user/permissions`
2. Haz clic en **"Try it out"**
3. Haz clic en **"Execute"**
4. Verás la respuesta:

```json
{
  "permissions": [
    {
      "id": "perm-123",
      "name": "view:dashboard",
      "resource": "dashboard",
      "action": "view"
    }
  ],
  "role": {
    "id": "role-admin",
    "name": "Admin",
    "description": "Administrador del sistema"
  },
  "user": {
    "id": "user-456",
    "email": "admin@example.com"
  }
}
```

---

## 🔍 Endpoints Disponibles vs No Disponibles

### ❌ Endpoints que NO Existen

| Ruta                      | Razón                                     |
| ------------------------- | ----------------------------------------- |
| `POST /api/auth/login`    | Login se hace vía Supabase Auth (cliente) |
| `POST /api/auth/register` | Registro se hace vía Supabase Auth        |
| `POST /api/auth/refresh`  | Refresh automático por Supabase           |

### ✅ Endpoints que SÍ Existen

| Ruta                    | Método         | Descripción                  |
| ----------------------- | -------------- | ---------------------------- |
| `/api/auth/logout`      | POST           | Limpia caché de permisos     |
| `/api/user/permissions` | GET            | Obtiene permisos del usuario |
| `/api/users/sync`       | POST           | Sincroniza usuario con BD    |
| `/api/providers`        | GET            | Lista proveedores            |
| `/api/providers`        | POST           | Crea proveedor               |
| `/api/providers/{id}`   | GET/PUT/DELETE | CRUD de proveedor            |
| `/api/messages/inbox`   | GET            | Mensajes recibidos           |
| `/api/messages/send`    | POST           | Enviar mensaje               |
| Y más...                |                | Ver docs completas           |

---

## 🎯 Resumen

### ¿Por qué no funciona `/auth/login` en Swagger?

**Respuesta corta:**
Porque ese endpoint **no existe**. Tu app usa **Supabase Auth** directamente desde el cliente.

### ¿Cómo se autentica entonces?

1. **Frontend** → Llama a `supabase.auth.signInWithPassword()`
2. **Supabase** → Valida y genera JWT
3. **Cookie** → Se guarda automáticamente
4. **API Routes** → Usan el token de la cookie para autenticar

### ¿Qué endpoints SÍ puedo probar?

Todos los que aparecen en Swagger AHORA son reales y funcionales:

- ✅ `/api/auth/logout`
- ✅ `/api/user/permissions`
- ✅ `/api/users/sync`
- ✅ `/api/providers/*`
- ✅ `/api/messages/*`
- ✅ `/api/dashboard/*`
- ✅ Y más...

---

## 📚 Archivos Relacionados

### Código de Autenticación

- **Login Page:** `src/app/login/page.tsx`
- **Auth Context:** `src/contexts/AuthContext.tsx`
- **Supabase Client:** `src/lib/supabase/server.ts` y `client.ts`
- **Middleware:** `middleware.ts` (protege rutas)

### Endpoints Reales

- **Logout:** `src/app/api/auth/logout/route.ts`
- **Permissions:** `src/app/api/user/permissions/route.ts`
- **Sync:** `src/app/api/users/sync/route.ts`

### Documentación

- **Swagger Docs:** `src/app/docs/page.tsx`
- **Esta Guía:** `AUTENTICACION_SWAGGER_GUIA.md`

---

## 🚀 Próximos Pasos

### 1. Entender el Flujo

Lee el código en:

- `src/app/login/page.tsx` - Ver cómo se hace login
- `src/contexts/AuthContext.tsx` - Ver el contexto de auth

### 2. Probar Endpoints Reales

Usa Swagger UI en `/docs` para probar los endpoints reales.

### 3. Agregar Nuevos Endpoints

Si necesitas crear un endpoint de login personalizado:

```typescript
// src/app/api/auth/custom-login/route.ts
import { NextRequest, NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";

export async function POST(request: NextRequest) {
  const { email, password } = await request.json();

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 401 });
  }

  return NextResponse.json({ user: data.user, session: data.session });
}
```

Pero **NO es necesario** porque Supabase ya lo maneja.

---

## ✅ Conclusión

**El problema está resuelto:**

1. ✅ Eliminado endpoint falso `/auth/login`
2. ✅ Agregada documentación clara sobre Supabase Auth
3. ✅ Agregados endpoints reales (`/auth/logout`, `/user/permissions`, `/users/sync`)
4. ✅ Instrucciones claras para obtener y usar el token
5. ✅ Documentación completa del flujo de autenticación

**Ya puedes:**

- ✅ Entender cómo funciona la autenticación
- ✅ Probar los endpoints reales en Swagger
- ✅ Obtener el token de autenticación
- ✅ Hacer requests autenticadas

---

**¿Tienes dudas?** Revisa esta guía o el código fuente en los archivos mencionados.
