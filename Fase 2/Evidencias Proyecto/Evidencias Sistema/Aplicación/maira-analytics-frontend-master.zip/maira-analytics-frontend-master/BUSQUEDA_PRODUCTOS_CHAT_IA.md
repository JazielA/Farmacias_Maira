# 🎯 Búsqueda de Productos con Comparación de Precios - Chat IA

## ✅ Implementación Completada

Se ha implementado la funcionalidad para que el chat con IA responda con comparaciones de precios cuando el usuario ingrese el nombre de un producto.

---

## 🚀 Cómo Funciona

### 1. **Usuario escribe nombre de producto en el chat**

Ejemplos:

- "AMLODIPINO"
- "ENALAPRIL 20MG"
- "(BE) LOSARTAN"
- "METFORMINA"

### 2. **Sistema busca automáticamente en la base de datos**

- Búsqueda **case-insensitive** (mayúsculas/minúsculas no importan)
- Búsqueda **parcial** (encuentra "AMLODIPINO 10MG" al escribir solo "AMLODIPINO")
- Obtiene precios de **todos los proveedores activos**
- Ordena resultados del **más barato al más caro**

### 3. **Chat IA responde con comparación detallada**

```
📦 (BE) AMLODIPINO 10MG X 30 COMP.

🔍 Comparación de Precios entre Proveedores:

1. Mediven 🏆 MEJOR PRECIO
   💰 Precio: $497

2. Ethon ⚠️ MÁS CARO
   💰 Precio: $588
   📈 $91 más caro (18.3%)

3. Agrosuper
   💰 Precio: $620
   📈 $123 más caro (24.7%)

📊 Estadísticas:
• Precio más bajo: $497 (Mediven)
• Precio más alto: $620 (Agrosuper)
• Precio promedio: $568
• Diferencia máxima: $123 (24.7%)

💡 Recomendación: Para obtener el mejor precio, compra este producto
a Mediven. Ahorrarás hasta $123 por unidad comparado con Agrosuper.
```

---

## 📋 Archivos Creados/Modificados

### 1. **Nuevo Endpoint de Backend**

📁 `/src/app/api/providers/search-product/route.ts`

**Funcionalidad:**

- Recibe nombre de producto
- Busca en tabla `products` con búsqueda parcial
- Obtiene precios de tabla `provider_prices`
- Une con tabla `providers` (solo activos)
- Calcula estadísticas y diferencias
- Ordena por precio ascendente
- Identifica mejor y peor precio

**Request:**

```typescript
POST /api/providers/search-product
{
  "productName": "AMLODIPINO"
}
```

**Response:**

```typescript
{
  "success": true,
  "data": {
    "found": true,
    "exactMatch": true,
    "product": {
      "productName": "(BE) AMLODIPINO 10MG X 30 COMP.",
      "pricesCount": 3,
      "comparison": [
        {
          "provider": "Mediven",
          "price": 497,
          "differenceFromCheapest": 0,
          "percentageFromCheapest": "0.00",
          "isCheapest": true,
          "isMostExpensive": false
        },
        // ... más proveedores
      ],
      "statistics": {
        "minPrice": 497,
        "maxPrice": 588,
        "avgPrice": 542,
        "priceDifference": 91,
        "percentageDifference": 18.31,
        "cheapestProvider": "Mediven",
        "mostExpensiveProvider": "Ethon"
      }
    }
  }
}
```

### 2. **Componente Frontend Actualizado**

📁 `/src/components/suppliers/AIAnalysis.tsx`

**Cambios principales:**

#### a) **Nueva lógica en `handleChatSubmit`:**

```typescript
// 1. Primero intenta buscar como producto
const searchResponse = await fetch("/api/providers/search-product", {
  method: "POST",
  body: JSON.stringify({ productName: query }),
});

// 2. Si encuentra producto, muestra comparación
if (searchData.success && searchData.data.found) {
  // Formatea respuesta visual con precios
}

// 3. Si no es producto, usa análisis general de IA
else {
  // Análisis de oportunidades, negociaciones, etc.
}
```

#### b) **Interfaces TypeScript agregadas:**

```typescript
interface PriceComparison {
  provider: string;
  price: number;
  differenceFromCheapest: number;
  percentageFromCheapest: string;
  isCheapest: boolean;
  isMostExpensive: boolean;
}

interface ProductSearchResult {
  productName: string;
  pricesCount: number;
  comparison: PriceComparison[];
  statistics: { ... };
}
```

#### c) **Renderizado mejorado de mensajes:**

```typescript
// Soporta formato markdown básico
<div
  dangerouslySetInnerHTML={{
    __html: msg.content
      .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
      .replace(/📦/g, '<span class="text-2xl">📦</span>'),
    // ... más emojis con tamaño aumentado
  }}
/>
```

#### d) **Botones de ejemplo actualizados:**

```typescript
// Nuevos botones con ejemplos de productos
<button onClick={() => setChatInput('AMLODIPINO')}>
  🔍 AMLODIPINO - Comparar precios entre proveedores
</button>

<button onClick={() => setChatInput('ENALAPRIL')}>
  🔍 ENALAPRIL - Ver diferencias de precio
</button>
```

#### e) **Placeholder actualizado:**

```typescript
placeholder = "Escribe el nombre de un producto o haz una pregunta...";
```

---

## 🎯 Casos de Uso Cubiertos

### ✅ Caso 1: Producto encontrado (único)

**Usuario escribe:** `"AMLODIPINO 10MG"`

**Sistema responde:**

- ✅ Nombre completo del producto
- ✅ Lista ordenada de proveedores (más barato primero)
- ✅ Precio de cada proveedor
- ✅ Diferencia en pesos y porcentaje
- ✅ Badges: 🏆 MEJOR PRECIO / ⚠️ MÁS CARO
- ✅ Estadísticas completas
- ✅ Recomendación clara de acción

### ✅ Caso 2: Múltiples productos encontrados

**Usuario escribe:** `"AMLODIPINO"`

**Sistema responde:**

```
🔍 Encontré 5 productos que coinciden con "AMLODIPINO":

1. (BE) AMLODIPINO 10MG X 30 COMP.
   💰 Mejor precio: $497 (Mediven)
   📊 3 proveedores

2. AMLODIPINO 5MG X 30 COMP.
   💰 Mejor precio: $380 (Mediven)
   📊 2 proveedores

...

💡 Por favor, sé más específico con el nombre del producto
para ver la comparación detallada.
```

### ✅ Caso 3: Producto no encontrado

**Usuario escribe:** `"PRODUCTO_INEXISTENTE"`

**Sistema responde:**

- Mensaje: "No se encontraron productos..."
- Continúa con análisis general de IA

### ✅ Caso 4: Pregunta general (no es producto)

**Usuario escribe:** `"¿Cuáles son mis mejores oportunidades de ahorro?"`

**Sistema responde:**

- Usa el análisis de IA original
- Tipos: oportunidades-ahorro, anomalias-precios, etc.

---

## 💡 Ventajas de la Implementación

### 1. **Búsqueda Inteligente**

- ✅ No requiere nombre exacto
- ✅ Ignora mayúsculas/minúsculas
- ✅ Encuentra coincidencias parciales
- ✅ Maneja prefijos y sufijos

### 2. **Información Clara y Accionable**

- ✅ Orden por precio (mejor primero)
- ✅ Visualización con emojis y colores
- ✅ Cálculos automáticos de diferencias
- ✅ Recomendación explícita

### 3. **Dual-Mode Chat**

- ✅ Búsqueda de productos específicos
- ✅ Análisis general con IA (cuando no es producto)
- ✅ Transición fluida entre ambos modos

### 4. **UX Mejorada**

- ✅ Botones de ejemplo con productos reales
- ✅ Placeholder instructivo
- ✅ Formato markdown para mejor legibilidad
- ✅ Emojis grandes y visibles

---

## 📊 Datos Utilizados

### Tablas de Supabase:

1. **`products`** - Productos con campos: id, ean, fingerprint, name, active_ingredient
2. **`provider_prices`** - Registros de precios (UNIQUE por product_id + provider_id)
3. **`providers`** - Proveedores con campos: id, name, created_at

### Relaciones:

```sql
products (1) ──< (N) provider_prices (N) >── (1) providers
   └── id (UUID)        └── product_id (UUID)
                        └── provider_id (UUID)
                        └── price (NUMERIC)
                        └── UNIQUE (product_id, provider_id)
```

---

## 🧪 Ejemplos de Búsquedas

### Búsquedas de Productos:

```
✅ "AMLODIPINO"
✅ "AMLODIPINO 10MG"
✅ "(BE) AMLODIPINO"
✅ "ENALAPRIL 20MG"
✅ "LOSARTAN"
✅ "METFORMINA 850MG"
✅ "SIMVASTATINA"
```

### Preguntas Generales (IA):

```
✅ "¿Cuáles son mis mejores oportunidades de ahorro?"
✅ "¿Qué proveedor me conviene más?"
✅ "¿Hay precios sospechosos?"
✅ "¿Cómo puedo negociar con proveedores?"
✅ "¿Qué productos debería comprar a cada proveedor?"
```

---

## 🔧 Configuración Requerida

### Variables de Entorno (.env.local):

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=tu_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=tu_key

# Groq IA (para análisis general)
GROQ_API_KEY=tu_api_key
```

### Base de Datos:

- ✅ Tabla `products` con datos
- ✅ Tabla `provider_prices` con precios
- ✅ Tabla `providers` con `is_active = true`

---

## 🎨 Ejemplo Visual del Chat

```
┌─────────────────────────────────────────────────────────────┐
│ 💬 Pregúntale a tu Asistente de Compras                    │
│ Escribe el nombre de un producto para comparar precios...  │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│ [Usuario]: AMLODIPINO                                       │
│                                                             │
│ [IA]:                                                       │
│ 📦 (BE) AMLODIPINO 10MG X 30 COMP.                         │
│                                                             │
│ 🔍 Comparación de Precios entre Proveedores:               │
│                                                             │
│ 1. Mediven 🏆 MEJOR PRECIO                                 │
│    💰 Precio: $497                                         │
│                                                             │
│ 2. Ethon ⚠️ MÁS CARO                                       │
│    💰 Precio: $588                                         │
│    📈 $91 más caro (18.3%)                                 │
│                                                             │
│ 📊 Estadísticas:                                           │
│ • Precio más bajo: $497 (Mediven)                          │
│ • Precio más alto: $588 (Ethon)                            │
│ • Diferencia máxima: $91 (18.3%)                           │
│                                                             │
│ 💡 Recomendación: Compra a Mediven y ahorra $91/unidad    │
│                                                             │
├─────────────────────────────────────────────────────────────┤
│ [Escribe el nombre de un producto o haz una pregunta...  ] │
│                                                      [Enviar]│
└─────────────────────────────────────────────────────────────┘
```

---

## ✅ Checklist de Implementación

- ✅ Endpoint `/api/providers/search-product` creado
- ✅ Búsqueda por nombre parcial implementada
- ✅ Integración con Supabase (products, provider_prices, providers)
- ✅ Cálculo de estadísticas y diferencias
- ✅ Identificación de mejor/peor precio
- ✅ Componente `AIAnalysis.tsx` actualizado
- ✅ Función `handleChatSubmit` con dual-mode
- ✅ Interfaces TypeScript agregadas
- ✅ Renderizado mejorado con markdown y emojis
- ✅ Botones de ejemplo actualizados
- ✅ Placeholder instructivo
- ✅ Documentación completa

---

## 🚀 Próximos Pasos Sugeridos

### Mejoras Opcionales:

1. **Autocompletado de productos**

   - Sugerir productos mientras el usuario escribe
   - Usar dropdown con lista de coincidencias

2. **Filtros avanzados**

   - Filtrar por categoría de producto
   - Filtrar por rango de precios
   - Filtrar por proveedor específico

3. **Historial de precios**

   - Mostrar evolución de precios en el tiempo
   - Gráficos de tendencias
   - Alertas de cambios de precio

4. **Comparación múltiple**

   - Comparar varios productos a la vez
   - Tabla comparativa de múltiples productos

5. **Exportar resultados**
   - Descargar comparación en PDF
   - Exportar a Excel
   - Compartir por email

---

## 🎓 Resumen para el Usuario

**¿Qué hace esto?**
Ahora puedes escribir el nombre de cualquier producto en el chat con IA y el sistema te mostrará automáticamente:

- Qué proveedores tienen ese producto
- Cuánto cobra cada uno
- Cuál es el más barato (con badge 🏆)
- Cuánto ahorras eligiendo el mejor precio
- Estadísticas completas de precios

**¿Cómo lo uso?**

1. Abre el chat con IA (pestaña "Chat con IA")
2. Escribe el nombre de un producto (ej: "AMLODIPINO")
3. El sistema responde con la comparación completa
4. Toma decisiones de compra informadas

**Ejemplos:**

- "AMLODIPINO" → Ve precios de todos los proveedores
- "ENALAPRIL 20MG" → Comparación específica
- "LOSARTAN" → Encuentra el mejor precio

¡Eso es todo! 🎉
