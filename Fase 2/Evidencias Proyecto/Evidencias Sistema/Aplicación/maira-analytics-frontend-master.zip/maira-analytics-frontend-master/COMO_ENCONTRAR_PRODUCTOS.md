/\*\*

- 🔍 Script para listar productos disponibles
-
- Este script te ayudará a encontrar nombres de productos reales
- que puedes usar para probar el chat
  \*/

console.log('📋 GUÍA PARA ENCONTRAR PRODUCTOS DISPONIBLES');
console.log('═'.repeat(70));

console.log('\n1️⃣ OPCIÓN 1: Usar Supabase SQL Editor');
console.log('─'.repeat(70));
console.log('\nAbre Supabase → SQL Editor → Nueva Query → Pega esto:\n');

const query1 = `-- Listar productos con precios de múltiples proveedores
SELECT 
  p.name AS producto,
  COUNT(DISTINCT pp.provider_id) AS num_proveedores,
  MIN(pp.price) AS precio_min,
  MAX(pp.price) AS precio_max,
  ROUND((MAX(pp.price) - MIN(pp.price)) / MIN(pp.price) * 100, 2) AS diferencia_porcentaje
FROM products p
JOIN provider_prices pp ON p.id = pp.product_id
JOIN providers prov ON pp.provider_id = prov.id
GROUP BY p.id, p.name
HAVING COUNT(DISTINCT pp.provider_id) >= 2
ORDER BY diferencia_porcentaje DESC
LIMIT 30;`;

console.log(query1);

console.log('\n📊 Esto te mostrará:');
console.log(' • Productos con al menos 2 proveedores');
console.log(' • Ordenados por mayor diferencia de precio (más interesante)');
console.log(' • Top 30 productos');
console.log('');

console.log('\n2️⃣ OPCIÓN 2: Buscar productos por categoría');
console.log('─'.repeat(70));
console.log('\nEn Supabase SQL Editor:\n');

const query2 = `-- Buscar productos que contengan una palabra
SELECT 
  p.name,
  COUNT(DISTINCT pp.provider_id) AS proveedores,
  MIN(pp.price) AS min,
  MAX(pp.price) AS max
FROM products p
JOIN provider_prices pp ON p.id = pp.product_id
JOIN providers prov ON pp.provider_id = prov.id
WHERE (
    p.name ILIKE '%AMLODIPINO%' OR
    p.name ILIKE '%ENALAPRIL%' OR
    p.name ILIKE '%LOSARTAN%' OR
    p.name ILIKE '%METFORMINA%' OR
    p.name ILIKE '%SIMVASTATINA%'
  )
GROUP BY p.id, p.name
ORDER BY p.name;`;

console.log(query2);

console.log('\n3️⃣ OPCIÓN 3: Ver todos los productos (primeros 50)');
console.log('─'.repeat(70));
console.log('\nEn Supabase SQL Editor:\n');

const query3 = `-- Primeros 50 productos alfabéticamente
SELECT 
  p.name,
  COUNT(DISTINCT pp.provider_id) AS num_proveedores
FROM products p
LEFT JOIN provider_prices pp ON p.id = pp.product_id
GROUP BY p.id, p.name
ORDER BY p.name
LIMIT 50;`;

console.log(query3);

console.log('\n4️⃣ VERIFICAR PROVEEDORES ACTIVOS');
console.log('─'.repeat(70));
console.log('\nEn Supabase SQL Editor:\n');

const query4 = `-- Ver proveedores activos
SELECT 
  id,
  name,
  is_active,
  created_at
FROM providers
ORDER BY is_active DESC, name;`;

console.log(query4);

console.log('\n📝 DESPUÉS DE EJECUTAR LAS QUERIES:');
console.log('═'.repeat(70));
console.log('1. Copia el nombre EXACTO de un producto de los resultados');
console.log('2. Pégalo en el chat (puedes usar parcial, ej: "AMLODIPINO")');
console.log('3. El sistema buscará productos que contengan ese texto');
console.log('4. Si encuentra, mostrará la comparación de precios');
console.log('');

console.log('\n🎯 EJEMPLO DE USO:');
console.log('─'.repeat(70));
console.log('Si la query devuelve: "(BE) AMLODIPINO 10MG X 30 COMP."');
console.log('');
console.log('Puedes buscar con:');
console.log(' ✅ "AMLODIPINO" → Encontrará');
console.log(' ✅ "AMLODIPINO 10MG" → Encontrará');
console.log(' ✅ "(BE) AMLODIPINO" → Encontrará');
console.log(' ✅ "amlodipino" → Encontrará (case-insensitive)');
console.log('');

console.log('\n⚠️ PROBLEMAS COMUNES:');
console.log('═'.repeat(70));

console.log('\n❌ Problema: "Producto no encontrado"');
console.log(' Causas:');
console.log(' • El producto no existe en la tabla products');
console.log(' • El producto no tiene precios en provider_prices');
console.log(' • Los proveedores están inactivos (is_active = false)');
console.log('');
console.log(' Solución:');
console.log(' 1. Ejecuta la Query 1 arriba para ver productos disponibles');
console.log(' 2. Usa nombres de esa lista');
console.log('');

console.log('\n❌ Problema: "Responde con análisis general"');
console.log(' Causa:');
console.log(' • El sistema no encontró el producto');
console.log(' • Está cayendo al modo de análisis general de IA');
console.log('');
console.log(' Solución:');
console.log(' 1. Abre DevTools (F12) en el navegador');
console.log(' 2. Ve a la pestaña Console');
console.log(' 3. Busca el producto en el chat');
console.log(' 4. Lee los logs:');
console.log(' 🔍 Buscando producto: ...');
console.log(' 📊 Respuesta de búsqueda: ...');
console.log(' 5. Si dice "found: false", el producto no está en BD');
console.log('');

console.log('\n💡 RECOMENDACIÓN:');
console.log('═'.repeat(70));
console.log('Antes de usar el chat:');
console.log('1. Ejecuta la Query 1 en Supabase');
console.log('2. Guarda una lista de 5-10 productos que tengas');
console.log('3. Usa esos productos para probar el chat');
console.log('4. Comparte la lista con tus usuarios');
console.log('');

console.log('\n📍 ARCHIVOS DEL PROYECTO:');
console.log('─'.repeat(70));
console.log('Backend: /src/app/api/providers/search-product/route.ts');
console.log('Frontend: /src/components/suppliers/AIAnalysis.tsx');
console.log('Logs: Revisa la consola del navegador (F12)');
console.log('');

console.log('\n✅ SIGUIENTE PASO:');
console.log('═'.repeat(70));
console.log('1. Ve a Supabase');
console.log('2. Ejecuta la Query 1 (productos con múltiples proveedores)');
console.log('3. Toma nota de 3-5 nombres de productos');
console.log('4. Prueba con esos nombres en el chat');
console.log('5. Si funcionan, crea una lista de productos disponibles');
console.log('');
