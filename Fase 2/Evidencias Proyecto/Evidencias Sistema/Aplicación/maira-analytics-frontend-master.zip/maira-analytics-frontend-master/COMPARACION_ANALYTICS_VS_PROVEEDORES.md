# 🔄 Comparación: Analytics vs Análisis de Proveedores

## 📊 Visión General

| Aspecto              | **Analytics (Ventas)**                   | **Proveedores (Compras)**                     |
| -------------------- | ---------------------------------------- | --------------------------------------------- |
| **Archivo Frontend** | `/src/app/dashboard/analytics/page.tsx`  | `/src/components/suppliers/AIAnalysis.tsx`    |
| **Archivo Backend**  | `/src/app/api/insights/analyze/route.ts` | `/src/app/api/providers/ai-analysis/route.ts` |
| **Fuente de Datos**  | `boletas_detalles` (ventas internas)     | `/api/compare-prices` (catálogos externos)    |
| **Objetivo**         | Maximizar ingresos                       | Minimizar costos                              |
| **Usuario**          | Gerencia comercial                       | Departamento de compras                       |

---

## 🎯 Casos de Uso

### **Analytics - Preguntas que Responde:**

1. ❓ _"¿Qué productos están vendiéndose más?"_ → Tendencias de Ventas
2. ❓ _"¿Cuándo venden más los antigripales?"_ → Estacionalidad
3. ❓ _"¿Qué productos están cayendo en ventas?"_ → Productos en Riesgo
4. ❓ _"¿Qué comprar para vender más?"_ → Oportunidades de Compra
5. ❓ _"¿Cómo mejorar mis márgenes?"_ → Análisis de Márgenes

### **Proveedores - Preguntas que Responde:**

1. ❓ _"¿Dónde puedo comprar más barato?"_ → Oportunidades de Ahorro
2. ❓ _"¿Hay precios sospechosos?"_ → Anomalías de Precios
3. ❓ _"¿Con quién negociar?"_ → Recomendaciones de Negociación
4. ❓ _"¿Estoy muy dependiente de un proveedor?"_ → Análisis de Diversificación
5. ❓ _"¿Qué comprar a cada uno?"_ → Optimización de Pedidos

---

## 🔍 Ejemplo Práctico: Paracetamol

### **Analytics:** _"¿Cómo va el Paracetamol?"_

```json
{
  "tendencias_ventas": {
    "producto": "Paracetamol 500mg",
    "ventas_mes_actual": 1500,
    "ventas_mes_anterior": 1200,
    "crecimiento": "+25%",
    "tendencia": "al_alza",
    "recomendacion": "Aumentar stock en 30% para próximo mes"
  }
}
```

**Conclusión:** Se vende bien, comprar más para vender.

---

### **Proveedores:** _"¿Dónde comprar Paracetamol?"_

```json
{
  "oportunidades_ahorro": {
    "producto": "Paracetamol 500mg x100",
    "proveedor_actual": "Proveedor A - $12,000",
    "proveedor_sugerido": "Proveedor B - $9,500",
    "ahorro_por_caja": "$2,500",
    "ahorro_mensual_estimado": "$37,500",
    "recomendacion": "Cambiar a Proveedor B"
  }
}
```

**Conclusión:** Comprarlo en Proveedor B para ahorrar.

---

## 🔄 Flujo Completo: Del Análisis a la Acción

### **Paso 1: Analytics - Detectar Oportunidad**

```
Usuario en /dashboard/analytics:
- Selecciona "Tendencias de Ventas"
- IA detecta: "Paracetamol creció 25% en últimos 3 meses"
- Recomendación: "Es un producto estrella, aumentar stock"
```

### **Paso 2: Proveedores - Optimizar Compra**

```
Usuario en /dashboard/proveedores → Análisis con IA:
- Selecciona "Oportunidades de Ahorro"
- IA detecta: "Proveedor B ofrece Paracetamol 20% más barato"
- Recomendación: "Comprar a Proveedor B y ahorrar $37,500/mes"
```

### **Paso 3: Resultado**

```
✅ Vender más (Analytics) + Comprar más barato (Proveedores) = Máxima Rentabilidad
```

---

## 🧠 Prompt Engineering: Diferentes Enfoques

### **Analytics - Contexto de Ventas**

```typescript
const contexto = `
Eres analista de ventas para farmacias en Chile.

CONTEXTO:
- Ubicación: Viña del Mar, Chile (hemisferio sur)
- Estación actual: Primavera (Octubre)
- Productos típicos: Antihistamínicos (alergias estacionales)

DATOS DE VENTAS:
${JSON.stringify(ventasPorProducto)}

TAREA: Identifica productos con TENDENCIA AL ALZA
Considera:
- Estacionalidad (Chile está en primavera)
- Crecimiento mes a mes
- Factores climáticos
`;
```

**Enfoque:** Histórico + Estacionalidad + Proyección

---

### **Proveedores - Contexto de Compras**

```typescript
const contexto = `
Eres experto en compras y negociación para farmacias.

CONTEXTO:
- 3 proveedores activos
- 250 productos comparados

DATOS DE PRECIOS:
${JSON.stringify(comparacionPrecios)}

TAREA: Identifica OPORTUNIDADES DE AHORRO
Considera:
- Diferencias significativas (>15%)
- Volumen de compra
- Impacto económico real
`;
```

**Enfoque:** Comparación + Optimización + ROI

---

## 💡 Decisiones de Diseño

### **¿Por Qué Sistemas Separados?**

| Razón                   | Explicación                                       |
| ----------------------- | ------------------------------------------------- |
| **Datos Diferentes**    | Ventas (interno) vs Catálogos (externo)           |
| **Usuarios Diferentes** | Gerente comercial vs Gerente de compras           |
| **Objetivos Opuestos**  | Maximizar precio venta vs Minimizar precio compra |
| **Modularidad**         | Más fácil de mantener separados                   |
| **Especialización**     | Cada IA enfocada en su dominio                    |

### **¿Por Qué Usar la Misma Tecnología?**

| Ventaja            | Detalle                             |
| ------------------ | ----------------------------------- |
| **Reutilización**  | Mismo SDK de Groq, misma estructura |
| **Consistencia**   | Misma experiencia de usuario        |
| **Costo Efectivo** | Una sola API key para ambos         |
| **Facilidad**      | Equipo ya conoce la implementación  |

---

## 📊 Métricas Clave

### **Analytics - KPIs de Ventas**

```typescript
{
  totalProductos: 347,
  productosTendenciaAlza: 45,
  ahorrosPotencialesDetectados: 23,
  margenPromedioOptimizado: 32.5,
  proyeccionVentasMesProximo: "+15%"
}
```

### **Proveedores - KPIs de Compras**

```typescript
{
  totalProveedores: 3,
  productosComparados: 250,
  ahorroPotencialMensual: 450000,  // CLP
  oportunidadesDetectadas: 15,
  proveedorMasCompetitivo: "Proveedor B"
}
```

---

## 🎨 Interfaz de Usuario

### **Analytics - Colores Azul/Morado**

```tsx
<div className="bg-gradient-to-r from-blue-600 to-purple-600">
  <Sparkles /> Analytics con IA
</div>
```

**Razón:** Asociación con análisis, inteligencia, predicción.

### **Proveedores - Colores Índigo/Rosa**

```tsx
<div className="bg-gradient-to-r from-indigo-600 to-purple-600">
  <Sparkles /> Centro de Inteligencia de Compras
</div>
```

**Razón:** Diferenciación visual, asociación con optimización.

---

## 🔀 Integración Futura

### **Escenario Ideal: Sistema Completo**

```
┌─────────────────────────────────────────────┐
│           DASHBOARD PRINCIPAL                │
└─────────────────┬───────────────────────────┘
                  │
        ┌─────────┴─────────┐
        │                   │
        ▼                   ▼
┌──────────────┐    ┌──────────────┐
│  ANALYTICS   │    │  PROVEEDORES │
│  (Ventas)    │◄──►│  (Compras)   │
└──────────────┘    └──────────────┘
        │                   │
        └─────────┬─────────┘
                  ▼
        ┌──────────────────┐
        │  RENTABILIDAD    │
        │  ÓPTIMA          │
        └──────────────────┘
```

**Flujo:**

1. **Analytics** detecta: "Vitamina C se vende 300% más en invierno"
2. **Sistema automático** consulta **Proveedores**
3. **Proveedores IA** responde: "Comprar a Proveedor B ahorra 25%"
4. **Resultado:** Stock óptimo al mejor precio

---

## 🚀 Recomendaciones de Uso

### **Usa Analytics cuando quieras:**

- ✅ Planificar inventario según tendencias
- ✅ Detectar productos en riesgo
- ✅ Entender patrones estacionales
- ✅ Optimizar márgenes de venta
- ✅ Proyectar ventas futuras

### **Usa Proveedores cuando quieras:**

- ✅ Reducir costos de compra
- ✅ Comparar precios entre proveedores
- ✅ Negociar con argumentos de datos
- ✅ Diversificar riesgos
- ✅ Optimizar pedidos

### **Usa AMBOS para:**

- 🎯 **Máxima rentabilidad:** Vender más de lo que tiene mejor margen
- 🎯 **Decisiones informadas:** Datos de ventas + datos de compras
- 🎯 **Ventaja competitiva:** Mejor producto al mejor precio

---

## 📈 Ejemplo de Decisión Completa

### **Producto: Loratadina (Antihistamínico)**

#### **1. Analytics dice:**

```
📊 Estacionalidad detectada:
- Septiembre-Noviembre: +250% ventas (primavera = alergias)
- Diciembre-Febrero: -70% ventas (verano)

📈 Recomendación:
"Aumentar stock de Loratadina 200% para octubre-noviembre"
```

#### **2. Proveedores dice:**

```
💰 Comparación de precios:
- Proveedor A: $8,500 (actual)
- Proveedor B: $6,800 (más barato)
- Diferencia: $1,700 (20% ahorro)

💡 Recomendación:
"Cambiar a Proveedor B para compra estacional"
```

#### **3. Decisión Final:**

```
✅ Acción: Comprar 500 unidades de Loratadina a Proveedor B

Cálculo:
- Sin IA: 500 × $8,500 = $4,250,000
- Con IA: 500 × $6,800 = $3,400,000
- Ahorro: $850,000 en un solo pedido

ROI del sistema de IA: Pagado en el primer pedido
```

---

## 🎓 Conclusión

### **Analytics + Proveedores = Sistema Completo**

```
┌─────────────────────────────────────────────┐
│  "¿QUÉ vender?"  →  Analytics               │
│  "¿DÓNDE comprar?" → Proveedores            │
│  "¿CUÁNTO ganar?"  →  Ambos combinados      │
└─────────────────────────────────────────────┘
```

**Resultado:**

- 📈 Vendes más de lo correcto
- 💰 Compras al mejor precio
- 🎯 Maximizas rentabilidad

**Todo con IA que te guía paso a paso.** ✨

---

## 🔗 Archivos Relacionados

### **Analytics (Ventas)**

- Frontend: `/src/app/dashboard/analytics/page.tsx`
- Backend: `/src/app/api/insights/analyze/route.ts`
- Documentación: `INICIO_RAPIDO_INSIGHTS_IA.md`

### **Proveedores (Compras)**

- Frontend: `/src/components/suppliers/AIAnalysis.tsx`
- Backend: `/src/app/api/providers/ai-analysis/route.ts`
- Documentación: `GUIA_IA_PROVEEDORES.md`

### **Ambos usan:**

- Groq SDK: `groq-sdk`
- Modelo: `llama-3.3-70b-versatile`
- API Key: `GROQ_API_KEY` en `.env.local`

---

**¡Ahora tienes un sistema completo de inteligencia de negocio para tu farmacia!** 🚀
