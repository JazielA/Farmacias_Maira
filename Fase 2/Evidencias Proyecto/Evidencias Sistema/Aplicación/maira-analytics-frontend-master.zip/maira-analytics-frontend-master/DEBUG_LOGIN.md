# 🔍 Debug: Usuario Deshabilitado puede Iniciar Sesión

## Pasos para Diagnosticar

### 1. Verificar que el usuario esté deshabilitado en la BD
```bash
npx tsx check-users.ts
```
✅ Confirmado: `user@example.com` tiene `isActive: false`

### 2. Abrir Herramientas de Desarrollo
- Presiona F12
- Ve a la pestaña "Consola"
- Ve a la pestaña "Red" (Network)

### 3. Intentar Login con Usuario Deshabilitado
1. Ve a: http://localhost:3000/login
2. Ingresa:
   - Email: `user@example.com`
   - Password: (la contraseña que usaste)
3. Click en "Iniciar Sesión"

### 4. Verificar Logs

#### En la Consola del Navegador (F12 → Consola):
Deberías ver:
```
🔍 [AUTH] Verificando estado del usuario: user@example.com
📡 [AUTH] Respuesta del servidor: 200
📊 [AUTH] Datos recibidos: { isActive: false, userId: "...", email: "..." }
❌ [AUTH] Usuario deshabilitado, cerrando sesión
```

#### En la Terminal donde corre npm run dev:
Deberías ver:
```
🔍 [API] Verificando estado de usuario...
👤 [API] Usuario de Supabase: user@example.com Error: undefined
🔎 [API] Buscando usuario en DB con ID: 7938dfef-99f4-4255-840b-4058735f76a5
💾 [API] Usuario en DB: {
  "isActive": false,
  "email": "user@example.com"
}
✅ [API] Estado del usuario user@example.com: isActive = false
```

#### En la Pestaña Red (F12 → Network):
Busca la request a `/api/user/check-status`:
- **Status:** Debería ser `200`
- **Response:** Debería contener `{ "isActive": false, ... }`

### 5. Posibles Problemas

#### Problema A: No ves ningún log
**Causa:** El código no se está ejecutando
**Solución:** 
1. Verifica que el servidor esté corriendo la última versión
2. Haz un hard refresh (Ctrl + Shift + R)
3. Limpia el cache del navegador

#### Problema B: Ves los logs pero permite el login
**Causa:** El error no se está manejando correctamente
**Solución:** Revisar el código de manejo de errores en LoginPage

#### Problema C: El endpoint retorna 401 o error
**Causa:** La sesión no se está estableciendo correctamente
**Solución:** Verificar la configuración de Supabase

#### Problema D: isActive aparece como true en los logs
**Causa:** La base de datos no tiene el valor correcto
**Solución:** Actualizar manualmente:
```sql
UPDATE users SET is_active = false WHERE email = 'user@example.com';
```

### 6. Test Manual en la API

Puedes probar el endpoint directamente:

1. Primero inicia sesión con un usuario activo para obtener una sesión
2. Luego en la consola del navegador ejecuta:
```javascript
fetch('/api/user/check-status')
  .then(r => r.json())
  .then(data => console.log('Estado:', data))
```

### 7. Verificar que el AuthContext esté siendo usado

En `src/app/login/page.tsx`, verifica que esté usando `signIn` del contexto:
```typescript
const { signIn } = useAuth();
```

Y que el handleSubmit lo esté llamando:
```typescript
const { error } = await signIn(email, password);
```

---

## 📝 Reportar Resultados

Por favor comparte:
1. ✅ Los logs que ves en la consola del navegador
2. ✅ Los logs que ves en la terminal del servidor
3. ✅ Si el login es exitoso o no
4. ✅ Cualquier mensaje de error que aparezca
5. ✅ La respuesta del endpoint `/api/user/check-status` en la pestaña Network
