# 📚 Documentación de API con Swagger

## ✅ Implementación Completada

Se ha creado exitosamente una página de documentación de API utilizando Swagger UI para el proyecto Maira Analytics.

## 🎯 Características Implementadas

### 1. **Página de Documentación**

- **Ubicación**: `/src/app/docs/page.tsx`
- **Ruta de acceso**: `http://localhost:3000/docs`
- **Tecnología**: Next.js 15 (App Router) + Swagger UI React

### 2. **Especificación OpenAPI 3.0.0**

La documentación incluye:

#### **Tags/Categorías**:

- 🔐 **Autenticación**: Login y gestión de sesiones
- 📊 **Dashboard**: Métricas y estadísticas
- 🏢 **Proveedores**: CRUD completo de proveedores
- 💬 **Mensajes**: Sistema de mensajería interna
- 🔔 **Notificaciones**: Gestión de notificaciones
- 📦 **Productos**: Catálogo y búsqueda de productos
- 🏆 **Ranking**: Rankings y comparaciones
- 💊 **Farmacia**: Operaciones específicas de farmacia

#### **Endpoints Documentados** (20+):

**Autenticación**:

- `POST /api/auth/login` - Iniciar sesión

**Dashboard**:

- `GET /api/dashboard/metrics` - Obtener métricas

**Proveedores**:

- `GET /api/providers` - Listar proveedores (con paginación y búsqueda)
- `POST /api/providers` - Crear proveedor
- `GET /api/providers/{id}` - Obtener proveedor por ID
- `PUT /api/providers/{id}` - Actualizar proveedor
- `DELETE /api/providers/{id}` - Eliminar proveedor
- `GET /api/providers/outdated` - Proveedores desactualizados
- `GET /api/providers/search-product` - Búsqueda inteligente con IA

**Mensajes**:

- `GET /api/messages/inbox` - Bandeja de entrada
- `GET /api/messages/sent` - Mensajes enviados
- `POST /api/messages/send` - Enviar mensaje
- `GET /api/messages/unread-count` - Contador de no leídos

**Notificaciones**:

- `GET /api/notifications` - Listar notificaciones
- `POST /api/notifications/mark-read` - Marcar como leída

**Productos**:

- `GET /api/catalog` - Catálogo de productos

**Ranking**:

- `GET /api/ranking/productos` - Ranking de productos

**Farmacia**:

- `POST /api/pharmacy/validate-products` - Validar productos
- `GET /api/pharmacy/diagnose` - Diagnóstico del sistema

### 3. **Seguridad**

- Esquema de autenticación: **Bearer Token (JWT)**
- Todos los endpoints protegidos requieren token de autenticación
- Documentación de códigos de respuesta HTTP

### 4. **Componentes de UI**

- Interfaz interactiva de Swagger UI
- Diseño responsive con Tailwind CSS
- Header personalizado con información del proyecto
- Soporte para modo claro/oscuro (nativo de Swagger UI)

## 📦 Dependencias Instaladas

```json
{
  "swagger-jsdoc": "^6.x.x",
  "swagger-ui-react": "^5.x.x",
  "@types/swagger-ui-react": "^4.x.x"
}
```

## 🚀 Cómo Usar

### Acceder a la Documentación

1. **Iniciar el servidor de desarrollo**:

   ```bash
   npm run dev
   ```

2. **Abrir en el navegador**:
   ```
   http://localhost:3001/docs
   ```

### Probar los Endpoints

1. **Autenticarse** (si es necesario):

   - Clic en el botón "Authorize" 🔓
   - Ingresar el token JWT
   - Clic en "Authorize"

2. **Probar un endpoint**:
   - Expandir el endpoint deseado
   - Clic en "Try it out"
   - Completar los parámetros necesarios
   - Clic en "Execute"
   - Ver la respuesta en tiempo real

## 🔧 Estructura del Código

```typescript
// src/app/docs/page.tsx
"use client";

import dynamic from "next/dynamic";
import "swagger-ui-react/swagger-ui.css";

const SwaggerUI = dynamic(() => import("swagger-ui-react"), { ssr: false });

const spec = {
  openapi: "3.0.0",
  info: {
    title: "Documentación de API - Maira Analytics",
    version: "1.0.0",
    // ... más configuración
  },
  paths: {
    // Definición de todos los endpoints
  },
};

export default function DocsPage() {
  return <SwaggerUI spec={spec} />;
}
```

## 🎨 Personalización

### Agregar Nuevos Endpoints

Para agregar un nuevo endpoint a la documentación:

```typescript
'/api/nuevo-endpoint': {
  get: {
    tags: ['Categoría'],
    summary: 'Descripción breve',
    description: 'Descripción detallada',
    security: [{ bearerAuth: [] }],
    parameters: [
      {
        name: 'parametro',
        in: 'query',
        schema: { type: 'string' },
        description: 'Descripción del parámetro'
      }
    ],
    responses: {
      '200': {
        description: 'Respuesta exitosa',
        content: {
          'application/json': {
            schema: {
              type: 'object',
              properties: {
                // Estructura de la respuesta
              }
            }
          }
        }
      }
    }
  }
}
```

### Cambiar el Tema

Swagger UI incluye temas predefinidos. Para personalizarlo:

```typescript
<SwaggerUI
  spec={spec}
  displayRequestDuration={true}
  defaultModelsExpandDepth={1}
  defaultModelExpandDepth={1}
  docExpansion="list"
/>
```

## 📝 Notas Importantes

### Next.js App Router vs Pages Router

Este proyecto usa **App Router** (Next.js 13+), por lo que:

- ❌ No usamos `getStaticProps` (es del Pages Router)
- ✅ Usamos componentes de cliente con `'use client'`
- ✅ La especificación se define directamente en el componente
- ✅ SwaggerUI se importa dinámicamente para evitar errores de SSR

### Importación Dinámica

```typescript
const SwaggerUI = dynamic(() => import("swagger-ui-react"), { ssr: false });
```

Esto es necesario porque Swagger UI usa APIs del navegador que no están disponibles durante el renderizado del servidor.

### Estilos CSS

```typescript
import "swagger-ui-react/swagger-ui.css";
```

Los estilos se importan globalmente para que Swagger UI se vea correctamente.

## 🔄 Próximos Pasos (Opcionales)

### 1. **Generación Automática desde JSDoc**

Si prefieres generar la documentación automáticamente desde comentarios en el código:

```bash
npm install swagger-jsdoc
```

```typescript
import swaggerJsdoc from "swagger-jsdoc";

const options = {
  definition: {
    openapi: "3.0.0",
    info: {
      title: "API Documentation",
      version: "1.0.0",
    },
  },
  apis: ["./src/app/api/**/*.ts"], // Archivos con JSDoc
};

const spec = swaggerJsdoc(options);
```

Y en tus archivos de API:

```typescript
/**
 * @swagger
 * /api/providers:
 *   get:
 *     summary: Lista todos los proveedores
 *     tags: [Proveedores]
 *     responses:
 *       200:
 *         description: Lista de proveedores
 */
export async function GET() {
  // ... código
}
```

### 2. **Exportar Especificación**

Crear endpoint para exportar el schema:

```typescript
// src/app/api/docs/route.ts
import { NextResponse } from "next/server";
import { spec } from "@/app/docs/page";

export async function GET() {
  return NextResponse.json(spec);
}
```

### 3. **Integración con Postman**

La especificación OpenAPI puede importarse directamente en Postman:

1. Abrir Postman
2. Import → Link
3. Pegar: `http://localhost:3001/api/docs`

## 🐛 Solución de Problemas

### Error: "document is not defined"

**Causa**: SwaggerUI se está renderizando en el servidor  
**Solución**: Asegúrate de usar importación dinámica con `ssr: false`

### Estilos no se cargan

**Causa**: Falta importar el CSS de Swagger UI  
**Solución**: `import 'swagger-ui-react/swagger-ui.css';`

### Puerto 3000 ocupado

**Causa**: Ya hay otra instancia corriendo  
**Solución**: Next.js automáticamente usa el puerto 3001 (o siguiente disponible)

## ✨ Ventajas de Esta Implementación

1. ✅ **Interactive**: Permite probar endpoints directamente desde el navegador
2. ✅ **Type-safe**: Usando TypeScript para la especificación
3. ✅ **Completa**: Incluye todos los endpoints principales del sistema
4. ✅ **Mantenible**: Fácil de actualizar y extender
5. ✅ **Estándar**: Usa OpenAPI 3.0.0, el estándar de la industria
6. ✅ **Sin dependencias externas**: No requiere servidor adicional
7. ✅ **Responsive**: Se adapta a cualquier tamaño de pantalla

## 📚 Referencias

- [OpenAPI Specification](https://swagger.io/specification/)
- [Swagger UI React](https://github.com/swagger-api/swagger-ui/tree/master/flavors/swagger-ui-react)
- [Next.js App Router](https://nextjs.org/docs/app)
- [swagger-jsdoc](https://github.com/Surnet/swagger-jsdoc)

---

**¡La documentación de tu API está lista! 🎉**

Accede a ella en: **http://localhost:3001/docs**
