/**
 * EJEMPLO: Cómo Documentar API Routes con JSDoc para Swagger
 * 
 * Este archivo muestra cómo agregar comentarios JSDoc a tus rutas de API
 * para generar documentación automáticamente.
 */

// ============================================================
// EJEMPLO 1: GET Simple
// ============================================================

/**
 * @swagger
 * /api/providers:
 *   get:
 *     tags:
 *       - Proveedores
 *     summary: Obtener lista de proveedores
 *     description: Retorna una lista paginada de todos los proveedores registrados en el sistema
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           default: 1
 *         description: Número de página
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           default: 10
 *         description: Cantidad de resultados por página
 *       - in: query
 *         name: search
 *         schema:
 *           type: string
 *         description: Término de búsqueda
 *     responses:
 *       200:
 *         description: Lista de proveedores obtenida exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 providers:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Provider'
 *                 total:
 *                   type: integer
 *                 page:
 *                   type: integer
 *                 totalPages:
 *                   type: integer
 *       401:
 *         description: No autorizado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 */
export async function GET(request: Request) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 2: POST con Request Body
// ============================================================

/**
 * @swagger
 * /api/providers:
 *   post:
 *     tags:
 *       - Proveedores
 *     summary: Crear un nuevo proveedor
 *     description: Registra un nuevo proveedor en el sistema
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required:
 *               - name
 *               - email
 *             properties:
 *               name:
 *                 type: string
 *                 example: Proveedor ABC
 *                 description: Nombre del proveedor
 *               email:
 *                 type: string
 *                 format: email
 *                 example: contacto@proveedor.com
 *               phone:
 *                 type: string
 *                 example: +56912345678
 *               address:
 *                 type: string
 *                 example: Av. Principal 123, Santiago
 *     responses:
 *       201:
 *         description: Proveedor creado exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Proveedor creado exitosamente
 *                 provider:
 *                   $ref: '#/components/schemas/Provider'
 *       400:
 *         description: Datos inválidos
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: No autorizado
 *       409:
 *         description: El proveedor ya existe
 */
export async function POST(request: Request) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 3: GET con Path Parameter
// ============================================================

/**
 * @swagger
 * /api/providers/{id}:
 *   get:
 *     tags:
 *       - Proveedores
 *     summary: Obtener proveedor por ID
 *     description: Retorna los detalles de un proveedor específico
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *           format: uuid
 *         description: ID único del proveedor
 *     responses:
 *       200:
 *         description: Proveedor encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Provider'
 *       404:
 *         description: Proveedor no encontrado
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/Error'
 *       401:
 *         description: No autorizado
 */
export async function GET(
  request: Request,
  { params }: { params: { id: string } }
) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 4: PUT con Path Parameter y Request Body
// ============================================================

/**
 * @swagger
 * /api/providers/{id}:
 *   put:
 *     tags:
 *       - Proveedores
 *     summary: Actualizar proveedor
 *     description: Actualiza la información de un proveedor existente
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del proveedor
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *               email:
 *                 type: string
 *                 format: email
 *               phone:
 *                 type: string
 *               status:
 *                 type: string
 *                 enum: [active, inactive]
 *     responses:
 *       200:
 *         description: Proveedor actualizado
 *       404:
 *         description: Proveedor no encontrado
 *       400:
 *         description: Datos inválidos
 */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 5: DELETE
// ============================================================

/**
 * @swagger
 * /api/providers/{id}:
 *   delete:
 *     tags:
 *       - Proveedores
 *     summary: Eliminar proveedor
 *     description: Elimina un proveedor del sistema (soft delete)
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *         description: ID del proveedor a eliminar
 *     responses:
 *       200:
 *         description: Proveedor eliminado exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Proveedor eliminado exitosamente
 *       404:
 *         description: Proveedor no encontrado
 *       401:
 *         description: No autorizado
 *       403:
 *         description: Sin permisos para eliminar
 */
export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 6: Endpoint con Múltiples Query Parameters
// ============================================================

/**
 * @swagger
 * /api/products/search:
 *   get:
 *     tags:
 *       - Productos
 *     summary: Buscar productos
 *     description: Busca productos con filtros avanzados
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: q
 *         schema:
 *           type: string
 *         description: Término de búsqueda
 *       - in: query
 *         name: category
 *         schema:
 *           type: string
 *         description: Filtrar por categoría
 *       - in: query
 *         name: minPrice
 *         schema:
 *           type: number
 *         description: Precio mínimo
 *       - in: query
 *         name: maxPrice
 *         schema:
 *           type: number
 *         description: Precio máximo
 *       - in: query
 *         name: inStock
 *         schema:
 *           type: boolean
 *         description: Solo productos en stock
 *       - in: query
 *         name: sortBy
 *         schema:
 *           type: string
 *           enum: [price, name, date]
 *           default: name
 *         description: Ordenar por
 *       - in: query
 *         name: order
 *         schema:
 *           type: string
 *           enum: [asc, desc]
 *           default: asc
 *         description: Orden
 *     responses:
 *       200:
 *         description: Resultados de búsqueda
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 products:
 *                   type: array
 *                   items:
 *                     $ref: '#/components/schemas/Product'
 *                 total:
 *                   type: integer
 *                 filters:
 *                   type: object
 */
export async function GET(request: Request) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 7: Schemas Reutilizables
// ============================================================

/**
 * @swagger
 * components:
 *   schemas:
 *     Provider:
 *       type: object
 *       required:
 *         - id
 *         - name
 *         - email
 *       properties:
 *         id:
 *           type: string
 *           format: uuid
 *           example: 123e4567-e89b-12d3-a456-426614174000
 *         name:
 *           type: string
 *           example: Proveedor ABC
 *         email:
 *           type: string
 *           format: email
 *           example: contacto@proveedor.com
 *         phone:
 *           type: string
 *           example: +56912345678
 *         address:
 *           type: string
 *           example: Av. Principal 123
 *         status:
 *           type: string
 *           enum: [active, inactive]
 *           example: active
 *         createdAt:
 *           type: string
 *           format: date-time
 *         updatedAt:
 *           type: string
 *           format: date-time
 * 
 *     Product:
 *       type: object
 *       properties:
 *         id:
 *           type: string
 *         name:
 *           type: string
 *         description:
 *           type: string
 *         price:
 *           type: number
 *           format: float
 *         category:
 *           type: string
 *         inStock:
 *           type: boolean
 *         providerId:
 *           type: string
 *         provider:
 *           $ref: '#/components/schemas/Provider'
 * 
 *     Error:
 *       type: object
 *       properties:
 *         error:
 *           type: string
 *           description: Mensaje de error
 *           example: Error al procesar la solicitud
 *         code:
 *           type: string
 *           description: Código de error
 *           example: ERR_INVALID_INPUT
 *         details:
 *           type: object
 *           description: Detalles adicionales del error
 * 
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 *       bearerFormat: JWT
 *       description: Token JWT de autenticación obtenido del endpoint /api/auth/login
 */

// ============================================================
// EJEMPLO 8: Endpoint con Upload de Archivos
// ============================================================

/**
 * @swagger
 * /api/providers/upload:
 *   post:
 *     tags:
 *       - Proveedores
 *     summary: Subir archivo de proveedores
 *     description: Importa proveedores desde un archivo Excel o CSV
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         multipart/form-data:
 *           schema:
 *             type: object
 *             required:
 *               - file
 *             properties:
 *               file:
 *                 type: string
 *                 format: binary
 *                 description: Archivo Excel o CSV con datos de proveedores
 *               overwrite:
 *                 type: boolean
 *                 description: Sobrescribir datos existentes
 *                 default: false
 *     responses:
 *       200:
 *         description: Archivo procesado exitosamente
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 imported:
 *                   type: integer
 *                   description: Cantidad de registros importados
 *                 skipped:
 *                   type: integer
 *                   description: Cantidad de registros omitidos
 *                 errors:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       row:
 *                         type: integer
 *                       error:
 *                         type: string
 *       400:
 *         description: Formato de archivo inválido
 */
export async function POST(request: Request) {
  // Tu código aquí
}

// ============================================================
// EJEMPLO 9: Endpoint con Respuestas Paginadas
// ============================================================

/**
 * @swagger
 * /api/messages:
 *   get:
 *     tags:
 *       - Mensajes
 *     summary: Listar mensajes
 *     description: Obtiene lista paginada de mensajes del usuario
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: page
 *         schema:
 *           type: integer
 *           minimum: 1
 *           default: 1
 *       - in: query
 *         name: limit
 *         schema:
 *           type: integer
 *           minimum: 1
 *           maximum: 100
 *           default: 20
 *       - in: query
 *         name: folder
 *         schema:
 *           type: string
 *           enum: [inbox, sent, archived]
 *           default: inbox
 *     responses:
 *       200:
 *         description: Lista de mensajes
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 messages:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                       subject:
 *                         type: string
 *                       preview:
 *                         type: string
 *                       sender:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                           name:
 *                             type: string
 *                       isRead:
 *                         type: boolean
 *                       createdAt:
 *                         type: string
 *                         format: date-time
 *                 pagination:
 *                   type: object
 *                   properties:
 *                     page:
 *                       type: integer
 *                     limit:
 *                       type: integer
 *                     total:
 *                       type: integer
 *                     totalPages:
 *                       type: integer
 *                     hasNext:
 *                       type: boolean
 *                     hasPrev:
 *                       type: boolean
 */
export async function GET(request: Request) {
  // Tu código aquí
}

// ============================================================
// CÓMO USAR ESTOS COMENTARIOS
// ============================================================

/*
Para generar documentación automática usando JSDoc:

1. Instalar swagger-jsdoc:
   npm install swagger-jsdoc

2. Crear configuración en src/app/docs/page.tsx:

   import swaggerJsdoc from 'swagger-jsdoc';
   
   const options = {
     definition: {
       openapi: '3.0.0',
       info: {
         title: 'Maira Analytics API',
         version: '1.0.0',
       },
       servers: [
         {
           url: '/api',
         },
       ],
     },
     apis: [
       './src/app/api/*.ts',
       './src/app/api/*/*.ts',
       // Agrega más rutas según tu estructura
     ],
   };
   
   const spec = swaggerJsdoc(options);

3. Los comentarios @swagger serán procesados automáticamente

4. Agregar estos comentarios a todos tus archivos de API routes

VENTAJAS:
- Documentación junto al código
- Se actualiza automáticamente al modificar el código
- Single source of truth
- Fácil de mantener
- Compatible con herramientas externas

DESVENTAJAS:
- Requiere procesamiento en build time
- Archivos más largos
- Puede afectar rendimiento si hay muchos endpoints
*/
