# ✅ ERROR CORREGIDO: Insights con IA

## 🐛 Problema Original

```
Error: Invalid prisma.boletas_detalles.findMany() invocation
Unknown field `sucursal` for select statement on model `boletas`
```

**Causa:** El schema de Prisma usa `sucursal_id` (no `sucursal`), y `boletas_detalles` no tiene relación directa con `productos_pos`.

---

## 🔧 Correcciones Aplicadas

### 1. Campo `sucursal` → `sucursal_id`

**Antes:**
```typescript
boletas: {
  select: {
    fecha: true,
    sucursal: true,  // ❌ NO EXISTE
  },
}
```

**Después:**
```typescript
boletas: {
  select: {
    fecha: true,
    sucursal_id: true,  // ✅ CORRECTO
  },
}
```

---

### 2. Relación `productos_pos` no disponible

**Problema:** `boletas_detalles` no tiene relación directa con `productos_pos` en el schema.

**Solución:** Hacer query separada para obtener precios de productos.

**Antes:**
```typescript
include: {
  boletas: { ... },
  productos_pos: {  // ❌ NO EXISTE ESTA RELACIÓN
    select: { preciocompraneto: true }
  }
}
```

**Después:**
```typescript
// 1. Obtener detalles de boletas
const ventasDetalladas = await prisma.boletas_detalles.findMany({
  include: {
    boletas: { select: { fecha: true, sucursal_id: true } }
  }
});

// 2. Obtener precios por separado
const codigosUnicos = [...new Set(ventasDetalladas.map(d => d.codigo))];
const productosConPrecios = await prisma.productos_pos.findMany({
  where: { codigo: { in: codigosUnicos } },
  select: { codigo: true, preciocompraneto: true }
});

// 3. Crear mapa para acceso rápido
const preciosMap = new Map(
  productosConPrecios.map(p => [p.codigo, p.preciocompraneto])
);
```

---

### 3. Manejo de valores nulos

**Agregado:** Conversión segura de tipos Decimal/null a number.

```typescript
const cantidad = Number(detalle.cantidad) || 0;
const precio = Number(detalle.precio) || 0;
const precioSinIVA = precio / 1.19;
const costoUnitario = Number(preciosMap.get(codigo)) || 0;
```

---

### 4. Tipos de TypeScript

**Corregido:** Eliminados tipos `any`, agregados tipos específicos.

```typescript
// Tipo del whereClause
const whereClause: {
  fecha: { gte: Date; lte: Date };
  sucursal_id?: number | null;
} = { ... };

// Tipo de productos en construirContextoIA
productos: Array<{
  codigo: string;
  nombre: string;
  unidadesVendidas: number;
  margenDinero: number;
  margenPorcentaje: number;
  ventasPorMes: Array<{ mes: string; ventas: number }>;
}>
```

---

### 5. Uso de `toSorted()` en lugar de `sort()`

**Antes:**
```typescript
const top10 = productos.sort(...).slice(0, 10);  // ⚠️ Muta array original
```

**Después:**
```typescript
const top10 = productos.toSorted(...).slice(0, 10);  // ✅ Inmutable
```

---

## 📂 Archivo Modificado

```
✅ src/app/api/insights/analyze/route.ts
```

**Líneas modificadas:**
- Línea 33-45: whereClause con tipos correctos
- Línea 48-82: Query separada para productos_pos + mapa de precios
- Línea 84-119: Manejo seguro de valores nulos
- Línea 122-141: Conversión correcta de ventasPorMes
- Línea 150-161: Tipos explícitos para función construirContextoIA
- Línea 163-168: Uso de toSorted()

---

## ✅ Estado Actual

| Componente | Estado |
|------------|--------|
| Compilación TypeScript | ✅ Sin errores |
| Lint warnings | ✅ Resueltos |
| Schema Prisma | ✅ Compatible |
| Queries de base de datos | ✅ Optimizadas |
| Tipos de TypeScript | ✅ Completos |

---

## 🚀 Próximo Paso: Probar

### 1. Abrir Analytics:
```
http://localhost:3000/dashboard/analytics
```

### 2. Hacer click en cualquier análisis:
- 📋 Resumen General
- 📈 Tendencias de Ventas
- 📅 Análisis Estacional
- 🛒 Oportunidades de Compra
- ⚠️ Productos en Riesgo
- 💰 Optimización de Márgenes

### 3. Verificar:
- ✅ No hay errores en consola
- ✅ Aparece animación "Analizando datos..."
- ✅ Se generan insights en 2-10 segundos
- ✅ Los datos se muestran estructurados

---

## 🔍 Si encuentras otro error:

### Error: "No se ha configurado la API key"

**Solución:**
```bash
# Verificar .env.local
GROQ_API_KEY=gsk_tu_key_aqui

# Reiniciar servidor
Ctrl+C
npm run dev
```

---

### Error: "Error al obtener datos de ventas"

**Posible causa:** No hay datos en el período de 90 días.

**Solución temporal:** Usar datos mock en la función `obtenerDatosVentas()`:

```typescript
// Línea ~30 en route.ts
async function obtenerDatosVentas(...) {
  // Comentar todo el código de Prisma
  
  // Retornar datos de prueba
  return [
    {
      codigo: '12345',
      nombre: 'Paracetamol 500mg',
      unidadesVendidas: 150,
      ingresosSinIVA: 45000,
      costoTotal: 30000,
      frecuencia: 45,
      margenDinero: 15000,
      margenPorcentaje: 33.3,
      ventasPorMes: [
        { mes: '2024-10', ventas: 50 },
        { mes: '2024-11', ventas: 60 },
        { mes: '2024-12', ventas: 40 },
      ],
    },
    // Agregar más productos...
  ];
}
```

---

### Error: "Rate limit exceeded"

**Causa:** Superaste el límite gratuito de Groq (30 req/min).

**Solución:** Espera 1 minuto antes de hacer otra consulta.

---

## 📊 Estructura de la Query Corregida

```
1. prisma.boletas_detalles.findMany()
   ↓
   Filtra por: boletas.fecha (gte/lte)
   ↓
   Incluye: boletas.fecha, boletas.sucursal_id
   ↓
2. prisma.productos_pos.findMany()
   ↓
   Filtra por: codigo IN (códigos únicos de boletas_detalles)
   ↓
   Obtiene: preciocompraneto
   ↓
3. Crear Map<codigo, precio>
   ↓
4. Agrupar datos por producto
   ↓
5. Calcular métricas (margen, tendencia)
   ↓
6. Enviar a Groq IA
   ↓
7. Retornar insights estructurados
```

---

## 🎯 Resultado Esperado

Al hacer click en "Tendencias de Ventas", deberías ver algo como:

```json
{
  "success": true,
  "data": {
    "insights": {
      "resumen": "Se detectaron 15 productos con crecimiento sostenido...",
      "productos_tendencia_alza": [
        {
          "nombre": "Paracetamol 500mg",
          "crecimiento_porcentual": 35,
          "razon": "Alta demanda en temporada de gripe",
          "recomendacion_stock": "Aumentar inventario en 40%"
        }
      ]
    },
    "metadata": {
      "totalProductos": 247,
      "fechaInicio": "2024-07-16",
      "fechaFin": "2024-10-14",
      "generadoEn": "2024-10-14T15:30:00Z"
    }
  }
}
```

---

## 📝 Notas Técnicas

### Schema Prisma (estructura real):

```prisma
model boletas {
  folio              Int       @id
  sucursal_id        Float?    // ← NOMBRE CORRECTO
  fecha              DateTime?
  // ... otros campos
  boletas_detalles   boletas_detalles[]
}

model boletas_detalles {
  id                     Int       @id
  boleta_folio           Int?
  codigo                 String?
  nombre                 String?
  cantidad               Decimal?
  precio                 Decimal?
  boletas                boletas?  @relation(...)
  productos_normalizados productos_normalizados? @relation(...)
  // NO tiene relación directa con productos_pos ❌
}

model productos_pos {
  id                 BigInt    @id
  codigo             String?
  preciocompraneto   Decimal?
  // ... otros campos
  // NO tiene relación inversa con boletas_detalles ❌
}
```

### Por qué no hay relación directa:

- `boletas_detalles.codigo` es un String
- `productos_pos.codigo` también es String
- Pero **no hay FK definida** en el schema
- Por eso debemos hacer join manual con un Map

---

## ✅ Verificación Final

Ejecuta esto en la consola del navegador (F12) después de hacer una consulta:

```javascript
// Debe retornar 200
console.log('Status:', response.status);

// Debe ser true
console.log('Success:', data.success);

// Debe tener insights
console.log('Insights:', data.data.insights);
```

---

**¡El error está corregido y la IA debería funcionar ahora! 🎉**

_Última actualización: 14 de octubre de 2024_
