# 🤖 Sistema de Análisis Inteligente de Proveedores

## 📋 Resumen

Sistema de IA para optimizar compras a proveedores usando **Groq (LLaMA 3.3)** que analiza comparaciones de precios y genera recomendaciones accionables.

---

## 🎯 Diferencias con Analytics

| Aspecto      | **Analytics** (Ventas)       | **Proveedores** (Compras)           |
| ------------ | ---------------------------- | ----------------------------------- |
| **Datos**    | Histórico de ventas interno  | Catálogos de proveedores externos   |
| **Objetivo** | Maximizar ventas             | Minimizar costos de compra          |
| **Análisis** | Tendencias, estacionalidad   | Comparación de precios, negociación |
| **Usuario**  | Gerencia comercial           | Departamento de compras             |
| **Métricas** | Ingresos, márgenes, rotación | Ahorros, diferencias de precio      |
| **Decisión** | Qué vender más               | A quién comprar                     |

---

## 🏗️ Arquitectura del Sistema

```
┌─────────────────────┐
│   FRONTEND          │
│ AIAnalysis.tsx      │
│ - Dashboard         │
│ - Chat con IA       │
│ - Calculadora       │
└──────────┬──────────┘
           │ POST /api/providers/ai-analysis
           ▼
┌─────────────────────┐
│   BACKEND API       │
│ ai-analysis/route.ts│
│ 1. Obtiene datos    │
│    /api/compare-    │
│    prices           │
│ 2. Procesa          │
│ 3. Llama Groq IA    │
│ 4. Retorna insights │
└──────────┬──────────┘
           │
      ┌────┴────┐
      ▼         ▼
┌──────────┐ ┌──────────┐
│ Supabase │ │ Groq AI  │
│  (providers)│ │ (LLaMA) │
└──────────┘ └──────────┘
```

---

## 🔥 5 Tipos de Análisis con IA

### **1. 💰 Oportunidades de Ahorro**

**Pregunta clave:** _"¿Dónde puedo ahorrar más dinero?"_

**Qué hace:**

- Identifica productos con grandes diferencias de precio
- Calcula ahorro si cambias de proveedor
- Prioriza por impacto económico

**Ejemplo de respuesta:**

```json
{
  "oportunidades": [
    {
      "producto": "Paracetamol 500mg x100",
      "proveedor_actual_probable": "Proveedor A",
      "proveedor_sugerido": "Proveedor B",
      "precio_actual": 12000,
      "precio_sugerido": 9500,
      "ahorro_por_unidad": 2500,
      "porcentaje_ahorro": 20.8,
      "prioridad": "alta",
      "razon": "Producto de alta rotación con diferencia significativa"
    }
  ],
  "ahorro_potencial_total": 450000,
  "resumen": "Cambiar 15 productos clave puede generar $450,000 de ahorro mensual"
}
```

---

### **2. ⚠️ Anomalías de Precios**

**Pregunta clave:** _"¿Hay precios sospechosos o errores?"_

**Qué hace:**

- Detecta precios fuera de rango normal
- Identifica posibles errores de digitación
- Encuentra inconsistencias

**Ejemplo de respuesta:**

```json
{
  "anomalias": [
    {
      "producto": "Ibuprofeno 400mg",
      "proveedor": "Proveedor C",
      "precio": 85000,
      "precio_esperado": 8500,
      "tipo_anomalia": "posible_error",
      "nivel_riesgo": "alto",
      "recomendacion": "Verificar con proveedor - probable error de un cero extra"
    }
  ],
  "total_anomalias": 3,
  "resumen": "3 productos requieren verificación urgente"
}
```

---

### **3. 🎯 Recomendaciones de Negociación**

**Pregunta clave:** _"¿Con quién y cómo negociar mejores precios?"_

**Qué hace:**

- Identifica proveedores con precios altos
- Genera argumentos de negociación
- Calcula impacto de descuentos

**Ejemplo de respuesta:**

```json
{
  "negociaciones_priorizadas": [
    {
      "proveedor": "Proveedor A",
      "productos_a_negociar": 25,
      "ahorro_potencial": 120000,
      "estrategia": "Negociar descuento por volumen en productos de alta rotación",
      "argumento_clave": "Proveedor B ofrece 18% menos en promedio en productos similares",
      "prioridad": "alta"
    }
  ],
  "resumen": "Negociar con 3 proveedores puede reducir costos en $280,000/mes"
}
```

---

### **4. 📊 Análisis de Diversificación**

**Pregunta clave:** _"¿Estoy muy dependiente de un proveedor?"_

**Qué hace:**

- Evalúa concentración de compras
- Detecta riesgo de dependencia
- Sugiere diversificación

**Ejemplo de respuesta:**

```json
{
  "analisis_riesgo": {
    "nivel_riesgo_global": "medio",
    "proveedor_mayor_dependencia": "Proveedor A",
    "porcentaje_concentracion": 65,
    "productos_sin_alternativa": 15
  },
  "recomendaciones_diversificacion": [
    {
      "area_riesgo": "65% de productos dependen de un solo proveedor",
      "accion_sugerida": "Buscar alternativas para al menos 30% de productos críticos",
      "impacto": "alto"
    }
  ],
  "resumen": "Riesgo moderado - diversificar proveedores en productos críticos"
}
```

---

### **5. 🛒 Optimización de Pedidos**

**Pregunta clave:** _"¿Qué comprar a cada proveedor para ahorrar más?"_

**Qué hace:**

- Crea plan de compra optimizado
- Asigna productos a proveedores
- Maximiza ahorro global

**Ejemplo de respuesta:**

```json
{
  "plan_compras_optimizado": [
    {
      "proveedor": "Proveedor B",
      "productos_recomendados": [
        {
          "producto": "Paracetamol 500mg",
          "razon": "20% más barato que competencia",
          "ahorro_vs_otros": 2500
        }
      ],
      "total_productos": 45,
      "ahorro_estimado": 85000
    }
  ],
  "resumen": "Plan optimizado: comprar 45 productos a Proveedor B, 32 a Proveedor A"
}
```

---

## 💡 Características Especiales

### **1. Dashboard Inteligente**

Vista general con:

- **KPIs principales:** Ahorro potencial, oportunidades, proveedores
- **Ranking de proveedores:** Score 0-100 basado en competitividad
- **Top oportunidades:** Las 5 mejores oportunidades de ahorro

### **2. Chat Conversacional**

Habla con la IA en lenguaje natural:

```
Usuario: "¿Cuáles son mis mejores oportunidades de ahorro?"
IA: [Analiza y responde con oportunidades específicas]

Usuario: "¿Qué proveedor me conviene más?"
IA: [Compara proveedores y recomienda el mejor]

Usuario: "¿Hay precios sospechosos?"
IA: [Detecta anomalías y las explica]
```

### **3. Calculadora de Ahorros** (Próximamente)

Simula cambios de proveedores y calcula impacto.

---

## 🔄 Flujo Completo del Sistema

### **Paso 1: Frontend - Usuario Solicita Análisis**

```tsx
// Usuario hace clic en "Oportunidades de Ahorro"
handleGenerateAnalysis("oportunidades-ahorro");
```

### **Paso 2: Backend - Obtiene Datos**

```typescript
// Llama a /api/compare-prices para obtener datos
const datos = await obtenerDatosProveedores();

// Resultado:
{
  productos: [
    {
      nombre: "Paracetamol 500mg",
      precioMinimo: 8000,
      precioMaximo: 12000,
      diferenciaMaxima: 4000,
      proveedorMasBarato: "Proveedor B"
    }
  ],
  proveedores: [
    {
      nombre: "Proveedor A",
      totalProductos: 150,
      precioPromedio: 9500,
      vecesEsMasBarato: 45
    }
  ]
}
```

### **Paso 3: Backend - Construye Prompt para IA**

```typescript
const contexto = `
Eres experto en compras para farmacias.

DATOS:
- 3 proveedores activos
- 250 productos analizados

PROVEEDORES:
${JSON.stringify(proveedores)}

PRODUCTOS CON MAYORES DIFERENCIAS:
${JSON.stringify(productos.slice(0, 15))}

TAREA: Identifica OPORTUNIDADES DE AHORRO
Analiza diferencias de precio y genera recomendaciones...
`;
```

### **Paso 4: Backend - Llama a Groq IA**

```typescript
const completion = await groq.chat.completions.create({
  model: "llama-3.3-70b-versatile",
  messages: [
    { role: "system", content: "Eres experto en compras..." },
    { role: "user", content: contexto },
  ],
  temperature: 0.3,
  response_format: { type: "json_object" },
});

const insights = JSON.parse(completion.choices[0].message.content);
```

### **Paso 5: Frontend - Muestra Resultados**

```tsx
// Renderiza insights de forma visual
<div className="oportunidades">
  {insights.oportunidades.map((opp) => (
    <div>
      <h3>{opp.producto}</h3>
      <p>Ahorro: {formatCurrency(opp.ahorro)}</p>
      <p>
        Cambiar de {opp.proveedor_actual} a {opp.proveedor_sugerido}
      </p>
    </div>
  ))}
</div>
```

---

## 🎓 Casos de Uso Reales

### **Escenario 1: Nuevo Gerente de Compras**

```
Necesidad: "Quiero saber si estoy pagando de más"

Acción:
1. Va a Dashboard → Ve ahorro potencial de $450,000
2. Click en "Oportunidades de Ahorro"
3. IA detecta 15 productos donde puede ahorrar

Resultado: Plan de acción con productos específicos para cambiar
```

---

### **Escenario 2: Negociación con Proveedor**

```
Necesidad: "Necesito argumentos para negociar con Proveedor A"

Acción:
1. Click en "Recomendaciones de Negociación"
2. IA genera estrategia con datos concretos

Resultado: "Proveedor B ofrece 18% menos en 25 productos similares"
```

---

### **Escenario 3: Detección de Errores**

```
Necesidad: "El precio de un producto se ve raro"

Acción:
1. Click en "Anomalías de Precios"
2. IA detecta: Ibuprofeno a $85,000 (debería ser $8,500)

Resultado: Alerta de posible error de digitación
```

---

## 🔑 Ventajas del Sistema

| Ventaja                       | Descripción                                     |
| ----------------------------- | ----------------------------------------------- |
| ✅ **Automatización**         | Analiza cientos de productos en segundos        |
| ✅ **Datos Concretos**        | Recomendaciones con montos y porcentajes reales |
| ✅ **Múltiples Perspectivas** | 5 tipos de análisis diferentes                  |
| ✅ **Chat Natural**           | Pregunta en lenguaje normal                     |
| ✅ **Accionable**             | Dice exactamente qué hacer                      |
| ✅ **Gratis**                 | Usa Groq en lugar de OpenAI                     |
| ✅ **Contextual**             | Entiende contexto de farmacia chilena           |

---

## 🚀 Configuración e Instalación

### **1. Variables de Entorno**

```bash
# .env.local
GROQ_API_KEY=gsk_xxxxxxxxxxxxxxxxxxxx
NEXT_PUBLIC_BASE_URL=http://localhost:3000  # Para desarrollo
```

### **2. Obtener API Key Gratis**

1. Ir a: https://console.groq.com
2. Crear cuenta (gratis)
3. Generar API key
4. Copiarla a .env.local

### **3. Ejecutar**

```bash
npm run dev
```

### **4. Usar**

1. Ir a `/dashboard/proveedores`
2. Click en pestaña "✨ Análisis con IA"
3. Seleccionar tipo de análisis
4. Ver resultados

---

## 📊 Comparación: Analytics vs Proveedores

### **Analytics (Ventas)**

```typescript
// Analiza datos INTERNOS de ventas
const ventas = await prisma.boletas_detalles.findMany({
  where: { fecha: { gte: fechaInicio } },
});

// Pregunta: "¿Qué productos se venden más?"
// Objetivo: Aumentar ingresos
```

### **Proveedores (Compras)**

```typescript
// Analiza datos EXTERNOS de catálogos
const precios = await fetch("/api/compare-prices");

// Pregunta: "¿Dónde comprar más barato?"
// Objetivo: Reducir costos
```

---

## 🎯 Mejores Prácticas

### **1. Mantén Catálogos Actualizados**

- Sube catálogos de proveedores regularmente
- La IA necesita datos frescos para análisis precisos

### **2. Valida Recomendaciones**

- La IA es un asistente, no reemplaza juicio humano
- Verifica precios antes de cambiar proveedor

### **3. Usa Chat para Explorar**

- Pregunta cosas específicas
- "¿Por qué Proveedor B es mejor para antibióticos?"

### **4. Combina con Analytics**

- Analytics dice qué SE VENDE más
- Proveedores dice dónde COMPRAR más barato
- Juntos = máxima rentabilidad

---

## 🐛 Troubleshooting

### **Error: "No se ha configurado API key"**

```bash
# Solución: Agregar a .env.local
GROQ_API_KEY=tu_key_aqui
# Reiniciar servidor
```

### **Error: "No hay datos suficientes"**

```bash
# Solución: Cargar catálogos en pestaña "Gestión de Proveedores"
```

### **Error: "Error al obtener datos"**

```bash
# Solución: Verificar que /api/compare-prices funcione
# Probar: http://localhost:3000/api/compare-prices
```

---

## 🔮 Futuras Mejoras

- [ ] **Historial de análisis:** Comparar cambios en el tiempo
- [ ] **Alertas automáticas:** Notificar cuando hay oportunidades
- [ ] **Integración con sistema de pedidos:** Generar órdenes automáticas
- [ ] **Análisis predictivo:** Predecir aumentos de precios
- [ ] **Multi-sucursal:** Comparar compras entre sucursales

---

## 📚 Recursos

- **Groq Console:** https://console.groq.com
- **LLaMA 3.3 Docs:** https://www.llama.com/docs/
- **Código fuente:**
  - Frontend: `/src/components/suppliers/AIAnalysis.tsx`
  - Backend: `/src/app/api/providers/ai-analysis/route.ts`

---

## ✨ Resumen Final

Este sistema te permite:

1. **Ver de un vistazo** dónde ahorrar dinero
2. **Negociar mejor** con argumentos de datos
3. **Detectar errores** antes de comprar
4. **Optimizar compras** automáticamente
5. **Hablar con IA** sobre tus proveedores

**Todo sin ser experto en análisis de datos.** 🎯
