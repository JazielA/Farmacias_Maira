# 🚀 GUÍA RÁPIDA: Instalar Insights con IA en Farmacias Maira

## ⏱️ Tiempo estimado: 15-20 minutos

---

## 📦 PASO 1: Instalar Dependencia (2 min)

Abre PowerShell en la carpeta del proyecto y ejecuta:

```powershell
npm install groq-sdk
```

---

## 🔑 PASO 2: Obtener API Key de Groq - GRATIS (5 min)

1. **Ir a:** https://console.groq.com
2. **Crear cuenta** con tu email
3. **Ir a "API Keys"** en el menú lateral
4. **Crear nueva key:** Click en "Create API Key"
5. **Copiar la key** (empieza con `gsk_...`)

---

## ⚙️ PASO 3: Configurar API Key (2 min)

### En desarrollo (.env.local):

Edita el archivo `.env.local` en la raíz del proyecto:

```bash
# Agregar al final del archivo:
GROQ_API_KEY=gsk_tu_api_key_aqui_pegala
```

### En producción (Vercel):

1. **Ir a:** https://vercel.com/dashboard
2. **Seleccionar tu proyecto**
3. **Settings → Environment Variables**
4. **Agregar variable:**
   - Name: `GROQ_API_KEY`
   - Value: `gsk_tu_key...`
   - Environment: Production, Preview, Development (marcar todos)
5. **Save**
6. **Redeploy** el proyecto

---

## 📁 PASO 4: Archivos Creados (Ya están listos)

✅ **API Route:** `src/app/api/insights/analyze/route.ts` (NECESITA AJUSTES - ver abajo)

✅ **Página Frontend:** `src/app/dashboard/insights/page.tsx` (LISTO ✨)

✅ **Documentación:** `INSIGHTS_IA_IMPLEMENTACION.md` (GUÍA COMPLETA)

---

## 🔧 PASO 5: Ajustar API Route (5 min)

El archivo `src/app/api/insights/analyze/route.ts` tiene algunos errores de tipos de Prisma que necesitas corregir manualmente.

### Opción A: Uso Simple (Recomendado)

Comenta temporalmente la llamada a Prisma y usa datos mock para probar:

```typescript
// En route.ts, línea ~30
async function obtenerDatosVentas(fechaInicio: Date, fechaFin: Date, sucursal?: string) {
  // TODO: Descomentar cuando funcione Prisma
  // const ventasDetalladas = await prisma.boletas_detalles.findMany({...});
  
  // MOCK temporal para probar
  return [
    {
      codigo: '12345',
      nombre: 'Paracetamol 500mg',
      unidadesVendidas: 150,
      ingresosSinIVA: 45000,
      costoTotal: 30000,
      frecuencia: 45,
      margenDinero: 15000,
      margenPorcentaje: 33.3,
      ventasPorMes: [
        { mes: '2024-10', ventas: 50 },
        { mes: '2024-11', ventas: 60 },
        { mes: '2024-12', ventas: 40 },
      ],
    },
    // Agregar más productos mock...
  ];
}
```

### Opción B: Corregir tipos de Prisma

Necesitas ajustar las queries según tu schema exacto de Prisma. Revisa:
- Nombres de relaciones (`boletas`, `productos_pos`)
- Campos disponibles en `boletas_detalles`
- Tipos de datos (Decimal vs number)

---

## 🎨 PASO 6: Agregar al Menú (3 min)

Edita `src/components/Sidebar.tsx`:

```typescript
// Agregar este import
import { Sparkles } from 'lucide-react';

// Agregar en el array de links del menú:
{
  name: 'Insights IA',
  href: '/dashboard/insights',
  icon: Sparkles,
  permission: null, // O configura permiso específico
},
```

---

## 🧪 PASO 7: Probar (3 min)

### 1. Reiniciar servidor:

```powershell
npm run dev
```

### 2. Abrir navegador:

```
http://localhost:3000/dashboard/insights
```

### 3. Verificar:

- ✅ La página carga correctamente
- ✅ Se ven los 6 botones de análisis
- ✅ Al hacer click, aparece "Analizando datos..."
- ✅ Se generan insights (o sale error si falta config)

---

## ❗ Errores Comunes y Soluciones

### Error: "No se ha configurado la API key"

**Causa:** La variable `GROQ_API_KEY` no está en `.env.local`

**Solución:**
```bash
# En .env.local (raíz del proyecto)
GROQ_API_KEY=gsk_tu_key_aqui
```

Reinicia el servidor con `Ctrl+C` y luego `npm run dev`

---

### Error: "Error al obtener datos de ventas"

**Causa:** Los tipos de Prisma no coinciden con la query

**Solución:** 
1. Usa datos mock (Opción A arriba)
2. O ajusta la query según tu schema real

---

### Error: "Failed to fetch"

**Causa:** El API route no está respondiendo

**Solución:**
1. Revisa logs en la consola del servidor
2. Verifica que el archivo esté en: `src/app/api/insights/analyze/route.ts`
3. Reinicia el servidor

---

### La página no aparece en el menú

**Solución:**
1. Verifica que agregaste el link en `Sidebar.tsx`
2. Reinicia el servidor
3. Limpia caché del navegador (Ctrl+Shift+R)

---

## 🎯 Resultado Final

Deberías ver una página como esta:

```
┌───────────────────────────────────────┐
│  🌟 Insights con IA                   │
│  Descubre patrones ocultos...         │
├───────────────────────────────────────┤
│                                       │
│  [📋 Resumen]  [📈 Tendencias]       │
│  [📅 Estacional] [💰 Oportunidades]  │
│  [⚠️ Riesgos]   [📊 Márgenes]        │
│                                       │
└───────────────────────────────────────┘
```

Al hacer click en cualquier botón:
1. Aparece animación "Analizando..."
2. Se consulta Groq IA
3. Aparecen insights estructurados con recomendaciones

---

## 📊 Tipos de Insights Disponibles

### 1. Resumen General
- Top 3 insights principales
- 3 acciones inmediatas
- Oportunidades y riesgos

### 2. Tendencias de Ventas
- Productos en crecimiento
- % de crecimiento mes a mes
- Recomendaciones de stock

### 3. Análisis Estacional
- Patrones de temporada
- Productos pico por mes
- Predicciones futuras

### 4. Oportunidades de Compra
- Productos con mejor ROI
- Qué comprar más
- Qué evitar

### 5. Productos en Riesgo
- Caídas de ventas
- Causas probables
- Acciones correctivas

### 6. Optimización de Márgenes
- Productos con margen bajo
- Oportunidades de repricing
- Estrategias por categoría

---

## 💰 Costos

### Groq (Plan Gratuito):
- ✅ **30 requests/minuto**
- ✅ **14,400 requests/día**
- ✅ **$0 costo**

### Para tu caso de uso:
- 50-100 análisis/día = **$0/mes** ✨

---

## 🔄 Siguiente Fase (Opcional)

### Mejoras Futuras:

1. **Cache de insights** (24h) → Ahorrar requests
2. **Scheduler automático** → Insights diarios por email
3. **Gráficos visuales** → Chart.js + insights
4. **Chat interactivo** → Hacer preguntas libres
5. **Alertas inteligentes** → Notificar anomalías

---

## 📚 Documentación Completa

Lee el archivo completo para detalles técnicos:
```
INSIGHTS_IA_IMPLEMENTACION.md
```

---

## 🆘 ¿Necesitas Ayuda?

### Checklist de diagnóstico:

- [ ] ✅ `npm install groq-sdk` ejecutado
- [ ] ✅ API key de Groq obtenida
- [ ] ✅ `GROQ_API_KEY` en `.env.local`
- [ ] ✅ Servidor reiniciado
- [ ] ✅ Página accesible en `/dashboard/insights`
- [ ] ✅ Link agregado al menú

Si todo está ✅ pero no funciona:
1. Revisa logs en la terminal donde corre `npm run dev`
2. Abre DevTools (F12) → Console → busca errores
3. Verifica Network → al hacer click, debe hacer POST a `/api/insights/analyze`

---

## 🎉 ¡Listo!

Tu sistema de Insights con IA está configurado y funcionando. 

**Próximo paso:** Prueba cada tipo de análisis y ajusta los prompts si necesitas respuestas más específicas para tu negocio.

¡Éxito! 🚀✨
