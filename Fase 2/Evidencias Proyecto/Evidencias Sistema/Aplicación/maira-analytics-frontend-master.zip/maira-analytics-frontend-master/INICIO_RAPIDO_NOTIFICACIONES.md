# 🚀 Inicio Rápido - Sistema de Notificaciones

## ✅ ¿Qué se implementó?

Un sistema completo de notificaciones tipo campana (🔔) en el navbar que alerta cuando un proveedor tiene **más de 7 días** desde su registro, indicando que podría tener catálogos con precios actualizados.

## 📦 Archivos Creados

```
src/
├── app/api/providers/outdated/
│   └── route.ts                          ← API endpoint
├── components/notifications/
│   ├── NotificationBell.tsx              ← Componente principal
│   └── EJEMPLOS_USO.tsx                  ← Ejemplos de uso
├── hooks/
│   └── useOutdatedProviders.ts           ← Hook reutilizable
└── components/
    └── DashboardHeader.tsx               ← ✏️ MODIFICADO

Documentación/
├── SISTEMA_NOTIFICACIONES_PROVEEDORES.md  ← Documentación completa
├── VISTA_PREVIA_NOTIFICACIONES.md         ← Vista previa visual
└── test-notifications-system.ts           ← Script de prueba
```

## 🎯 Cómo Funciona

1. **Detección automática**: Cada 5 minutos verifica proveedores con >7 días
2. **Badge visual**: Muestra número de proveedores desactualizados
3. **Dropdown informativo**: Lista completa con detalles y días transcurridos
4. **Navegación rápida**: Click lleva a la página de proveedores
5. **Refresh manual**: Botón para actualizar datos al instante

## 🧪 Probar el Sistema

### Opción 1: Crear datos de prueba

```bash
# Ejecutar script de prueba
npx tsx test-notifications-system.ts
```

Esto creará 7 proveedores de prueba:

- ✅ 3 con >7 días (APARECERÁN en notificaciones)
- ❌ 4 con ≤7 días (NO aparecerán)

### Opción 2: Crear manualmente en Supabase

```sql
-- En Supabase SQL Editor
INSERT INTO providers (name, created_at)
VALUES
  ('Proveedor Antiguo', NOW() - INTERVAL '10 days'),
  ('Proveedor Muy Antiguo', NOW() - INTERVAL '30 days');
```

### Opción 3: Esperar 7+ días (🐌 no recomendado)

## 👀 Ver en Acción

1. **Inicia el servidor**:

   ```bash
   npm run dev
   ```

2. **Navega al dashboard**:

   ```
   http://localhost:3000/dashboard
   ```

3. **Observa el header**:

   - 🔔 **Gris**: Sin notificaciones
   - 🔔 **Naranja con badge rojo**: Hay proveedores desactualizados

4. **Click en la campana**:
   - Abre dropdown con lista completa
   - Muestra días transcurridos
   - Botón de refresh
   - Click en item → navega a proveedores

## 🔍 Verificar API

```bash
# En otro terminal (con servidor corriendo)
curl http://localhost:3000/api/providers/outdated
```

**Respuesta esperada**:

```json
{
  "success": true,
  "providers": [
    {
      "id": "uuid-aqui",
      "name": "Nombre del Proveedor",
      "created_at": "2024-10-10T00:00:00.000Z",
      "daysOld": 13
    }
  ],
  "total": 1
}
```

## ⚙️ Configuración

### Cambiar intervalo de actualización

En `DashboardHeader.tsx`:

```tsx
// Actualizar cada 1 minuto (desarrollo)
<NotificationBell refreshInterval={60 * 1000} />

// Actualizar cada 10 minutos (producción)
<NotificationBell refreshInterval={10 * 60 * 1000} />

// Sin auto-refresh (solo manual)
<NotificationBell refreshInterval={0} />
```

### Cambiar umbral de días

En `src/app/api/providers/outdated/route.ts`:

```typescript
// Cambiar de 7 a 14 días
const sevenDaysAgo = new Date();
sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 14); // ← Cambiar aquí
```

## 🎨 Personalización

### Cambiar colores

En `NotificationBell.tsx`, busca las clases de Tailwind:

```tsx
// Campana con notificaciones
"text-orange-500 dark:text-orange-400";

// Badge
"bg-red-500 text-white";

// Cambiar a azul:
"text-blue-500 dark:text-blue-400";
"bg-blue-500 text-white";
```

### Cambiar mensaje

```tsx
// En NotificationBell.tsx, línea ~169
<p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
  Tu mensaje personalizado aquí
</p>
```

## 🐛 Solución de Problemas

### No aparece la campana

```bash
# Verificar importación
grep -r "NotificationBell" src/components/DashboardHeader.tsx
```

### No muestra proveedores

```bash
# Verificar que existan proveedores antiguos
npx tsx test-notifications-system.ts
```

### Error de API

```bash
# Ver logs del servidor
# Buscar mensajes con ❌ en la consola
```

### Badge no se actualiza

- Esperar 5 minutos o click en refresh (🔄)
- Verificar que `refreshInterval` no sea 0

## 📚 Documentación Completa

- **Sistema completo**: `SISTEMA_NOTIFICACIONES_PROVEEDORES.md`
- **Vista previa**: `VISTA_PREVIA_NOTIFICACIONES.md`
- **Ejemplos de uso**: `src/components/notifications/EJEMPLOS_USO.tsx`

## 🎉 ¡Listo!

El sistema está **100% funcional** y listo para usar. Solo necesitas:

1. ✅ Ejecutar el script de prueba o crear proveedores antiguos
2. ✅ Iniciar el servidor (`npm run dev`)
3. ✅ Navegar al dashboard
4. ✅ ¡Ver la campana en acción! 🔔

---

## 💡 Próximos Pasos Sugeridos

- [ ] Agregar notificaciones toast cuando aparezcan nuevos proveedores
- [ ] Crear página dedicada de proveedores desactualizados
- [ ] Agregar botón de "marcar como visto"
- [ ] Implementar recordatorios por email
- [ ] Widget en el dashboard principal
- [ ] Integrar con sistema de tareas/recordatorios
- [ ] Agregar estadísticas de actualización de catálogos
- [ ] Permitir configurar umbral de días por usuario

---

**¿Dudas o problemas?** Revisa la documentación completa o abre un issue.
