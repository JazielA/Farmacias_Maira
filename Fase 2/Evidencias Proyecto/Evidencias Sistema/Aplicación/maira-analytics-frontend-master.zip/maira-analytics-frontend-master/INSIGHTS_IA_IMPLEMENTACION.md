# 🤖 Implementación de Insights con IA para Farmacias Maira

## 📋 Tabla de Contenidos
1. [Arquitectura General](#arquitectura-general)
2. [Opción Recomendada: Groq](#opción-recomendada-groq)
3. [Alternativa: OpenAI](#alternativa-openai)
4. [Instalación y Configuración](#instalación-y-configuración)
5. [Estructura de Archivos](#estructura-de-archivos)
6. [Uso desde el Frontend](#uso-desde-el-frontend)
7. [Tipos de Insights Disponibles](#tipos-de-insights-disponibles)
8. [Costos y Límites](#costos-y-límites)

---

## 🏗️ Arquitectura General

```
┌──────────────────────────────────────────┐
│  Frontend: Dashboard Insights IA         │
│  - Botones de insights predefinidos     │
│  - Visualización de resultados           │
│  - Filtros de fecha y sucursal          │
└─────────────┬────────────────────────────┘
              │
              ▼
┌──────────────────────────────────────────┐
│  API Route: /api/insights/analyze        │
│  1. Recibe tipo de insight solicitado   │
│  2. Consulta Supabase (Prisma)          │
│  3. Agrega y procesa datos              │
│  4. Construye prompt para IA            │
│  5. Llama a Groq/OpenAI                 │
│  6. Parsea y retorna insights           │
└─────────────┬────────────────────────────┘
              │
     ┌────────┴────────┐
     ▼                 ▼
┌─────────┐     ┌────────────┐
│Supabase │     │ Groq API   │
│(Prisma) │     │(IA Gratis) │
└─────────┘     └────────────┘
```

---

## 🚀 Opción Recomendada: Groq

### ¿Por qué Groq?
- ✅ **100% GRATIS** hasta 30 req/min (suficiente para tu caso)
- ✅ **ULTRA RÁPIDO** (500 tokens/segundo vs 20-40 de OpenAI)
- ✅ Modelos open-source de calidad (Llama 3.1 70B)
- ✅ API compatible con OpenAI
- ✅ Perfecto para análisis de datos estructurados
- ✅ No necesitas tarjeta de crédito para empezar

### Características de Groq:
- **Modelo recomendado:** `llama-3.1-70b-versatile`
- **Límite gratuito:** 30 req/min, 14,400/día
- **Context window:** 128K tokens
- **Costo adicional:** $0 (gratis)

---

## 💰 Alternativa: OpenAI

Si prefieres OpenAI (más confiable, mejor razonamiento):

### Características:
- **Modelo recomendado:** `gpt-3.5-turbo` (económico)
- **Costo:** ~$0.002 por 1K tokens
- **Estimado mensual:** $5-20 para tu caso de uso
- **Ventajas:** Mejor comprensión de contexto complejo

### Configuración OpenAI:
```typescript
import OpenAI from 'openai';

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

const completion = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo',
  messages: [/* ... */],
  temperature: 0.3,
});
```

---

## 🛠️ Instalación y Configuración

### Paso 1: Instalar Dependencias

```powershell
# Para Groq (Recomendado - GRATIS)
npm install groq-sdk

# O para OpenAI (si prefieres)
npm install openai
```

### Paso 2: Obtener API Key

#### Para Groq (Gratis):
1. Ve a https://console.groq.com
2. Crea una cuenta (email + contraseña)
3. Ve a "API Keys"
4. Crea una nueva key
5. Cópiala

#### Para OpenAI (Pago):
1. Ve a https://platform.openai.com
2. Crea una cuenta
3. Agrega método de pago
4. Ve a "API Keys"
5. Crea una nueva key

### Paso 3: Configurar Variables de Entorno

Edita tu archivo `.env.local`:

```bash
# Para Groq (Opción recomendada)
GROQ_API_KEY=gsk_tu_api_key_aqui

# O para OpenAI
OPENAI_API_KEY=sk-tu_api_key_aqui
```

⚠️ **IMPORTANTE:** Nunca subas estas keys a Git. Asegúrate de que `.env.local` esté en `.gitignore`.

### Paso 4: Configurar en Vercel

Cuando despliegues a producción:

1. Ve a tu proyecto en Vercel
2. Settings → Environment Variables
3. Agrega: `GROQ_API_KEY` = tu_key
4. Redeploy

---

## 📁 Estructura de Archivos

### Archivos a Crear:

```
src/
├── app/
│   ├── api/
│   │   └── insights/
│   │       └── analyze/
│   │           └── route.ts          # ✅ API Route principal
│   └── dashboard/
│       └── insights/
│           └── page.tsx               # 📄 Página de Insights IA
├── components/
│   └── insights/
│       ├── InsightCard.tsx            # 💬 Card para mostrar insights
│       ├── InsightSelector.tsx        # 🎛️ Selector de tipo de insight
│       └── InsightChart.tsx           # 📊 Gráficos opcionales
└── lib/
    └── insights-prompts.ts            # 📝 Prompts reutilizables (opcional)
```

---

## 🎯 Tipos de Insights Disponibles

### 1. **Tendencias de Ventas** (`tendencias-ventas`)
- Productos con crecimiento sostenido
- Porcentaje de crecimiento mes a mes
- Recomendaciones de stock

**Ejemplo de respuesta:**
```json
{
  "productos_tendencia_alza": [
    {
      "nombre": "Paracetamol 500mg",
      "crecimiento_porcentual": 35,
      "razon": "Temporada de gripes en aumento",
      "recomendacion_stock": "Aumentar inventario en 40%"
    }
  ],
  "resumen": "3 productos muestran crecimiento superior al 30%..."
}
```

### 2. **Análisis Estacional** (`estacionalidad`)
- Productos con patrones estacionales
- Predicción de ventas futuras
- Preparación para temporada alta

### 3. **Oportunidades de Compra** (`oportunidades-compra`)
- Productos con mejor ROI
- Productos a evitar
- Balance margen vs volumen

### 4. **Productos en Riesgo** (`productos-riesgo`)
- Productos con caída en ventas
- Causas probables
- Acciones correctivas

### 5. **Optimización de Márgenes** (`analisis-margen`)
- Productos con margen bajo
- Oportunidades de repricing
- Estrategias por categoría

### 6. **Resumen General** (`resumen-general`)
- Top 3 insights del período
- Acciones inmediatas
- Overview ejecutivo

---

## 💻 Uso desde el Frontend

### Componente de Ejemplo: `InsightsPage.tsx`

```typescript
'use client';

import { useState } from 'react';

type InsightType = 
  | 'tendencias-ventas'
  | 'estacionalidad'
  | 'oportunidades-compra'
  | 'productos-riesgo'
  | 'analisis-margen'
  | 'resumen-general';

export default function InsightsPage() {
  const [loading, setLoading] = useState(false);
  const [insights, setInsights] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const handleGenerateInsight = async (tipo: InsightType) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/insights/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          insightType: tipo,
          // Opcional: fechas específicas
          fechaInicio: '2024-01-01',
          fechaFin: '2024-12-31',
          sucursal: 'todas',
        }),
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error);
      }

      setInsights(data.data);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-6">🤖 Insights con IA</h1>

      {/* Botones de insights */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <button
          onClick={() => handleGenerateInsight('tendencias-ventas')}
          disabled={loading}
          className="p-4 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          📈 Tendencias de Ventas
        </button>

        <button
          onClick={() => handleGenerateInsight('estacionalidad')}
          disabled={loading}
          className="p-4 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
        >
          📅 Análisis Estacional
        </button>

        <button
          onClick={() => handleGenerateInsight('oportunidades-compra')}
          disabled={loading}
          className="p-4 bg-green-600 text-white rounded-lg hover:bg-green-700"
        >
          💰 Oportunidades de Compra
        </button>

        <button
          onClick={() => handleGenerateInsight('productos-riesgo')}
          disabled={loading}
          className="p-4 bg-red-600 text-white rounded-lg hover:bg-red-700"
        >
          ⚠️ Productos en Riesgo
        </button>

        <button
          onClick={() => handleGenerateInsight('analisis-margen')}
          disabled={loading}
          className="p-4 bg-yellow-600 text-white rounded-lg hover:bg-yellow-700"
        >
          📊 Optimizar Márgenes
        </button>

        <button
          onClick={() => handleGenerateInsight('resumen-general')}
          disabled={loading}
          className="p-4 bg-gray-600 text-white rounded-lg hover:bg-gray-700"
        >
          📋 Resumen General
        </button>
      </div>

      {/* Loading state */}
      {loading && (
        <div className="flex items-center justify-center p-8">
          <div className="animate-spin h-12 w-12 border-4 border-blue-600 border-t-transparent rounded-full" />
          <p className="ml-4 text-gray-600">Analizando datos con IA...</p>
        </div>
      )}

      {/* Error state */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
          <p className="text-red-800">❌ Error: {error}</p>
        </div>
      )}

      {/* Resultados */}
      {insights && !loading && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold mb-4">
            Resultados del Análisis
          </h2>

          <div className="bg-gray-50 rounded p-4 mb-4">
            <p className="text-sm text-gray-600">
              Período: {insights.metadata.fechaInicio} - {insights.metadata.fechaFin}
            </p>
            <p className="text-sm text-gray-600">
              Total productos: {insights.metadata.totalProductos}
            </p>
          </div>

          {/* Mostrar insights en formato bonito */}
          <pre className="bg-gray-100 rounded p-4 overflow-auto text-sm">
            {JSON.stringify(insights.insights, null, 2)}
          </pre>

          {/* Aquí puedes crear componentes más bonitos para cada tipo */}
        </div>
      )}
    </div>
  );
}
```

---

## 📊 Costos y Límites

### Groq (Recomendado)

| Plan | Requests/min | Requests/día | Tokens/min | Costo |
|------|--------------|--------------|------------|-------|
| Free | 30 | 14,400 | 6,000 | $0 |
| Paid | 30 | Ilimitado | 30,000 | $0.05-0.27/1M tokens |

**Para tu caso:**
- Estimado: 50-100 requests/día
- Costo: **$0/mes** (dentro del plan gratuito)

### OpenAI

| Modelo | Input | Output | Estimado/mes |
|--------|-------|--------|--------------|
| GPT-3.5 Turbo | $0.0005/1K | $0.0015/1K | $5-15 |
| GPT-4 Turbo | $0.01/1K | $0.03/1K | $30-80 |

---

## 🚦 Próximos Pasos

### 1. **Instalación Inicial**
```powershell
cd "C:\Users\Thomidev\Desktop\Programación\maira-analytics-frontend"
npm install groq-sdk
```

### 2. **Configurar API Key**
- Crear cuenta en https://console.groq.com
- Copiar API key
- Agregar a `.env.local`:
```
GROQ_API_KEY=gsk_tu_key_aqui
```

### 3. **Crear API Route**
- Ya está creado en: `src/app/api/insights/analyze/route.ts`
- Necesita ajustes para tipos de Prisma

### 4. **Crear Página de Insights**
- Crear: `src/app/dashboard/insights/page.tsx`
- Usar el ejemplo de código de arriba

### 5. **Agregar al Menú**
- Editar `Sidebar.tsx` para agregar link a Insights

### 6. **Probar**
```powershell
npm run dev
```
- Visitar: http://localhost:3000/dashboard/insights

---

## 🎓 Recursos Adicionales

### Documentación:
- **Groq:** https://console.groq.com/docs
- **OpenAI:** https://platform.openai.com/docs
- **Prompts para retail:** https://www.promptingguide.ai

### Mejoras Futuras:
1. **Cache de insights** (guardar en Supabase para no regenerar)
2. **Scheduler automático** (generar insights diarios con Vercel Cron)
3. **Notificaciones** (email con insights importantes)
4. **Chat interactivo** (hacer preguntas libres)
5. **Gráficos visuales** (Chart.js con insights)

---

## ❓ FAQ

### ¿Por qué no usar Ollama?
Ollama es solo para ejecución local, no tiene API en la nube. Necesitarías un servidor aparte.

### ¿Groq o OpenAI?
- **Groq:** Gratis, rápido, perfecto para empezar
- **OpenAI:** Mejor calidad en respuestas complejas, costo bajo

### ¿Qué pasa si excedo el límite gratuito de Groq?
Puedes cambiar a plan pago ($0.05-0.27 por 1M tokens) o implementar cola de requests.

### ¿Cómo proteger la API key?
- Nunca exponerla en el frontend
- Solo usar en API Routes (server-side)
- Agregar a `.gitignore`
- Rotar keys cada 3-6 meses

---

## 📞 Soporte

Si necesitas ayuda:
1. Revisa los logs en Vercel
2. Verifica que la API key esté configurada
3. Revisa el schema de Prisma para los tipos correctos

¡Éxito con la implementación! 🚀
