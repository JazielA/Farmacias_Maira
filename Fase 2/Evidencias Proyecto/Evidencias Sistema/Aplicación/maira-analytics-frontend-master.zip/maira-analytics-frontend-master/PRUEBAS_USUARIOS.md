# 🧪 Guía de Pruebas - Sistema de Habilitación/Deshabilitación de Usuarios

## Funcionalidad Implementada
Sistema completo para deshabilitar y habilitar usuarios temporalmente, con bloqueo automático de acceso.

---

## ✅ Pruebas a Realizar

### 1. **Verificar que el campo existe en la base de datos**

```sql
-- Ejecutar en Supabase SQL Editor
SELECT id, email, is_active FROM users LIMIT 5;
```

Deberías ver la columna `is_active` con valores `true` para todos los usuarios existentes.

---

### 2. **Probar la interfaz de usuarios**

1. Inicia sesión como administrador en: http://localhost:3000/login
2. Ve a: http://localhost:3000/dashboard/usuarios
3. Verifica que veas:
   - ✅ Columna **"Estado"** con badges:
     - 🟢 **"● Activo"** (verde) para usuarios activos
     - 🔴 **"● Inactivo"** (rojo) para usuarios deshabilitados
   - ✅ Botones en la columna de acciones:
     - **"🔒 Deshabilitar"** (naranja) para usuarios activos
     - **"✅ Habilitar"** (verde) para usuarios inactivos

---

### 3. **Deshabilitar un usuario de prueba**

**IMPORTANTE:** Asegúrate de tener al menos 2 usuarios en el sistema para esta prueba.

1. En la página de usuarios, crea un nuevo usuario de prueba si no existe:
   - Email: `test@example.com`
   - Password: `test123`
   - Rol: Viewer o cualquier otro

2. Click en el botón **"🔒 Deshabilitar"** para el usuario `test@example.com`

3. Verifica que:
   - ✅ Aparece un diálogo de confirmación
   - ✅ Después de confirmar, el badge cambia a **"● Inactivo"** (rojo)
   - ✅ El botón cambia a **"✅ Habilitar"** (verde)
   - ✅ La fila se muestra con fondo gris y opacidad reducida

---

### 4. **Verificar bloqueo de inicio de sesión**

**Caso A: Usuario deshabilitado intenta iniciar sesión**

1. Cierra tu sesión actual (Click en tu nombre → Cerrar Sesión)
2. En la página de login, intenta iniciar sesión con el usuario deshabilitado:
   - Email: `test@example.com`
   - Password: `test123`

3. **Resultado esperado:**
   - ❌ No debe permitir el acceso
   - ❌ Debe mostrar mensaje: "Tu cuenta ha sido deshabilitada. Contacta al administrador."

---

**Caso B: Usuario activo en sesión es deshabilitado**

1. Abre 2 navegadores diferentes (por ejemplo, Chrome y Firefox)
2. En ambos navegadores:
   - Navegador 1: Inicia sesión como admin
   - Navegador 2: Inicia sesión con `test@example.com`

3. En el Navegador 1 (admin):
   - Ve a `/dashboard/usuarios`
   - Deshabilita al usuario `test@example.com`

4. En el Navegador 2 (usuario deshabilitado):
   - Espera 30 segundos (tiempo de verificación automática)
   - O navega a otra página del dashboard

5. **Resultado esperado:**
   - ❌ El usuario debe ser desconectado automáticamente
   - ❌ Debe ser redirigido al login con mensaje de cuenta deshabilitada

---

### 5. **Habilitar usuario nuevamente**

1. Inicia sesión como administrador
2. Ve a `/dashboard/usuarios`
3. Busca el usuario deshabilitado (tendrá badge "● Inactivo" rojo)
4. Click en **"✅ Habilitar"**
5. Verifica que:
   - ✅ Badge cambia a **"● Activo"** (verde)
   - ✅ Botón cambia a **"🔒 Deshabilitar"** (naranja)
   - ✅ La fila vuelve a tener apariencia normal

6. Cierra sesión e intenta iniciar sesión con ese usuario nuevamente
7. **Resultado esperado:**
   - ✅ Debe permitir el acceso correctamente

---

### 6. **Verificar restricción de seguridad**

1. Como administrador, intenta deshabilitar tu propia cuenta
2. **Resultado esperado:**
   - ❌ Debe mostrar error: "No puedes deshabilitarte a ti mismo"

---

### 7. **Verificar endpoint API directamente**

```bash
# Verificar el endpoint de check-status (sin autenticación)
curl http://localhost:3000/api/user/check-status

# Debería retornar: {"error":"No autorizado","isActive":false}
```

---

## 🔍 Verificación en la Base de Datos

Puedes verificar directamente el estado en la base de datos:

```sql
-- Ver usuarios y su estado
SELECT 
  email, 
  is_active,
  created_at 
FROM users 
ORDER BY created_at DESC;

-- Cambiar manualmente el estado (solo para pruebas)
UPDATE users 
SET is_active = false 
WHERE email = 'test@example.com';

-- Restaurar estado
UPDATE users 
SET is_active = true 
WHERE email = 'test@example.com';
```

---

## 🐛 Solución de Problemas

### Problema: Usuario deshabilitado aún puede iniciar sesión

**Solución:**
1. Verifica que el campo `is_active` existe en la BD:
   ```sql
   SELECT is_active FROM users LIMIT 1;
   ```
2. Verifica que el usuario tenga `is_active = false`:
   ```sql
   SELECT email, is_active FROM users WHERE email = 'test@example.com';
   ```
3. Limpia el caché del navegador y prueba en modo incógnito
4. Verifica que el servidor esté corriendo la última versión del código

### Problema: Error al deshabilitar usuario

**Solución:**
1. Verifica permisos del usuario actual (debe tener permiso de `write` en `usuarios`)
2. Revisa la consola del navegador para ver errores específicos
3. Revisa los logs del servidor

### Problema: Hook useUserStatus causa loop infinito

**Solución:**
1. Verifica que el intervalo de 30 segundos no esté creando múltiples intervalos
2. Asegúrate de que el componente se desmonte correctamente

---

## 📊 Métricas de Éxito

✅ Todas las pruebas pasaron si:
- Los usuarios deshabilitados no pueden iniciar sesión
- Los usuarios activos en sesión son desconectados al ser deshabilitados
- Los usuarios pueden ser habilitados nuevamente sin problemas
- La interfaz muestra correctamente el estado de cada usuario
- No se pueden deshabilitar a sí mismos los administradores

---

## 🎯 Funcionalidad Completa

```
┌─────────────────────────────────────────────────────────────┐
│ FLUJO COMPLETO                                              │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. Admin deshabilita usuario → isActive = false           │
│  2. Usuario intenta login → Verificación en AuthContext    │
│  3. Si isActive = false → Rechazar y mostrar mensaje       │
│  4. Usuario activo navegando → Hook verifica cada 30s      │
│  5. Si detecta isActive = false → Cerrar sesión automática │
│  6. Admin habilita usuario → isActive = true               │
│  7. Usuario puede iniciar sesión nuevamente                │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```
