# 🔔 Sistema de Notificaciones para Proveedores Desactualizados

## Descripción General

Sistema implementado para alertar a los usuarios sobre proveedores que tienen más de 7 días desde su registro y que podrían tener catálogos de precios actualizados disponibles.

## 📁 Archivos Creados

### 1. API Endpoint

**Ruta:** `/src/app/api/providers/outdated/route.ts`

Endpoint que retorna la lista de proveedores con más de 7 días desde su creación.

**URL:** `GET /api/providers/outdated`

**Respuesta:**

```json
{
  "success": true,
  "providers": [
    {
      "id": "uuid",
      "name": "Nombre del Proveedor",
      "created_at": "2024-10-10T00:00:00.000Z",
      "daysOld": 13
    }
  ],
  "total": 1
}
```

### 2. Hook Personalizado

**Ruta:** `/src/hooks/useOutdatedProviders.ts`

Hook reutilizable para obtener y gestionar proveedores desactualizados.

**Uso:**

```tsx
const { providers, loading, error, count, refresh } =
  useOutdatedProviders(300000); // 5 minutos
```

**Propiedades:**

- `providers`: Array de proveedores desactualizados
- `loading`: Estado de carga
- `error`: Mensaje de error si existe
- `count`: Número total de notificaciones
- `refresh()`: Función para actualizar manualmente

### 3. Componente de Notificación

**Ruta:** `/src/components/notifications/NotificationBell.tsx`

Componente visual de campana con badge de notificaciones.

**Características:**

- ✅ Badge animado con contador de notificaciones
- ✅ Dropdown con lista detallada de proveedores
- ✅ Actualización automática cada 5 minutos (configurable)
- ✅ Botón de refresh manual
- ✅ Navegación a página de proveedores
- ✅ Estados de carga y error
- ✅ Diseño responsive con dark mode

**Props:**

```tsx
interface NotificationBellProps {
  refreshInterval?: number; // Milisegundos (default: 5 minutos)
}
```

### 4. Integración en Header

**Modificado:** `/src/components/DashboardHeader.tsx`

Se agregó la campana de notificaciones en el header del dashboard.

## 🎨 Características del Sistema

### Visualización

- **Campana Gris**: Sin notificaciones
- **Campana Naranja**: Con notificaciones pendientes
- **Badge Rojo Pulsante**: Muestra el contador (máx. 9+)
- **Dropdown Elegante**: Lista completa con detalles

### Funcionalidad

1. **Carga Automática**: Al montar el componente
2. **Refresh Automático**: Cada 5 minutos por defecto
3. **Refresh Manual**: Botón con ícono giratorio
4. **Click Outside**: Cierra el dropdown al hacer clic fuera
5. **Navegación**: Click en notificación lleva a `/dashboard/suppliers`

### Estados

- **Cargando**: Spinner animado
- **Error**: Mensaje de error con botón de reintentar
- **Sin notificaciones**: Mensaje "Todo al día"
- **Con notificaciones**: Lista completa con detalles

## 🚀 Uso

### Básico (en DashboardHeader)

```tsx
import NotificationBell from "@/components/notifications/NotificationBell";

<NotificationBell />;
```

### Personalizado

```tsx
// Actualizar cada 10 minutos
<NotificationBell refreshInterval={10 * 60 * 1000} />

// Actualizar cada 1 minuto (desarrollo)
<NotificationBell refreshInterval={60 * 1000} />

// Sin actualización automática
<NotificationBell refreshInterval={0} />
```

### Usar el Hook en Otros Componentes

```tsx
import { useOutdatedProviders } from "@/hooks/useOutdatedProviders";

function MiComponente() {
  const { providers, count, loading, error, refresh } = useOutdatedProviders();

  return (
    <div>{count > 0 && <p>Tienes {count} proveedores desactualizados</p>}</div>
  );
}
```

## 📊 Criterios de Notificación

Un proveedor se considera "desactualizado" cuando:

- ✅ Han pasado **más de 7 días** desde su fecha de registro (`created_at`)
- ✅ Aparece en la tabla `providers`

## 🔄 Flujo de Datos

```
Component Mount
    ↓
useOutdatedProviders Hook
    ↓
Fetch /api/providers/outdated
    ↓
Query Supabase (providers con created_at < hace 7 días)
    ↓
Calcular días transcurridos
    ↓
Retornar lista con daysOld
    ↓
Actualizar UI (Badge + Dropdown)
    ↓
Auto-refresh cada 5 minutos
```

## 🎯 Mejoras Futuras Sugeridas

1. **Notificaciones Toast**: Mostrar toast cuando aparezcan nuevos proveedores
2. **Sonido**: Agregar sonido opcional al recibir notificaciones
3. **Persistencia**: Marcar notificaciones como "vistas"
4. **Filtros**: Permitir filtrar por días (7, 14, 30 días)
5. **Exportar**: Botón para exportar lista de proveedores desactualizados
6. **Email**: Enviar recordatorio automático por email
7. **Dashboard Widget**: Agregar widget en el dashboard principal
8. **Configuración**: Permitir al usuario configurar el umbral de días

## 🧪 Testing

Para probar el sistema:

1. **Crear proveedores de prueba**:

```sql
-- En Supabase SQL Editor
INSERT INTO providers (name, created_at)
VALUES
  ('Proveedor Antiguo 1', NOW() - INTERVAL '10 days'),
  ('Proveedor Antiguo 2', NOW() - INTERVAL '15 days'),
  ('Proveedor Nuevo', NOW());
```

2. **Verificar API**:

```bash
curl http://localhost:3000/api/providers/outdated
```

3. **Verificar en UI**:
   - Navegar al dashboard
   - Observar la campana en el header
   - Click para ver el dropdown
   - Verificar contador y lista

## 📝 Notas Técnicas

- **Performance**: La query está optimizada con índice en `created_at`
- **Caché**: No se implementó caché para mantener datos en tiempo real
- **Estado Global**: No usa Redux/Zustand, cada instancia maneja su estado
- **TypeScript**: Totalmente tipado con interfaces claras
- **Accesibilidad**: Incluye títulos y aria-labels (mejorable)

## 🐛 Troubleshooting

### La campana no aparece

- Verificar que `NotificationBell` esté importado en `DashboardHeader`
- Revisar consola para errores de importación

### No muestra proveedores

- Verificar que existan proveedores con más de 7 días
- Revisar permisos de la tabla `providers` en Supabase
- Verificar autenticación del usuario

### Errores de CORS

- Asegurar que el endpoint esté en `/src/app/api/`
- Verificar que Next.js esté corriendo correctamente

## ✅ Checklist de Implementación

- [x] Crear endpoint API `/api/providers/outdated`
- [x] Crear hook `useOutdatedProviders`
- [x] Crear componente `NotificationBell`
- [x] Integrar en `DashboardHeader`
- [x] Documentar funcionalidad
- [x] Agregar tipos TypeScript
- [x] Implementar dark mode
- [x] Agregar estados de carga/error
- [x] Agregar refresh manual
- [x] Implementar auto-refresh

## 🎉 ¡Sistema Listo!

El sistema de notificaciones está completamente funcional y listo para usar.
Los usuarios ahora serán alertados automáticamente sobre proveedores que necesitan actualización.
