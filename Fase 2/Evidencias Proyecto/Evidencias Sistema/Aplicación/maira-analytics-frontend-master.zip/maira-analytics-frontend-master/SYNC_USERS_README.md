# 🔄 Script de Sincronización de Usuarios

## Descripción

Este script sincroniza los IDs de usuarios entre Supabase Auth y tu base de datos local PostgreSQL, resolviendo problemas de IDs desincronizados que impiden que las funcionalidades de autenticación funcionen correctamente.

## ⚠️ IMPORTANTE - Antes de Ejecutar

1. **Haz un backup de tu base de datos**
   ```bash
   # Si usas Supabase, puedes hacer backup desde el dashboard
   # O exportar con pg_dump
   pg_dump -h your-db-host -U postgres -d postgres > backup.sql
   ```

2. **Asegúrate de que las variables de entorno estén configuradas**
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `DATABASE_URL`

## 🚀 Uso

### 1. Verificar estado actual de usuarios
```bash
npm run check:users
```

Este comando te mostrará todos los usuarios y su estado de `isActive`.

### 2. Ejecutar sincronización
```bash
npm run sync:users
```

## 📊 ¿Qué hace el script?

El script realiza las siguientes acciones:

### 1. **Usuarios en Supabase Auth pero NO en BD Local**
   - ✅ Los **crea** en la base de datos local con el ID de Supabase
   - ✅ Los marca como `isActive: true` por defecto

### 2. **Usuarios con IDs diferentes**
   - 🔄 **Actualiza** los posts del usuario al nuevo ID
   - 🔄 **Actualiza** el perfil del usuario al nuevo ID
   - 🔄 **Elimina** el registro antiguo
   - 🔄 **Crea** un nuevo registro con el ID correcto de Supabase
   - ✅ Preserva todos los datos (rol, estado, fechas)

### 3. **Usuarios ya sincronizados**
   - ✅ Los detecta y no hace cambios

### 4. **Usuarios en BD Local pero NO en Supabase Auth**
   - ⚠️  Los reporta como "huérfanos"
   - ℹ️  Los mantiene en la BD (no los elimina)

## 📝 Ejemplo de Salida

```
🔄 Iniciando sincronización de IDs entre Supabase Auth y BD Local...

📊 Usuarios en Supabase Auth: 6
📊 Usuarios en BD local: 6

✅ test1.@test.com - IDs ya sincronizados
✅ test@gmail.com - IDs ya sincronizados
✅ prueba@gmail.com - IDs ya sincronizados

🔄 Sincronizando user@example.com:
   Auth ID: b0a5b2dd-23d4-4589-96f5-bcf0a913ed56
   BD ID:   7938dfef-99f4-4255-840b-4058735f76a5 ❌ DIFERENTE
   📝 0 posts actualizados
   👤 Perfil actualizado
   ✅ ID sincronizado correctamente: b0a5b2dd-23d4-4589-96f5-bcf0a913ed56

🔄 Sincronizando manager@example.com:
   Auth ID: 813318aa-2608-4d38-9a8f-372a0d0ae5a5
   BD ID:   bf196652-6225-4a6a-a7ab-cf2913414e4a ❌ DIFERENTE
   ✅ ID sincronizado correctamente: 813318aa-2608-4d38-9a8f-372a0d0ae5a5

🔄 Sincronizando admin@example.com:
   Auth ID: d6373c0e-036c-4a54-a2ab-e546f0e46fef
   BD ID:   17132b6a-7e0e-4a09-8b42-aaddffa595b0 ❌ DIFERENTE
   ✅ ID sincronizado correctamente: d6373c0e-036c-4a54-a2ab-e546f0e46fef

============================================================
📊 RESUMEN DE SINCRONIZACIÓN
============================================================
✅ Ya sincronizados:      3
➕ Creados en BD:         0
🔄 IDs actualizados:      3
⚠️  Usuarios huérfanos:   0
❌ Errores:               0
============================================================

🎉 ¡Sincronización completada exitosamente!
```

## 🛠️ Solución de Problemas

### Error: "supabaseUrl is required"
**Causa:** Variables de entorno no configuradas.
**Solución:** Verifica que `.env.local` tenga las variables correctas.

### Error: "Foreign key constraint"
**Causa:** Hay relaciones que impiden actualizar los IDs.
**Solución:** El script maneja esto automáticamente actualizando posts y perfiles primero.

### Error: "Unique constraint violated"
**Causa:** Ya existe un usuario con ese ID.
**Solución:** El script usa transacciones para evitar esto, pero si persiste, contacta al equipo.

## 🔐 Seguridad

- ✅ El script usa **transacciones** para garantizar atomicidad
- ✅ Si hay un error, se hace **rollback** automático
- ✅ No elimina datos sin antes crear los nuevos registros
- ✅ Preserva todos los datos del usuario (rol, estado, fechas)

## 📚 Comandos Relacionados

```bash
# Ver estado de usuarios
npm run check:users

# Sincronizar IDs
npm run sync:users

# Abrir Prisma Studio para ver la BD
npm run db:studio

# Ver comparación detallada (script manual)
npx tsx compare-users.ts
```

## 🎯 Cuándo Ejecutar Este Script

Ejecuta este script si:

- ❌ Los usuarios deshabilitados pueden iniciar sesión
- ❌ El endpoint `/api/user/check-status` retorna "Usuario no encontrado"
- ❌ Los IDs de usuarios en BD local no coinciden con Supabase Auth
- ❌ Acabas de migrar usuarios de otro sistema
- ❌ Creaste usuarios manualmente en la BD

## ✅ Después de Ejecutar

1. Verifica que los usuarios pueden iniciar sesión correctamente
2. Prueba deshabilitar un usuario y verificar que no pueda iniciar sesión
3. Verifica que el endpoint `/api/user/check-status` funcione
4. Revisa que no haya usuarios duplicados

## 📞 Soporte

Si encuentras problemas:
1. Revisa los logs del script
2. Verifica las variables de entorno
3. Asegúrate de tener el backup de la BD
4. Contacta al equipo de desarrollo con los logs de error
