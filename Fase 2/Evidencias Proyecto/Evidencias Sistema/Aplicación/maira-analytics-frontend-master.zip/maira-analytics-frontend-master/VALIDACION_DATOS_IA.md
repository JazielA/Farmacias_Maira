# 🔍 Validación de Datos - Sistema de IA de Proveedores

## 📊 Fuentes de Datos (100% REALES)

### ✅ **NO usa datos simulados o hardcodeados**

### ✅ **SÍ usa datos reales de Supabase**

---

## 🗂️ Flujo Completo de Datos

```
┌─────────────────────────────────────────────────────────────┐
│                    FUENTE DE DATOS                           │
│                                                               │
│  Supabase PostgreSQL Database                                │
│  ├─ Tabla: providers                                         │
│  │  └─ Columnas: id, name, created_at                        │
│  │                                                            │
│  ├─ Tabla: products                                          │
│  │  └─ Columnas: id, name, ean                               │
│  │                                                            │
│  └─ Tabla: provider_prices                                   │
│     └─ Columnas: id, provider_id, product_id, price          │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              API: /api/compare-prices                        │
│                                                               │
│  1. Consulta: SELECT * FROM provider_prices                  │
│     JOIN products ON provider_prices.product_id = products.id│
│     JOIN providers ON provider_prices.provider_id = providers.id │
│                                                               │
│  2. Transforma: Formato LARGO → PIVOTE                       │
│     Antes:                                                    │
│     ┌────────────┬──────────┬────────┐                       │
│     │ Producto   │ Proveedor│ Precio │                       │
│     ├────────────┼──────────┼────────┤                       │
│     │ Paracetamol│ MEDIVEN  │ 10000  │                       │
│     │ Paracetamol│ Ethon    │  9500  │                       │
│     │ Paracetamol│ Cruz Verde│ 11000 │                       │
│     └────────────┴──────────┴────────┘                       │
│                                                               │
│     Después:                                                  │
│     {                                                         │
│       productId: "abc123",                                    │
│       productName: "Paracetamol 500mg",                       │
│       prices: {                                               │
│         "MEDIVEN": 10000,                                     │
│         "Ethon": 9500,                                        │
│         "Cruz Verde": 11000                                   │
│       }                                                       │
│     }                                                         │
│                                                               │
│  3. Retorna: JSON con productos y precios                    │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│         API: /api/providers/ai-analysis                      │
│                                                               │
│  1. Llama a: /api/compare-prices                             │
│                                                               │
│  2. Procesa cada producto:                                   │
│     • Calcula precio mínimo                                  │
│     • Calcula precio máximo                                  │
│     • Calcula precio promedio                                │
│     • Calcula diferencia máxima                              │
│     • Calcula % de diferencia                                │
│     • Identifica proveedor más barato                        │
│     • Identifica proveedor más caro                          │
│                                                               │
│  3. Agrega por proveedor:                                    │
│     • Total de productos                                     │
│     • Precio promedio                                        │
│     • Veces que es el más barato                             │
│     • Veces que es el más caro                               │
│     • % de competitividad                                    │
│                                                               │
│  4. Construye prompt para IA:                                │
│     "Eres experto en compras..."                             │
│     + Datos de proveedores                                   │
│     + Top 15 productos con mayor diferencia                  │
│     + Tarea específica según tipo de análisis                │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│              Groq IA (LLaMA 3.3 70B)                         │
│                                                               │
│  Recibe:                                                      │
│  • Contexto del negocio                                      │
│  • Datos de 3+ proveedores                                   │
│  • Datos de 250+ productos                                   │
│  • Precios reales actualizados                               │
│                                                               │
│  Procesa con:                                                │
│  • 70 mil millones de parámetros                             │
│  • Modelo especializado en razonamiento                      │
│  • Temperature: 0.3 (respuestas consistentes)                │
│                                                               │
│  Genera:                                                      │
│  • Insights específicos                                      │
│  • Recomendaciones accionables                               │
│  • Cálculos de ahorro                                        │
│  • Estrategias de negociación                                │
└────────────────────┬────────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────────┐
│            RESPUESTA AL USUARIO                              │
│                                                               │
│  JSON estructurado con:                                      │
│  • Oportunidades de ahorro                                   │
│  • Anomalías detectadas                                      │
│  • Recomendaciones de negociación                            │
│  • Análisis de diversificación                               │
│  • Plan de compras optimizado                                │
└─────────────────────────────────────────────────────────────┘
```

---

## 📋 Ejemplo Real de Datos

### **1. Datos RAW de Supabase:**

```sql
-- Tabla: provider_prices
provider_id | product_id | price
------------|------------|-------
uuid-1      | uuid-A     | 10000
uuid-2      | uuid-A     |  9500
uuid-3      | uuid-A     | 11000
uuid-1      | uuid-B     |  8000
uuid-2      | uuid-B     |  7500
```

### **2. Respuesta de `/api/compare-prices`:**

```json
{
  "providerNames": ["MEDIVEN", "Ethon", "Cruz Verde"],
  "productsData": [
    {
      "productId": "uuid-A",
      "productName": "Paracetamol 500mg x100",
      "ean": "7890123456789",
      "prices": {
        "MEDIVEN": 10000,
        "Ethon": 9500,
        "Cruz Verde": 11000
      }
    },
    {
      "productId": "uuid-B",
      "productName": "Ibuprofeno 400mg x100",
      "ean": "7890123456790",
      "prices": {
        "MEDIVEN": 8000,
        "Ethon": 7500
      }
    }
  ]
}
```

### **3. Datos Procesados por `/api/providers/ai-analysis`:**

```javascript
// Productos con cálculos
[
  {
    id: "uuid-A",
    nombre: "Paracetamol 500mg x100",
    precios: [
      { proveedor: "MEDIVEN", precio: 10000 },
      { proveedor: "Ethon", precio: 9500 },
      { proveedor: "Cruz Verde", precio: 11000 },
    ],
    precioMinimo: 9500,
    precioMaximo: 11000,
    precioPromedio: 10166.67,
    diferenciaMaxima: 1500, // $1,500 de diferencia
    porcentajeDiferencia: 15.79, // 15.79% de diferencia
    proveedorMasBarato: "Ethon", // ← Este es el recomendado
    proveedorMasCaro: "Cruz Verde",
  },
][
  // Proveedores con estadísticas
  ({
    nombre: "Ethon",
    totalProductos: 2,
    precioPromedio: 8500,
    precioTotal: 17000,
    vecesEsMasBarato: 2, // Ganó 2 de 2 veces
    vecesEsMasCaro: 0,
    porcentajeCompetitivo: 100, // 100% competitivo
  },
  {
    nombre: "MEDIVEN",
    totalProductos: 2,
    precioPromedio: 9000,
    precioTotal: 18000,
    vecesEsMasBarato: 0,
    vecesEsMasCaro: 0,
    porcentajeCompetitivo: 0, // 0% competitivo
  })
];
```

### **4. Prompt Enviado a Groq IA:**

```
Eres experto en compras para farmacias en Chile.

DATOS GENERALES:
- Total de proveedores: 3
- Total de productos: 250

PROVEEDORES:
[
  {
    "nombre": "Ethon",
    "totalProductos": 2,
    "precioPromedio": 8500,
    "vecesEsMasBarato": 2,
    "porcentajeCompetitivo": 100
  }
]

PRODUCTOS CON MAYORES DIFERENCIAS:
[
  {
    "nombre": "Paracetamol 500mg",
    "precioMinimo": 9500,
    "precioMaximo": 11000,
    "diferencia": 1500,
    "proveedorMasBarato": "Ethon"
  }
]

TAREA: Identifica OPORTUNIDADES DE AHORRO
Analiza diferencias de precio y genera recomendaciones...
```

### **5. Respuesta de Groq IA:**

```json
{
  "oportunidades": [
    {
      "producto": "Paracetamol 500mg x100",
      "proveedor_actual_probable": "MEDIVEN",
      "proveedor_sugerido": "Ethon",
      "precio_actual": 10000,
      "precio_sugerido": 9500,
      "ahorro_por_unidad": 500,
      "porcentaje_ahorro": 5,
      "prioridad": "alta",
      "razon": "Ethon es consistentemente más barato (100% competitivo)"
    }
  ],
  "ahorro_potencial_total": 450000,
  "resumen": "Cambiar a Ethon en 15 productos puede generar $450,000 de ahorro mensual"
}
```

---

## 🔬 Validación Técnica

### **Verificar que usa datos reales:**

```bash
# Terminal 1: Iniciar servidor
npm run dev

# Terminal 2: Ejecutar script de validación
node validate-ai-providers-data.js
```

### **Script muestra:**

- ✅ Cantidad de productos reales
- ✅ Cantidad de proveedores reales
- ✅ Precios reales de la base de datos
- ✅ Cálculos de diferencias
- ✅ Ejemplo de prompt enviado a IA
- ✅ Estructura de datos completa

---

## 🎯 Garantía de Datos Reales

### **Evidencia 1: Consulta a Supabase**

```typescript
// src/app/api/compare-prices/route.ts (línea 31)
const { data: priceRows, error: pricesError } = await supabase
  .from("provider_prices") // ← Tabla real
  .select("price, products (id, name, ean), providers (id, name)")
  .order("products(name)"); // ← JOIN real
```

### **Evidencia 2: Transformación de Datos**

```typescript
// src/app/api/providers/ai-analysis/route.ts (línea 43)
const productos = data.productsData.map(
  (product: {
    productId: string; // ← ID real de la base de datos
    productName: string; // ← Nombre real del producto
    prices: Record<string, number>; // ← Precios reales de proveedores
  }) => {
    // ... cálculos con datos reales
  }
);
```

### **Evidencia 3: No hay datos hardcodeados**

```typescript
// ❌ NO HAY ESTO:
const productos = [
  { nombre: "Producto A", precio: 1000 },  // Hardcoded
  { nombre: "Producto B", precio: 2000 }   // Hardcoded
];

// ✅ SÍ HAY ESTO:
const response = await fetch('/api/compare-prices');  // Consulta real
const data = await response.json();                   // Datos reales
const productos = data.productsData.map(...);        // Procesamiento real
```

---

## 📊 Estadísticas de Datos

### **Origen de los datos:**

| Dato        | Fuente                             | Tipo                      |
| ----------- | ---------------------------------- | ------------------------- |
| Productos   | `products` table (Supabase)        | Real                      |
| Proveedores | `providers` table (Supabase)       | Real                      |
| Precios     | `provider_prices` table (Supabase) | Real                      |
| Cálculos    | API `/api/providers/ai-analysis`   | Procesado en tiempo real  |
| Insights    | Groq IA (LLaMA 3.3)                | Generado con datos reales |

### **Flujo temporal:**

1. **Usuario sube Excel** → Se guarda en `provider_prices`
2. **Usuario solicita análisis** → API consulta `provider_prices`
3. **API procesa datos** → Cálculos en memoria
4. **API llama Groq** → Envía datos reales
5. **IA genera insights** → Basados en datos reales
6. **Usuario ve resultados** → Datos 100% actualizados

---

## ✅ Conclusión

### **El sistema de IA usa:**

✅ Datos REALES de Supabase  
✅ Precios ACTUALIZADOS de proveedores  
✅ Productos REALES del catálogo  
✅ Cálculos en TIEMPO REAL  
✅ Insights PERSONALIZADOS por IA

### **El sistema NO usa:**

❌ Datos simulados o de prueba  
❌ Precios hardcodeados  
❌ Respuestas pre-generadas  
❌ Datos estáticos

---

## 🔍 Para Verificar Manualmente

1. **Abrir Supabase Dashboard**

   - Ve a tu proyecto en Supabase
   - Tabla `provider_prices`
   - Verás los mismos productos y precios

2. **Probar endpoint directamente**

   ```bash
   curl http://localhost:3000/api/compare-prices
   ```

3. **Ejecutar script de validación**

   ```bash
   node validate-ai-providers-data.js
   ```

4. **Ver logs en consola**
   - Al hacer análisis verás: "Obtenidos X productos"
   - Los X coinciden con tu base de datos

---

**¿Dudas? Ejecuta el script de validación para ver los datos en acción.** 🚀
