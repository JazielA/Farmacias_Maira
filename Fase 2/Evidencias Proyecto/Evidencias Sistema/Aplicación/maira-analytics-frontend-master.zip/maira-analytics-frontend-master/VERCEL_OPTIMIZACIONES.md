# 🚀 Optimizaciones para Deploy en Vercel

## ✅ Cambios Realizados para Compatibilidad con Vercel

### 1. **Hook `useUserStatus` Optimizado**

**Mejoras implementadas:**
- ✅ Uso de `useRef` para prevenir memory leaks
- ✅ Verificación de componente montado antes de actualizar estado
- ✅ Limpieza adecuada del intervalo en unmount
- ✅ Intervalo aumentado a 60 segundos (de 30) para reducir requests
- ✅ Headers de `cache: 'no-store'` para evitar cache en Vercel
- ✅ Verificaciones de `isMountedRef.current` antes de cada setState

**Beneficios:**
- No hay memory leaks
- Menos requests al servidor
- Compatible con Vercel Edge Network
- Maneja correctamente el desmontaje del componente

---

### 2. **API Routes con Runtime Explícito**

**Endpoints actualizados:**

#### `/api/user/check-status`
```typescript
export const runtime = 'nodejs'      // Usar Node.js (Prisma requiere esto)
export const dynamic = 'force-dynamic' // No cachear
export const revalidate = 0          // Sin revalidación
```

#### `/api/admin/users/[userId]/toggle-status`
```typescript
export const runtime = 'nodejs'      // Usar Node.js
export const dynamic = 'force-dynamic' // No cachear
```

**Por qué es importante:**
- Prisma requiere Node.js runtime (no funciona en Edge)
- `force-dynamic` evita que Vercel cachee las respuestas
- Garantiza que siempre se consulte el estado actual del usuario

---

### 3. **Middleware Simplificado**

**Ventajas para Vercel:**
- ✅ No hace fetches internos (más rápido)
- ✅ Solo verificación de autenticación básica
- ✅ Compatible con Edge Runtime
- ✅ Mínima latencia

**Nota:** La verificación del estado del usuario se hace en:
1. Login (AuthContext)
2. Dashboard Layout (useUserStatus hook)

---

## 🔧 Variables de Entorno Requeridas

Asegúrate de tener configuradas en Vercel:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_service_role_key

# Database
DATABASE_URL="postgresql://..."
DIRECT_URL="postgresql://..."
```

---

## 📊 Consideraciones de Performance en Vercel

### Request Frequency
- **Antes:** Verificación cada 30 segundos = 120 requests/hora por usuario
- **Ahora:** Verificación cada 60 segundos = 60 requests/hora por usuario
- **Impacto:** 50% menos requests, mejor para los límites de Vercel

### Cold Starts
El endpoint `/api/user/check-status` puede tener cold starts en Vercel Free Tier:
- Primera request: ~1-2 segundos
- Requests subsecuentes: ~100-300ms

**Solución:** El hook maneja esto con timeout y no bloquea la UI.

---

## 🐛 Posibles Problemas y Soluciones

### Problema 1: "Function Execution Timeout"
**Causa:** Prisma queries muy lentas
**Solución:**
```typescript
// Agregar timeout a la query
const dbUser = await Promise.race([
  prisma.user.findUnique({
    where: { id: user.id },
    select: { isActive: true }
  }),
  new Promise((_, reject) => 
    setTimeout(() => reject(new Error('Query timeout')), 5000)
  )
])
```

### Problema 2: "Too Many Requests"
**Causa:** Muchos usuarios verificando simultáneamente
**Solución implementada:**
- Intervalo de 60 segundos
- Cache en el cliente para evitar requests duplicados
- Headers de no-cache solo cuando es necesario

### Problema 3: "Prisma Client Not Found"
**Causa:** Cliente de Prisma no generado en build
**Solución:**
```json
// package.json
{
  "scripts": {
    "postinstall": "prisma generate",
    "build": "prisma generate && next build"
  }
}
```

---

## 🎯 Checklist de Deploy

Antes de hacer deploy a Vercel:

- [ ] Variables de entorno configuradas
- [ ] `prisma generate` en postinstall
- [ ] Runtime configurado en API routes con Prisma
- [ ] Conexión pooling configurada en DATABASE_URL
- [ ] DIRECT_URL configurada para migraciones
- [ ] Límites de funciones serverless considerados

---

## 📈 Monitoreo en Vercel

Para monitorear el sistema en producción:

### 1. **Vercel Analytics**
Revisa:
- Function invocations de `/api/user/check-status`
- Duración promedio de ejecución
- Errores y timeouts

### 2. **Logs en Vercel**
```bash
# Ver logs en tiempo real
vercel logs --follow

# Filtrar por endpoint específico
vercel logs --follow | grep "check-status"
```

### 3. **Supabase Logs**
En Supabase Dashboard → Logs:
- Consultas a tabla `users`
- Queries lentas
- Conexiones activas

---

## 🔐 Seguridad en Vercel

### Rate Limiting (Recomendado)
Para evitar abuse del endpoint de verificación:

```typescript
// Implementar en una próxima iteración
import { Ratelimit } from '@upstash/ratelimit'
import { Redis } from '@upstash/redis'

const ratelimit = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(10, '60 s'), // 10 requests por minuto
})
```

### Headers de Seguridad
Vercel automáticamente agrega:
- CORS headers
- Security headers
- HTTPS redirect

---

## 🚀 Performance Tips

### 1. **Connection Pooling**
Ya configurado en tu `.env`:
```
DATABASE_URL="postgresql://...pooler.supabase.com:5432/..."
```

### 2. **Prisma Optimization**
```typescript
// Solo seleccionar campos necesarios
select: { isActive: true }  // ✅ Correcto
// vs
// Sin select                 // ❌ Trae todos los campos
```

### 3. **Client-Side Caching**
```typescript
// En useUserStatus, podríamos agregar:
const lastCheck = useRef(Date.now())
if (Date.now() - lastCheck.current < 60000) {
  return // Skip check si fue hace menos de 60s
}
```

---

## ✅ Resultado Final

Con estas optimizaciones:
- ✅ Compatible con Vercel Edge Network
- ✅ Sin memory leaks
- ✅ Performance óptimo
- ✅ Manejo correcto de cold starts
- ✅ Reducción del 50% en requests
- ✅ Funciona en Vercel Free Tier

---

## 📚 Referencias

- [Next.js Runtime Config](https://nextjs.org/docs/app/api-reference/file-conventions/route-segment-config)
- [Prisma with Vercel](https://www.prisma.io/docs/guides/deployment/deployment-guides/deploying-to-vercel)
- [Vercel Functions](https://vercel.com/docs/functions)
- [Supabase with Vercel](https://supabase.com/docs/guides/getting-started/quickstarts/nextjs)
