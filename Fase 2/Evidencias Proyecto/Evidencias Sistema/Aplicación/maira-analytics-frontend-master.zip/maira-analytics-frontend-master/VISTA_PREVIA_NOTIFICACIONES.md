# 🎨 Vista Previa del Sistema de Notificaciones

## Componentes Visuales

### 1. Campana en el Header (Estado Sin Notificaciones)

```
┌─────────────────────────────────────────────────────────────────┐
│ Maira Analytics                                    🔔  👤 Admin │
│ Supervisión inteligente para cadenas farmacéuticas              │
└─────────────────────────────────────────────────────────────────┘
```

### 2. Campana con Notificaciones

```
┌─────────────────────────────────────────────────────────────────┐
│ Maira Analytics                              🔔 [3]  👤 Admin   │
│ Supervisión inteligente...                    ↑                 │
│                                              Badge               │
└─────────────────────────────────────────────────────────────────┘
```

### 3. Dropdown Abierto (Mockup ASCII)

```
                                  ┌──────────────────────────────────────┐
                                  │ Catálogos Desactualizados      🔄    │
                                  │ Proveedores con más de 7 días       │
                                  ├──────────────────────────────────────┤
                                  │                                      │
                                  │ 📦  Farmacias Cruz Verde        13d  │
                                  │     Podría tener precios             │
                                  │     actualizados disponibles         │
                                  │     📅 Registrado hace 13 días       │
                                  │                                      │
                                  ├──────────────────────────────────────┤
                                  │                                      │
                                  │ 📦  Salcobrand                   8d  │
                                  │     Podría tener precios             │
                                  │     actualizados disponibles         │
                                  │     📅 Registrado hace 8 días        │
                                  │                                      │
                                  ├──────────────────────────────────────┤
                                  │                                      │
                                  │ 📦  Farmacias Ahumada           10d  │
                                  │     Podría tener precios             │
                                  │     actualizados disponibles         │
                                  │     📅 Registrado hace 10 días       │
                                  │                                      │
                                  ├──────────────────────────────────────┤
                                  │   [Ver todos los proveedores]        │
                                  └──────────────────────────────────────┘
```

## Estados del Sistema

### 🔴 Estado: Con Notificaciones

- **Campana**: Color naranja (text-orange-500)
- **Badge**: Rojo pulsante con número
- **Dropdown**: Lista de proveedores con detalles

### ⚪ Estado: Sin Notificaciones

- **Campana**: Color gris (text-gray-600)
- **Sin badge**
- **Dropdown**: Mensaje "Todo al día 🎉"

### 🔄 Estado: Cargando

- **Spinner**: Animación circular azul
- **Mensaje**: "Cargando..."

### ❌ Estado: Error

- **Mensaje de error**: En rojo
- **Botón**: "Reintentar"

## Colores del Sistema

### Light Mode

- Campana normal: `text-gray-600`
- Campana con notificaciones: `text-orange-500`
- Badge: `bg-red-500 text-white`
- Dropdown background: `bg-white`
- Border: `border-gray-200`

### Dark Mode

- Campana normal: `text-gray-400`
- Campana con notificaciones: `text-orange-400`
- Badge: `bg-red-500 text-white` (igual)
- Dropdown background: `bg-gray-800`
- Border: `border-gray-700`

## Animaciones

### Badge Pulsante

```css
@keyframes pulse {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.5;
  }
}
```

### Spinner de Refresh

```css
@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
```

## Interacciones

### Click en Campana

1. Abre/cierra el dropdown
2. Carga datos si es la primera vez
3. Focus visual con ring azul

### Click en Notificación

1. Navega a `/dashboard/suppliers`
2. Cierra el dropdown
3. Hover effect (bg-gray-50)

### Click en "Ver todos"

1. Navega a `/dashboard/suppliers`
2. Cierra el dropdown

### Click fuera

1. Cierra el dropdown automáticamente
2. Sin animación brusca

### Botón Refresh

1. Recarga datos manualmente
2. Muestra spinner durante carga
3. Se deshabilita mientras carga

## Responsividad

### Desktop (≥ 1024px)

- Dropdown: 384px de ancho (w-96)
- Posición: Alineado a la derecha
- Sin scroll en lista corta

### Tablet (768px - 1023px)

- Dropdown: 320px de ancho
- Ajuste automático de posición
- Scroll si hay muchos items

### Mobile (< 768px)

- Dropdown: Ancho completo menos márgenes
- Posición: Centrado
- Lista scrolleable

## Ejemplo de Código para Testing Manual

### En el navegador (DevTools Console):

```javascript
// Simular click en la campana
document.querySelector('button[title*="proveedor"]').click();

// Ver datos en el estado
// (Requiere React DevTools)

// Forzar actualización
// Click en el botón de refresh en el dropdown
```

### Verificar en Network Tab:

```
GET /api/providers/outdated
Status: 200 OK
Response:
{
  "success": true,
  "providers": [...],
  "total": 3
}
```

## Checklist de Testing Visual

- [ ] Badge aparece cuando hay notificaciones (> 7 días)
- [ ] Badge muestra número correcto (máx. 9+)
- [ ] Badge tiene animación de pulso
- [ ] Campana cambia de color (gris → naranja)
- [ ] Dropdown se abre al hacer click
- [ ] Dropdown se cierra al hacer click fuera
- [ ] Lista muestra todos los proveedores desactualizados
- [ ] Cada item muestra: nombre, mensaje, fecha, badge de días
- [ ] Click en item navega a /dashboard/suppliers
- [ ] Botón refresh funciona y muestra spinner
- [ ] Estado de carga muestra spinner
- [ ] Estado de error muestra mensaje y botón reintentar
- [ ] Estado vacío muestra "Todo al día"
- [ ] Dark mode se ve correctamente
- [ ] Responsivo en móvil/tablet/desktop
- [ ] Auto-refresh funciona cada 5 minutos

## Screenshots Recomendados

Para documentación completa, toma screenshots de:

1. **Campana sin notificaciones** (estado normal)
2. **Campana con badge** (3+ notificaciones)
3. **Dropdown abierto con lista** (vista completa)
4. **Estado de carga** (spinner)
5. **Estado vacío** ("Todo al día")
6. **Dark mode** (todos los estados)
7. **Mobile view** (dropdown responsive)

## Mejoras Visuales Futuras

- [ ] Agregar iconos de proveedor personalizados
- [ ] Animación slide-in para el dropdown
- [ ] Efecto haptic en móviles al abrir
- [ ] Sonido opcional al recibir notificación
- [ ] Gradiente en el badge
- [ ] Skeleton loading más sofisticado
- [ ] Transiciones más suaves
- [ ] Micro-interacciones en hover
