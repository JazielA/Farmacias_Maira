import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: false, // Desactivar para evitar doble renders en desarrollo
  /* config options here */
};

export default nextConfig;
