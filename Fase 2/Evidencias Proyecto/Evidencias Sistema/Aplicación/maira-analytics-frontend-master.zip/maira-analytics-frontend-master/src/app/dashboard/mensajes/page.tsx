"use client";

import { useState } from 'react'
import { MessageComposer } from '@/components/messages/MessageComposer'
import { MessageList } from '@/components/messages/MessageList'

export default function MensajesPage() {
    const [refreshKey, setRefreshKey] = useState(0)

    const handleSent = () => {
        // Forzar re-render de la lista de mensajes
        setRefreshKey(prev => prev + 1)
    }

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-2xl font-bold text-[var(--foreground)] mb-2">Mensajería Interna</h1>
                <p className="text-[var(--text-subtle)]">Envía y gestiona mensajes con otros usuarios del sistema</p>
            </div>
            
            <MessageComposer onSent={handleSent} />
            
            <MessageList key={refreshKey} mailbox="inbox" />
        </div>
    )
}


