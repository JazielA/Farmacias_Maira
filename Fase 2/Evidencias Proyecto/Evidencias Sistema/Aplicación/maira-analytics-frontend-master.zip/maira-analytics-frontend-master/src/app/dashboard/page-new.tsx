"use client";

import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { PermissionsProvider } from "@/contexts/PermissionsContext";
import Sidebar from "@/components/Sidebar";

interface DashboardStats {
  totalUsers: number;
  totalPosts: number;
  publishedPosts: number;
  draftPosts: number;
  userPosts: number;
  recentActivity: Array<{
    id: string;
    title: string;
    author: string;
    createdAt: string;
    published: boolean;
  }>;
  metrics: {
    engagementRate: number;
    growthRate: number;
    satisfaction: number;
  };
}

export default function Dashboard() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [stats, setStats] = useState<DashboardStats | null>(null);

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
      return;
    }

    const fetchStats = async () => {
      if (!user) return;

      try {
        const response = await fetch("/api/dashboard");
        if (response.ok) {
          const data = await response.json();
          setStats(data);
        }
      } catch (error) {
        console.error("Error fetching dashboard stats:", error);
        setStats({
          totalUsers: 1,
          totalPosts: 0,
          publishedPosts: 0,
          draftPosts: 0,
          userPosts: 0,
          recentActivity: [],
          metrics: {
            engagementRate: 85,
            growthRate: 12,
            satisfaction: 92,
          },
        });
      } finally {
        // Stats loaded
      }
    };

    if (user) {
      fetchStats();
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-lg">Cargando...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const statCards = [
    {
      name: "Total de Usuarios",
      value: stats?.totalUsers || 0,
      icon: "👥",
      color: "bg-blue-500",
      description: "Usuarios registrados",
    },
    {
      name: "Posts Totales",
      value: stats?.totalPosts || 0,
      icon: "📄",
      color: "bg-green-500",
      description: "Contenido creado",
    },
    {
      name: "Posts Publicados",
      value: stats?.publishedPosts || 0,
      icon: "✅",
      color: "bg-yellow-500",
      description: "Contenido activo",
    },
    {
      name: "Mis Posts",
      value: stats?.userPosts || 0,
      icon: "✍️",
      color: "bg-purple-500",
      description: "Tu contenido",
    },
  ];

  return (
    <PermissionsProvider>
      <div className="flex h-screen bg-gray-100">
        <Sidebar />

        <div className="flex-1 flex flex-col overflow-hidden">
          <main className="flex-1 overflow-y-auto">
            <div className="p-6 space-y-6">
              <div className="bg-white rounded-lg shadow p-6">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  Dashboard con Prisma
                </h1>
                <p className="text-gray-600">
                  Panel de control con datos reales desde PostgreSQL usando
                  Prisma ORM.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {statCards.map((stat) => (
                  <div
                    key={stat.name}
                    className="bg-white rounded-lg shadow p-6 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex items-center">
                      <div
                        className={`flex-shrink-0 w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center text-white text-xl`}
                      >
                        {stat.icon}
                      </div>
                      <div className="ml-4">
                        <p className="text-sm font-medium text-gray-600">
                          {stat.name}
                        </p>
                        <p className="text-2xl font-bold text-gray-900">
                          {typeof stat.value === "number"
                            ? stat.value.toLocaleString()
                            : stat.value}
                        </p>
                        <p className="text-xs text-gray-500">
                          {stat.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="bg-white rounded-lg shadow p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">
                  Información de Usuario (Supabase + Prisma)
                </h2>
                <div className="bg-gray-50 rounded-md p-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Email (Supabase)
                      </label>
                      <p className="mt-1 text-sm text-gray-900">{user.email}</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        ID de Usuario
                      </label>
                      <p className="mt-1 text-sm text-gray-900 font-mono">
                        {user.id}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Última Conexión
                      </label>
                      <p className="mt-1 text-sm text-gray-900">
                        {user.last_sign_in_at
                          ? new Date(user.last_sign_in_at).toLocaleString()
                          : "N/A"}
                      </p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Estado
                      </label>
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Conectado con Prisma
                      </span>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-indigo-50 rounded-md">
                    <h3 className="text-sm font-medium text-indigo-900 mb-2">
                      🔗 Integración Prisma + Supabase
                    </h3>
                    <ul className="text-xs text-indigo-700 space-y-1">
                      <li>✅ Autenticación manejada por Supabase Auth</li>
                      <li>✅ Datos de aplicación manejados por Prisma ORM</li>
                      <li>✅ Base de datos PostgreSQL compartida</li>
                      <li>✅ Tipos TypeScript generados automáticamente</li>
                      <li>✅ Sincronización automática de usuarios</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </PermissionsProvider>
  );
}
