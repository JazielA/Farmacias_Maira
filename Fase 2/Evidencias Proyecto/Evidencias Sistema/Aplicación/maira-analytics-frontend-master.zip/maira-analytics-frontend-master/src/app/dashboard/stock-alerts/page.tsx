import StockAlerts from "@/components/products/StockAlerts";

export default function StockAlertsPage() {
  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900">
      <main className="flex-1 overflow-y-auto p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
              Control de Stock
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              Configura alertas de stock mínimo por sucursal
            </p>
          </div>
          <StockAlerts />
        </div>
      </main>
    </div>
  );
}
