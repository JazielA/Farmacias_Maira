"use client";

import { useEffect, useState, useCallback } from "react";

interface DashboardData {
  test: string;
}

export default function SimpleTest() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [fetchCount, setFetchCount] = useState(0);

  const fetchData = useCallback(async () => {
    setFetchCount((prev) => prev + 1);
    console.log(`🔍 Fetch #${fetchCount + 1}`);

    try {
      setLoading(true);
      // Simular API call
      await new Promise((resolve) => setTimeout(resolve, 1000));
      setData({ test: `Datos ${Date.now()}` });
    } finally {
      setLoading(false);
    }
  }, [fetchCount]);

  useEffect(() => {
    console.log("🚀 useEffect ejecutado");
    fetchData();
  }, [fetchData]);

  return (
    <div className="p-6">
      <h1>Test Simple</h1>
      <p>Fetches: {fetchCount}</p>
      {loading ? <p>Cargando...</p> : <p>Datos: {data?.test}</p>}
      <button
        onClick={fetchData}
        className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
      >
        Refetch Manual
      </button>
    </div>
  );
}
