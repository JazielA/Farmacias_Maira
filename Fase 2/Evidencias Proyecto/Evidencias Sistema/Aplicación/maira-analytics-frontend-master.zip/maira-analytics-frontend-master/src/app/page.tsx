"use client";

import { useAuth } from "@/contexts/AuthContext";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { PermissionsProvider } from "@/contexts/PermissionsContext";
import Sidebar from "@/components/Sidebar";
import DashboardHeader from "@/components/DashboardHeader";
import QuickActions from "@/components/home/QuickActions";
import StatsOverview from "@/components/home/StatsOverview";
import NotificationWidget from "@/components/home/NotificationWidget";
import RecentActivity from "@/components/home/RecentActivity";
import QuickLinks from "@/components/home/QuickLinks";

export default function Home() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) {
      router.push("/login");
    }
  }, [user, loading, router]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <div className="text-lg text-gray-700 dark:text-gray-300">Cargando...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <PermissionsProvider>
      <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
        {/* Sidebar */}
        <Sidebar />
        
        {/* Main Content */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Header */}
          <DashboardHeader />
          
          {/* Main content area */}
          <main className="flex-1 overflow-auto p-6">
            <div className="max-w-7xl mx-auto space-y-6">
              {/* Stats Overview */}
              <StatsOverview />

              {/* Quick Actions */}
              <QuickActions />

              {/* Two Column Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Notifications */}
                <NotificationWidget />

                {/* Quick Links */}
                <QuickLinks />
              </div>

              {/* Recent Activity */}
              <RecentActivity />

              {/* Info Footer */}
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-lg p-6 border border-blue-200 dark:border-blue-800">
                <div className="flex items-start gap-4">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      Consejo del Día
                    </h3>
                    <p className="text-gray-700 dark:text-gray-300">
                      Utiliza el comparador de precios para identificar los mejores proveedores. 
                      Configura alertas automáticas cuando el stock sea bajo para evitar desabastecimientos.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </main>
        </div>
      </div>
    </PermissionsProvider>
  );
}
