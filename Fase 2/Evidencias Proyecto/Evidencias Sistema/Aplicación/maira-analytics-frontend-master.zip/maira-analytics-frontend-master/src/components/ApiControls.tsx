"use client";

import { RefreshCcw } from "lucide-react";

interface ApiControlsProps {
  onSyncData: () => void;
  isLoading: boolean;
  className?: string;
}

export default function ApiControls({
  onSyncData,
  isLoading,
  className,
}: Readonly<ApiControlsProps>) {
  return (
    <div
      className={`flex items-center gap-4 rounded-lg border border-blue-100 bg-blue-50 px-4 py-3 text-sm shadow-sm dark:border-blue-500/40 dark:bg-blue-500/10 ${
        className ?? ""
      }`}
    >
      <div className="flex items-center gap-2">
        <span className="text-sm font-medium text-gray-700 dark:text-slate-200">
          🟢 Datos en tiempo real desde Supabase
        </span>
      </div>

      <button
        onClick={onSyncData}
        disabled={isLoading}
        className={`inline-flex items-center gap-2 rounded-lg border border-blue-600 bg-blue-600 text-white px-4 py-2 font-medium transition-colors hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
          isLoading ? "cursor-not-allowed opacity-60" : ""
        }`}
      >
        {isLoading ? (
          <>
            <div className="h-4 w-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
            Sincronizando...
          </>
        ) : (
          <>
            <RefreshCcw className="h-4 w-4" />
            Sincronizar datos
          </>
        )}
      </button>
    </div>
  );
}
