'use client'

import { useState, useEffect } from 'react'

interface CacheStats {
  size: number
  maxSize: number
  hitRatio: string
  remainingTTL: string
}

interface CacheStatsResponse {
  success: boolean
  stats: CacheStats
  timestamp: string
}

export default function CacheStatsWidget() {
  const [stats, setStats] = useState<CacheStats | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [lastRefresh, setLastRefresh] = useState<string>('')

  const fetchStats = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/admin/cache')
      
      if (!response.ok) {
        throw new Error('Error al obtener estadísticas del caché')
      }

      const data: CacheStatsResponse = await response.json()
      setStats(data.stats)
      setLastRefresh(data.timestamp)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    } finally {
      setLoading(false)
    }
  }

  const clearCache = async (email?: string) => {
    try {
      setLoading(true)
      const url = email ? `/api/admin/cache?email=${encodeURIComponent(email)}` : '/api/admin/cache'
      const response = await fetch(url, { method: 'DELETE' })
      
      if (!response.ok) {
        throw new Error('Error al limpiar caché')
      }

      const data = await response.json()
      console.log(data.message)
      
      // Refrescar estadísticas después de limpiar
      await fetchStats()
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido')
    }
  }

  useEffect(() => {
    fetchStats()
    // Refrescar cada 30 segundos
    const interval = setInterval(fetchStats, 30000)
    return () => clearInterval(interval)
  }, [])

  if (loading && !stats) {
    return (
      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-medium text-gray-900 mb-4">📊 Estadísticas del Caché</h3>
        <div className="animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-gray-900">📊 Estadísticas del Caché</h3>
        <button
          onClick={() => fetchStats()}
          disabled={loading}
          className="text-sm text-blue-600 hover:text-blue-800 disabled:opacity-50"
        >
          🔄 Actualizar
        </button>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-md">
          <p className="text-red-600 text-sm">{error}</p>
        </div>
      )}

      {stats && (
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Usuarios en Caché</p>
              <p className="text-2xl font-semibold text-gray-900">
                {stats.size} / {stats.maxSize}
              </p>
            </div>
            
            <div>
              <p className="text-sm text-gray-600">Ratio de Aciertos</p>
              <p className="text-2xl font-semibold text-green-600">
                {stats.hitRatio}
              </p>
            </div>
          </div>

          <div>
            <p className="text-sm text-gray-600">TTL Restante</p>
            <p className="text-lg font-medium text-gray-900">
              {stats.remainingTTL}
            </p>
          </div>

          {lastRefresh && (
            <p className="text-xs text-gray-500">
              Última actualización: {new Date(lastRefresh).toLocaleTimeString()}
            </p>
          )}

          <div className="flex space-x-2 pt-3 border-t">
            <button
              onClick={() => clearCache()}
              disabled={loading}
              className="px-3 py-1 text-sm bg-red-600 text-white rounded hover:bg-red-700 disabled:opacity-50"
            >
              🗑️ Limpiar Todo
            </button>
            
            <button
              onClick={() => {
                const email = prompt('Ingrese el email del usuario para limpiar su caché:')
                if (email) clearCache(email)
              }}
              disabled={loading}
              className="px-3 py-1 text-sm bg-yellow-600 text-white rounded hover:bg-yellow-700 disabled:opacity-50"
            >
              🎯 Limpiar Usuario
            </button>
          </div>

          <div className="mt-2 p-2 bg-blue-50 rounded text-xs text-blue-700">
            💡 <strong>Tip:</strong> El caché se limpia automáticamente al cerrar sesión
          </div>
        </div>
      )}
    </div>
  )
}