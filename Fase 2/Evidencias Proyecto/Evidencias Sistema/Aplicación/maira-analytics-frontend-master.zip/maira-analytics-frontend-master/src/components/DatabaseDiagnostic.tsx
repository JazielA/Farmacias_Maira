"use client";

import { useState } from "react";
import {
  AlertCircle,
  CheckCircle,
  Database,
  Loader2,
  RefreshCw,
} from "lucide-react";

interface DiagnosisResult {
  success: boolean;
  timestamp: string;
  user?: string;
  diagnosis?: {
    boletas: boolean;
    boletas_detalles: boolean;
    boletas_pagos: boolean;
  };
  connectionTest?: boolean;
  sampleData?: {
    boletas?: { data?: unknown[]; count?: number; error?: unknown };
    boletas_detalles?: { data?: unknown[]; count?: number; error?: unknown };
    boletas_pagos?: { data?: unknown[]; count?: number; error?: unknown };
  };
  summary?: {
    allTablesAvailable: boolean;
    tablesFound: number;
    totalTables: number;
    hayDatos: boolean;
  };
  dataOverview?: {
    registros: {
      boletas: number;
      boletas_detalles: number;
      boletas_pagos: number;
    };
    fechas: {
      minima: string | null;
      maxima: string | null;
      total_dias: number;
    };
    ultimas_boletas: unknown[];
  };
  error?: string;
}

export default function DatabaseDiagnostic() {
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DiagnosisResult | null>(null);

  const runDiagnostic = async () => {
    setIsLoading(true);
    setResult(null);

    try {
      const response = await fetch("/api/pharmacy/diagnose");
      const data: DiagnosisResult = await response.json();
      setResult(data);
    } catch (error) {
      setResult({
        success: false,
        timestamp: new Date().toISOString(),
        error: error instanceof Error ? error.message : "Error de conexión",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const StatusIcon = ({ status }: { status: boolean }) =>
    status ? (
      <CheckCircle className="h-5 w-5 text-green-500" />
    ) : (
      <AlertCircle className="h-5 w-5 text-red-500" />
    );

  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-6 shadow-sm">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <Database className="h-6 w-6 text-blue-600" />
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              Diagnóstico de Base de Datos
            </h3>
            <p className="text-sm text-gray-500">
              Verificar conexión con tablas de boletas
            </p>
          </div>
        </div>
        <button
          onClick={runDiagnostic}
          disabled={isLoading}
          className="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Diagnosticando...
            </>
          ) : (
            <>
              <RefreshCw className="h-4 w-4" />
              Ejecutar Diagnóstico
            </>
          )}
        </button>
      </div>

      {result && (
        <div className="space-y-4">
          <div
            className={`rounded-lg p-4 ${
              result.success
                ? "bg-green-50 border border-green-200"
                : "bg-red-50 border border-red-200"
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <StatusIcon status={result.success} />
              <span
                className={`font-medium ${
                  result.success ? "text-green-800" : "text-red-800"
                }`}
              >
                {result.success
                  ? "Diagnóstico completado"
                  : "Error en diagnóstico"}
              </span>
            </div>
            <p className="text-sm text-gray-600">
              Ejecutado: {new Date(result.timestamp).toLocaleString("es-ES")}
            </p>
            {result.user && (
              <p className="text-sm text-gray-600">Usuario: {result.user}</p>
            )}
            {result.error && (
              <p className="text-sm text-red-600 mt-2">Error: {result.error}</p>
            )}
          </div>

          {result.diagnosis && (
            <div className="rounded-lg border border-gray-200 p-4">
              <h4 className="font-medium text-gray-900 mb-3">
                Estado de las Tablas
              </h4>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tabla boletas</span>
                  <StatusIcon status={result.diagnosis.boletas} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    Tabla boletas_detalles
                  </span>
                  <StatusIcon status={result.diagnosis.boletas_detalles} />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">
                    Tabla boletas_pagos
                  </span>
                  <StatusIcon status={result.diagnosis.boletas_pagos} />
                </div>
              </div>
            </div>
          )}

          {result.summary && (
            <div
              className={`rounded-lg p-4 ${
                result.summary.allTablesAvailable && result.summary.hayDatos
                  ? "bg-green-50 border border-green-200"
                  : "bg-yellow-50 border border-yellow-200"
              }`}
            >
              <h4 className="font-medium mb-2">Resumen</h4>
              <div className="text-sm space-y-1">
                <p>
                  Tablas encontradas: {result.summary.tablesFound} de{" "}
                  {result.summary.totalTables}
                </p>
                <p>
                  Conexión disponible:{" "}
                  {result.connectionTest ? "✅ Sí" : "❌ No"}
                </p>
                <p>Hay datos: {result.summary.hayDatos ? "✅ Sí" : "❌ No"}</p>
                <p
                  className={
                    result.summary.allTablesAvailable && result.summary.hayDatos
                      ? "text-green-700"
                      : "text-yellow-700"
                  }
                >
                  {result.summary.allTablesAvailable && result.summary.hayDatos
                    ? "✅ Sistema listo para usar datos reales"
                    : result.summary.allTablesAvailable
                    ? "⚠️ Tablas disponibles pero sin datos"
                    : "⚠️ Faltan tablas o datos"}
                </p>
              </div>
            </div>
          )}

          {result.dataOverview && (
            <div className="rounded-lg border border-gray-200 p-4">
              <h4 className="font-medium text-gray-900 mb-3">
                Información de Datos
              </h4>
              <div className="space-y-3 text-sm">
                <div>
                  <div className="font-medium text-gray-700 mb-1">
                    Registros por tabla:
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div className="bg-blue-50 p-2 rounded">
                      <div className="font-semibold text-blue-800">
                        {result.dataOverview.registros.boletas.toLocaleString()}
                      </div>
                      <div className="text-xs text-blue-600">Boletas</div>
                    </div>
                    <div className="bg-green-50 p-2 rounded">
                      <div className="font-semibold text-green-800">
                        {result.dataOverview.registros.boletas_detalles.toLocaleString()}
                      </div>
                      <div className="text-xs text-green-600">Detalles</div>
                    </div>
                    <div className="bg-purple-50 p-2 rounded">
                      <div className="font-semibold text-purple-800">
                        {result.dataOverview.registros.boletas_pagos.toLocaleString()}
                      </div>
                      <div className="text-xs text-purple-600">Pagos</div>
                    </div>
                  </div>
                </div>

                {result.dataOverview.fechas.minima &&
                  result.dataOverview.fechas.maxima && (
                    <div>
                      <div className="font-medium text-gray-700 mb-1">
                        Rango de fechas disponibles:
                      </div>
                      <div className="bg-gray-50 p-2 rounded text-xs">
                        <div>
                          <strong>Desde:</strong>{" "}
                          {result.dataOverview.fechas.minima}
                        </div>
                        <div>
                          <strong>Hasta:</strong>{" "}
                          {result.dataOverview.fechas.maxima}
                        </div>
                        <div>
                          <strong>Período:</strong>{" "}
                          {result.dataOverview.fechas.total_dias} días únicos
                        </div>
                      </div>
                    </div>
                  )}

                {result.dataOverview.registros.boletas === 0 && (
                  <div className="bg-red-50 border border-red-200 p-3 rounded">
                    <div className="text-red-800 font-medium">
                      ⚠️ No hay datos en las tablas
                    </div>
                    <div className="text-red-600 text-xs mt-1">
                      Las tablas existen pero están vacías. Verifica que hayas
                      cargado datos de boletas.
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {result.sampleData && (
            <div className="rounded-lg border border-gray-200 p-4">
              <h4 className="font-medium text-gray-900 mb-3">
                Datos de Muestra
              </h4>
              <div className="space-y-3 text-sm">
                {Object.entries(result.sampleData).map(([table, data]) => (
                  <div key={table} className="border-l-4 border-blue-200 pl-3">
                    <div className="font-medium text-gray-700">{table}</div>
                    {data && typeof data === "object" && "error" in data ? (
                      <div className="text-red-600">
                        Error: {JSON.stringify(data.error)}
                      </div>
                    ) : data && typeof data === "object" && "count" in data ? (
                      <div className="text-gray-600">
                        Registros encontrados: {data.count}
                      </div>
                    ) : (
                      <div className="text-gray-500">Sin datos</div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!result && !isLoading && (
        <div className="text-center py-8 text-gray-500">
          <Database className="h-12 w-12 mx-auto mb-3 text-gray-300" />
          <p>
            Haz clic en &quot;Ejecutar Diagnóstico&quot; para verificar la
            conexión con la base de datos
          </p>
        </div>
      )}
    </div>
  );
}
