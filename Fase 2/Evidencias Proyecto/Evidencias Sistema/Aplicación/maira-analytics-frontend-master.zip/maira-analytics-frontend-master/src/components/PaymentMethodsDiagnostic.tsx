"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

interface DiagnosticData {
  totalBoletas: number;
  totalPagos: number;
  mediosPago: Array<{
    mediopago: string;
    count: number;
  }>;
  samplePagos: Array<{
    boleta_folio: string;
    mediopago: string;
    monto: number;
  }>;
}

export default function PaymentMethodsDiagnostic() {
  const [data, setData] = useState<DiagnosticData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function diagnosePaymentMethods() {
      try {
        setLoading(true);
        const supabase = createClient();

        // Contar boletas totales
        const { count: boletasCount } = await supabase
          .from('boletas')
          .select('*', { count: 'exact', head: true });

        // Contar pagos totales
        const { count: pagosCount } = await supabase
          .from('boletas_pagos')
          .select('*', { count: 'exact', head: true });

        // Obtener distribución de medios de pago
        const { data: mediosData } = await supabase
          .from('boletas_pagos')
          .select('mediopago')
          .limit(1000);

        // Contar por medio de pago
        const mediosMap = new Map<string, number>();
        mediosData?.forEach(item => {
          const medio = item.mediopago || 'Sin especificar';
          mediosMap.set(medio, (mediosMap.get(medio) || 0) + 1);
        });

        const mediosPago = Array.from(mediosMap.entries()).map(([mediopago, count]) => ({
          mediopago,
          count
        })).sort((a, b) => b.count - a.count);

        // Obtener muestra de pagos
        const { data: sampleData } = await supabase
          .from('boletas_pagos')
          .select('boleta_folio, mediopago, monto')
          .limit(10);

        setData({
          totalBoletas: boletasCount || 0,
          totalPagos: pagosCount || 0,
          mediosPago,
          samplePagos: sampleData || []
        });

      } catch (err) {
        console.error('Error en diagnóstico de pagos:', err);
        setError(err instanceof Error ? err.message : 'Error desconocido');
      } finally {
        setLoading(false);
      }
    }

    diagnosePaymentMethods();
  }, []);

  if (loading) {
    return (
      <div className="rounded-lg border border-yellow-200 bg-yellow-50 p-4">
        <div className="flex items-center gap-2">
          <div className="h-4 w-4 animate-spin rounded-full border-2 border-yellow-500 border-t-transparent"></div>
          <p className="text-sm font-medium text-yellow-800">Diagnosticando medios de pago...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-lg border border-red-200 bg-red-50 p-4">
        <p className="text-sm font-medium text-red-800">Error: {error}</p>
      </div>
    );
  }

  if (!data) return null;

  return (
    <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm">
      <h4 className="font-semibold text-blue-900 mb-3">Diagnóstico de Medios de Pago</h4>
      
      <div className="space-y-2 mb-4">
        <p><strong>Total boletas:</strong> {data.totalBoletas}</p>
        <p><strong>Total pagos:</strong> {data.totalPagos}</p>
      </div>

      {data.mediosPago.length > 0 && (
        <div className="mb-4">
          <p className="font-medium mb-2">Distribución de medios de pago:</p>
          <div className="space-y-1">
            {data.mediosPago.slice(0, 5).map(item => (
              <div key={item.mediopago} className="flex justify-between">
                <span>{item.mediopago || 'Sin especificar'}:</span>
                <span className="font-mono">{item.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {data.samplePagos.length > 0 && (
        <div>
          <p className="font-medium mb-2">Muestra de pagos:</p>
          <div className="text-xs space-y-1">
            {data.samplePagos.slice(0, 3).map((pago, index) => (
              <div key={index} className="font-mono">
                Folio: {pago.boleta_folio} | {pago.mediopago} | ${pago.monto}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}