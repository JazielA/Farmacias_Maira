'use client'

import { useState } from 'react'

interface PerformanceTestResult {
  method: string
  url: string
  duration: number
  status: number
  cached?: boolean
  error?: string
}

export default function PerformanceTestWidget() {
  const [results, setResults] = useState<PerformanceTestResult[]>([])
  const [loading, setLoading] = useState(false)

  const testApi = async (url: string, method: string = 'GET') => {
    setLoading(true)
    const startTime = performance.now()
    
    try {
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json'
        }
      })
      
      const endTime = performance.now()
      const duration = Math.round(endTime - startTime)
      
      const result: PerformanceTestResult = {
        method,
        url,
        duration,
        status: response.status,
      }

      if (method === 'GET') {
        const data = await response.json()
        result.cached = data.stats || data.permissions ? true : false
      }
      
      setResults(prev => [result, ...prev.slice(0, 9)]) // Keep last 10 results
      
    } catch (error) {
      const endTime = performance.now()
      const result: PerformanceTestResult = {
        method,
        url,
        duration: Math.round(endTime - startTime),
        status: 0,
        error: error instanceof Error ? error.message : 'Error desconocido'
      }
      
      setResults(prev => [result, ...prev.slice(0, 9)])
    } finally {
      setLoading(false)
    }
  }

  const runBenchmark = async () => {
    setResults([])
    const tests = [
      '/api/user/permissions',
      '/api/user/permissions', // Test cache hit
      '/api/admin/cache',
      '/api/admin/users',
      '/api/user/permissions', // Another cache test
    ]

    for (const url of tests) {
      await testApi(url)
      // Wait a bit between tests
      await new Promise(resolve => setTimeout(resolve, 100))
    }
  }

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <h3 className="text-lg font-medium text-gray-900 mb-4">⚡ Test de Rendimiento</h3>
      
      <div className="flex flex-wrap gap-2 mb-4">
        <button
          onClick={() => testApi('/api/user/permissions')}
          disabled={loading}
          className="px-3 py-1 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:opacity-50"
        >
          🔒 Permisos
        </button>
        
        <button
          onClick={() => testApi('/api/admin/cache')}
          disabled={loading}
          className="px-3 py-1 text-sm bg-green-600 text-white rounded hover:bg-green-700 disabled:opacity-50"
        >
          📊 Caché
        </button>
        
        <button
          onClick={runBenchmark}
          disabled={loading}
          className="px-3 py-1 text-sm bg-purple-600 text-white rounded hover:bg-purple-700 disabled:opacity-50"
        >
          🚀 Benchmark
        </button>

        <button
          onClick={() => setResults([])}
          className="px-3 py-1 text-sm bg-gray-600 text-white rounded hover:bg-gray-700"
        >
          🗑️ Limpiar
        </button>
      </div>

      {loading && (
        <div className="text-center py-2">
          <div className="inline-block animate-spin rounded-full h-4 w-4 border-b-2 border-purple-600"></div>
          <span className="ml-2 text-sm text-gray-600">Ejecutando test...</span>
        </div>
      )}

      {results.length > 0 && (
        <div className="space-y-2 max-h-64 overflow-y-auto">
          <h4 className="text-sm font-medium text-gray-700">📈 Resultados (últimos 10):</h4>
          {results.map((result, index) => (
            <div
              key={index}
              className={`p-2 rounded text-sm ${
                result.status >= 200 && result.status < 300
                  ? 'bg-green-50 border-green-200'
                  : result.error
                  ? 'bg-red-50 border-red-200'
                  : 'bg-yellow-50 border-yellow-200'
              } border`}
            >
              <div className="flex justify-between items-start">
                <div>
                  <span className="font-mono text-xs">
                    {result.method} {result.url.replace('/api/', '')}
                  </span>
                  {result.error && (
                    <div className="text-red-600 text-xs mt-1">
                      ❌ Error: {result.error}
                    </div>
                  )}
                </div>
                <div className="text-right">
                  <div className={`font-semibold ${
                    result.duration < 100 ? 'text-green-600' :
                    result.duration < 300 ? 'text-yellow-600' : 'text-red-600'
                  }`}>
                    {result.duration}ms
                  </div>
                  <div className="text-xs text-gray-500">
                    HTTP {result.status || 'ERR'}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {results.length >= 3 && (
        <div className="mt-4 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded">
          <h4 className="text-sm font-medium text-gray-700 mb-2">📊 Estadísticas de Rendimiento:</h4>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-semibold text-blue-600">
                {Math.round(results.reduce((acc, r) => acc + r.duration, 0) / results.length)}ms
              </div>
              <div className="text-xs text-gray-600">Promedio</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-green-600">
                {Math.min(...results.map(r => r.duration))}ms
              </div>
              <div className="text-xs text-gray-600">Mínimo</div>
            </div>
            <div>
              <div className="text-lg font-semibold text-orange-600">
                {Math.max(...results.map(r => r.duration))}ms
              </div>
              <div className="text-xs text-gray-600">Máximo</div>
            </div>
          </div>
          
          {results.length >= 5 && (
            <div className="mt-2 text-center">
              <div className="text-sm text-gray-600">
                ✅ Cache Hit Rate: {Math.round((results.filter(r => r.duration < 50).length / results.length) * 100)}%
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}