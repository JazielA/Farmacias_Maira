'use client';

import { useState } from 'react';
import { Bell, AlertTriangle, Info, CheckCircle, AlertCircle } from 'lucide-react';

interface Notification {
  id: string;
  type: 'info' | 'warning' | 'success' | 'alert';
  title: string;
  message: string;
  time: string;
  read: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    type: 'warning',
    title: 'Stock Bajo',
    message: '5 productos tienen stock crítico',
    time: 'Hace 10 minutos',
    read: false
  },
  {
    id: '2',
    type: 'info',
    title: 'Nuevo Proveedor',
    message: 'BioPharma Express ha actualizado precios',
    time: 'Hace 1 hora',
    read: false
  },
  {
    id: '3',
    type: 'success',
    title: 'Sincronización Completada',
    message: 'Web scraping finalizado exitosamente',
    time: 'Hace 2 horas',
    read: true
  },
  {
    id: '4',
    type: 'alert',
    title: 'Producto Agotado',
    message: 'Alcohol en Gel 500ml sin stock en 2 proveedores',
    time: 'Hace 3 horas',
    read: true
  }
];

export default function NotificationWidget() {
  const [notifications, setNotifications] = useState<Notification[]>(mockNotifications);
  const unreadCount = notifications.filter(n => !n.read).length;

  const getTypeConfig = (type: Notification['type']) => {
    switch (type) {
      case 'warning':
        return { Icon: AlertTriangle, bg: 'bg-yellow-50 dark:bg-yellow-900/20', border: 'border-yellow-200 dark:border-yellow-800', text: 'text-yellow-800 dark:text-yellow-200', iconColor: 'text-yellow-600 dark:text-yellow-400' };
      case 'info':
        return { Icon: Info, bg: 'bg-blue-50 dark:bg-blue-900/20', border: 'border-blue-200 dark:border-blue-800', text: 'text-blue-800 dark:text-blue-200', iconColor: 'text-blue-600 dark:text-blue-400' };
      case 'success':
        return { Icon: CheckCircle, bg: 'bg-green-50 dark:bg-green-900/20', border: 'border-green-200 dark:border-green-800', text: 'text-green-800 dark:text-green-200', iconColor: 'text-green-600 dark:text-green-400' };
      case 'alert':
        return { Icon: AlertCircle, bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-200 dark:border-red-800', text: 'text-red-800 dark:text-red-200', iconColor: 'text-red-600 dark:text-red-400' };
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Bell className="w-5 h-5" />
          <span>Notificaciones</span>
          {unreadCount > 0 && (
            <span className="bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
              {unreadCount}
            </span>
          )}
        </h2>
        <button className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400">
          Ver todas
        </button>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto">
        {notifications.map((notification) => {
          const config = getTypeConfig(notification.type);
          return (
            <div
              key={notification.id}
              className={`p-3 rounded-lg border ${config.bg} ${config.border} ${!notification.read ? 'border-l-4' : ''} transition-all`}
            >
              <div className="flex items-start gap-3">
                <config.Icon className={`w-6 h-6 ${config.iconColor}`} />
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <h3 className={`font-semibold ${config.text}`}>
                      {notification.title}
                    </h3>
                    {!notification.read && (
                      <button
                        onClick={() => markAsRead(notification.id)}
                        className="text-xs text-gray-500 hover:text-gray-700 dark:text-gray-400"
                      >
                        ✓
                      </button>
                    )}
                  </div>
                  <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                    {notification.message}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {notification.time}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
