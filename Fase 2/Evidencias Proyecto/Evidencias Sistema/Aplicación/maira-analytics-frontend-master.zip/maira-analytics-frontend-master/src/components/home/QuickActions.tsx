'use client';

import Link from 'next/link';
import { BarChart3, DollarSign, Users, Settings, Star, MessageCircle, TrendingUp } from 'lucide-react';

interface QuickAction {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  color: string;
  bgColor: string;
}

const quickActions: QuickAction[] = [
  {
    title: 'Dashboard',
    description: 'Análisis y métricas',
    icon: BarChart3,
    href: '/dashboard',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Ranking',
    description: 'Productos más vendidos',
    icon: Star,
    href: '/dashboard/ranking',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Proveedores',
    description: 'Comparar precios',
    icon: DollarSign,
    href: '/dashboard/proveedores',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Analytics',
    description: 'Análisis avanzado',
    icon: TrendingUp,
    href: '/dashboard/analytics',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Mensajes',
    description: 'Comunicación interna',
    icon: MessageCircle,
    href: '/dashboard/mensajes',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Usuarios',
    description: 'Administrar permisos',
    icon: Users,
    href: '/dashboard/usuarios',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  },
  {
    title: 'Configuración',
    description: 'Ajustes del sistema',
    icon: Settings,
    href: '/dashboard/configuracion',
    color: 'text-red-700',
    bgColor: 'bg-red-50 hover:bg-red-100 border-red-200 dark:bg-red-900/20 dark:hover:bg-red-900/30 dark:border-red-800'
  }
];

export default function QuickActions() {
  return (
    <div className="bg-[var(--surface)] rounded-lg shadow-md p-6 border border-[var(--border)]">
      <h2 className="text-xl font-bold text-[var(--foreground)] mb-4">
        Accesos Rápidos
      </h2>
      <div className="space-y-4">
        {/* Primera fila - 4 botones principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.slice(0, 4).map((action) => {
            const IconComponent = action.icon;
            return (
            <Link
              key={action.href}
              href={action.href}
              className={`${action.bgColor} border-2 rounded-lg p-4 transition-all hover:shadow-md hover:scale-105`}
            >
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <IconComponent className="w-10 h-10" />
                </div>
                <h3 className={`font-semibold ${action.color} mb-1`}>
                  {action.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {action.description}
                </p>
              </div>
            </Link>
          );})}
        </div>
        
        {/* Segunda fila - 3 botones centrados */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 gap-4 max-w-3xl mx-auto">
          {quickActions.slice(4).map((action) => {
            const IconComponent = action.icon;
            return (
            <Link
              key={action.href}
              href={action.href}
              className={`${action.bgColor} border-2 rounded-lg p-4 transition-all hover:shadow-md hover:scale-105`}
            >
              <div className="text-center">
                <div className="flex justify-center mb-2">
                  <IconComponent className="w-10 h-10" />
                </div>
                <h3 className={`font-semibold ${action.color} mb-1`}>
                  {action.title}
                </h3>
                <p className="text-sm text-[var(--text-subtle)]">
                  {action.description}
                </p>
              </div>
            </Link>
          );})}
        </div>
      </div>
    </div>
  );
}
