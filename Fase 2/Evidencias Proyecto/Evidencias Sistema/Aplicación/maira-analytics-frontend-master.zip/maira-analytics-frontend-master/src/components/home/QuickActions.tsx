'use client';

import Link from 'next/link';
import { BarChart3, DollarSign, Users, Settings } from 'lucide-react';

interface QuickAction {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  color: string;
  bgColor: string;
}

const quickActions: QuickAction[] = [
  {
    title: 'Ver Dashboard',
    description: 'Análisis y métricas',
    icon: BarChart3,
    href: '/dashboard',
    color: 'text-blue-700',
    bgColor: 'bg-blue-50 hover:bg-blue-100 border-blue-200'
  },
  {
    title: 'Comparar Precios',
    description: 'Productos y proveedores',
    icon: DollarSign,
    href: '/dashboard/proveedores',
    color: 'text-green-700',
    bgColor: 'bg-green-50 hover:bg-green-100 border-green-200'
  },
  {
    title: 'Gestionar Usuarios',
    description: 'Administrar permisos',
    icon: Users,
    href: '/dashboard/usuarios',
    color: 'text-purple-700',
    bgColor: 'bg-purple-50 hover:bg-purple-100 border-purple-200'
  },
  {
    title: 'Configuración',
    description: 'Ajustes del sistema',
    icon: Settings,
    href: '/dashboard/configuracion',
    color: 'text-gray-700',
    bgColor: 'bg-gray-50 hover:bg-gray-100 border-gray-200'
  }
];

export default function QuickActions() {
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
        Accesos Rápidos
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickActions.map((action) => {
          const IconComponent = action.icon;
          return (
          <Link
            key={action.href}
            href={action.href}
            className={`${action.bgColor} border-2 rounded-lg p-4 transition-all hover:shadow-md`}
          >
            <div className="text-center">
              <div className="flex justify-center mb-2">
                <IconComponent className="w-10 h-10" />
              </div>
              <h3 className={`font-semibold ${action.color} mb-1`}>
                {action.title}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {action.description}
              </p>
            </div>
          </Link>
        );})}
      </div>
    </div>
  );
}
