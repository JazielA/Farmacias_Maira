'use client';

import { RefreshCw, AlertTriangle, Edit, User, Clock } from 'lucide-react';

interface Activity {
  id: string;
  type: 'update' | 'sync' | 'alert' | 'user';
  title: string;
  description: string;
  time: string;
  user?: string;
}

const recentActivities: Activity[] = [
  {
    id: '1',
    type: 'sync',
    title: 'Sincronización de Precios',
    description: 'Actualización automática desde web scraping completada',
    time: 'Hace 15 minutos',
    user: 'Sistema'
  },
  {
    id: '2',
    type: 'alert',
    title: 'Alerta de Stock Bajo',
    description: 'Paracetamol 500mg - Stock crítico en MedSupply Pro',
    time: 'Hace 30 minutos',
    user: 'Sistema'
  },
  {
    id: '3',
    type: 'update',
    title: 'Precios Actualizados',
    description: 'BioPharma Express actualizó 3 productos',
    time: 'Hace 1 hora',
    user: 'Admin'
  },
  {
    id: '4',
    type: 'user',
    title: 'Nuevo Usuario Registrado',
    description: 'usuario@farmacia.com agregado al sistema',
    time: 'Hace 2 horas',
    user: 'Admin'
  },
  {
    id: '5',
    type: 'sync',
    title: 'Importación Excel',
    description: 'Catálogo de Farmacéutica Global importado (12 productos)',
    time: 'Hace 3 horas',
    user: 'Admin'
  },
  {
    id: '6',
    type: 'update',
    title: 'Configuración Modificada',
    description: 'Umbrales de stock actualizados',
    time: 'Hace 5 horas',
    user: 'Admin'
  }
];

export default function RecentActivity() {
  const getActivityIcon = (type: Activity['type']) => {
    switch (type) {
      case 'sync': return RefreshCw;
      case 'alert': return AlertTriangle;
      case 'update': return Edit;
      case 'user': return User;
    }
  };

  const getActivityColor = (type: Activity['type']) => {
    switch (type) {
      case 'sync': return 'text-blue-600 dark:text-blue-400';
      case 'alert': return 'text-red-600 dark:text-red-400';
      case 'update': return 'text-green-600 dark:text-green-400';
      case 'user': return 'text-purple-600 dark:text-purple-400';
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6">
      <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
        <Clock className="w-5 h-5" />
        <span>Actividad Reciente</span>
      </h2>

      <div className="space-y-4 max-h-96 overflow-y-auto">
        {recentActivities.map((activity, index) => (
          <div key={activity.id} className="relative">
            {/* Timeline line */}
            {index !== recentActivities.length - 1 && (
              <div className="absolute left-6 top-12 bottom-0 w-0.5 bg-gray-200 dark:bg-gray-700" />
            )}
            
            <div className="flex gap-3">
              {/* Icon */}
              <div className={`flex-shrink-0 w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center relative z-10`}>
                {(() => {
                  const IconComponent = getActivityIcon(activity.type);
                  return <IconComponent className="w-5 h-5 text-gray-600 dark:text-gray-300" />;
                })()}
              </div>
              
              {/* Content */}
              <div className="flex-1 pb-4">
                <div className="flex items-start justify-between">
                  <h3 className={`font-semibold ${getActivityColor(activity.type)}`}>
                    {activity.title}
                  </h3>
                  <span className="text-xs text-gray-500 dark:text-gray-400">
                    {activity.time}
                  </span>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                  {activity.description}
                </p>
                {activity.user && (
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    Por: {activity.user}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
        <button className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 font-medium">
          Ver historial completo →
        </button>
      </div>
    </div>
  );
}
