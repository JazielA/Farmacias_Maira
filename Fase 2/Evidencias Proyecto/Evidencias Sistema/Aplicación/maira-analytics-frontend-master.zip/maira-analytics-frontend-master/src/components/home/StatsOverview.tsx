'use client';

import { Package, Building2, AlertTriangle, Wallet, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface StatCard {
  title: string;
  value: string | number;
  change: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
  trending: 'up' | 'down' | 'neutral';
}

const stats: StatCard[] = [
  {
    title: 'Productos Monitoreados',
    value: '8',
    change: '+2 esta semana',
    icon: Package,
    color: 'bg-blue-500',
    trending: 'up'
  },
  {
    title: 'Proveedores Activos',
    value: '11',
    change: '+3 nuevos',
    icon: Building2,
    color: 'bg-green-500',
    trending: 'up'
  },
  {
    title: 'Alertas de Stock',
    value: '5',
    change: 'Requieren atención',
    icon: AlertTriangle,
    color: 'bg-yellow-500',
    trending: 'neutral'
  },
  {
    title: 'Ahorro Potencial',
    value: '$1,250',
    change: 'Vs. precio máx.',
    icon: Wallet,
    color: 'bg-purple-500',
    trending: 'up'
  }
];

export default function StatsOverview() {
  const getTrendIcon = (trending: StatCard['trending']) => {
    switch (trending) {
      case 'up': return <TrendingUp className="w-5 h-5 text-green-600 dark:text-green-400" />;
      case 'down': return <TrendingDown className="w-5 h-5 text-red-600 dark:text-red-400" />;
      case 'neutral': return <Minus className="w-5 h-5 text-gray-600 dark:text-gray-400" />;
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat) => {
        const IconComponent = stat.icon;
        return (
        <div
          key={stat.title}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center justify-between mb-3">
            <div className={`${stat.color} w-12 h-12 rounded-lg flex items-center justify-center text-white`}>
              <IconComponent className="w-6 h-6" />
            </div>
            {getTrendIcon(stat.trending)}
          </div>
          <h3 className="text-gray-600 dark:text-gray-400 text-sm mb-1">
            {stat.title}
          </h3>
          <p className="text-3xl font-bold text-gray-900 dark:text-white mb-1">
            {stat.value}
          </p>
          <p className="text-xs text-gray-500 dark:text-gray-400">
            {stat.change}
          </p>
        </div>
      );
      })}
    </div>
  );
}
