'use client';

import { useState } from 'react';
import { Sparkles, Loader2, TrendingUp, ShoppingCart, AlertCircle } from 'lucide-react';

interface InsightsPanelProps {
  fechaInicio: string;
  fechaFin: string;
  sucursal: string;
}

type InsightType = 'canibalización' | 'cross-sell';

export default function InsightsPanel({
  fechaInicio,
  fechaFin,
  sucursal,
}: Readonly<InsightsPanelProps>) {
  const [activeTab, setActiveTab] = useState<InsightType>('cross-sell');
  const [loading, setLoading] = useState(false);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const [insights, setInsights] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);

  const generateInsight = async (type: InsightType) => {
    setLoading(true);
    setError(null);
    setActiveTab(type);
    setInsights(null);

    try {
      const response = await fetch('/api/ranking/insights', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          insightType: type,
          fechaInicio,
          fechaFin,
          sucursal,
        }),
      });

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Error al generar insights');
      }

      setInsights(data.data.insights);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Error desconocido');
      console.error('Error:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 p-6 text-white">
        <div className="flex items-center gap-3">
          <Sparkles className="h-8 w-8" />
          <div>
            <h2 className="text-2xl font-bold">Insights Avanzados con IA</h2>
            <p className="text-blue-100 text-sm">
              Análisis profundo de tus datos de ventas
            </p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mt-6">
          <button
            onClick={() => generateInsight('cross-sell')}
            disabled={loading}
            className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'cross-sell'
                ? 'bg-white text-blue-600 shadow-lg'
                : 'bg-white/10 text-white hover:bg-white/20'
            } disabled:opacity-50`}
          >
            <ShoppingCart className="h-5 w-5 mx-auto mb-1" />
            <span className="text-sm">Venta Cruzada</span>
          </button>
          <button
            onClick={() => generateInsight('canibalización')}
            disabled={loading}
            className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
              activeTab === 'canibalización'
                ? 'bg-white text-blue-600 shadow-lg'
                : 'bg-white/10 text-white hover:bg-white/20'
            } disabled:opacity-50`}
          >
            <TrendingUp className="h-5 w-5 mx-auto mb-1" />
            <span className="text-sm">Canibalización</span>
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6 min-h-[400px]">
            {/* Loading State */}
            {loading && (
              <div className="flex flex-col items-center justify-center h-full">
                <Loader2 className="h-16 w-16 text-blue-600 animate-spin mb-4" />
                <p className="text-gray-600 dark:text-gray-400">
                  La IA está analizando miles de transacciones...
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-500 mt-2">
                  Esto puede tardar 10-30 segundos
                </p>
              </div>
            )}

            {/* Error State */}
            {error && !loading && (
              <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-6">
                <div className="flex gap-3">
                  <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-red-900 dark:text-red-100 mb-1">
                      Error al generar insights
                    </h3>
                    <p className="text-sm text-red-800 dark:text-red-200">{error}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Initial State */}
            {!loading && !insights && !error && (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <Sparkles className="h-16 w-16 text-gray-400 mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  Selecciona un tipo de análisis
                </h3>
                <p className="text-gray-600 dark:text-gray-400 max-w-md">
                  Haz clic en una de las pestañas arriba para obtener insights
                  personalizados sobre tus datos de ventas
                </p>
              </div>
            )}

            {/* Insights Content */}
            {insights && !loading && (
              <div className="space-y-6">
                {/* Resumen */}
                {insights.resumen && (
                  <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-500 p-4 rounded-r-lg">
                    <h3 className="font-semibold text-blue-900 dark:text-blue-100 mb-2 flex items-center gap-2">
                      <Sparkles className="h-5 w-5" />
                      Resumen Ejecutivo
                    </h3>
                    <p className="text-blue-800 dark:text-blue-200">{insights.resumen}</p>
                  </div>
                )}

                {/* CROSS-SELL Content */}
                {activeTab === 'cross-sell' && insights.patrones_detectados && (
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                        Patrones Detectados
                      </h3>
                      {insights.impacto_total_mensual && (
                        <div className="bg-green-100 dark:bg-green-900/30 px-4 py-2 rounded-lg">
                          <span className="text-sm text-green-800 dark:text-green-200 font-medium">
                            Impacto Total: ${insights.impacto_total_mensual.toLocaleString('es-CL')} CLP/mes
                          </span>
                        </div>
                      )}
                    </div>

                    {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                    {insights.patrones_detectados.map((patron: any, idx: number) => (
                      <div key={`patron-${idx}-${patron.nombre_patron}`} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between mb-4">
                          <div>
                            <h4 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                              {patron.nombre_patron}
                            </h4>
                            <div className="flex flex-wrap gap-3 text-sm text-gray-600 dark:text-gray-400">
                              <span>🎯 Confianza: {patron.confianza.toFixed(1)}%</span>
                              <span>📦 Comprados juntos: {patron.soporte} veces</span>
                            </div>
                          </div>
                          {patron.impacto_total && (
                            <div className="text-right">
                              <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                                +${patron.impacto_total.toLocaleString('es-CL')}
                              </div>
                              <div className="text-xs text-gray-500">CLP/mes</div>
                            </div>
                          )}
                        </div>

                        {/* Productos */}
                        <div className="mb-4 p-3 bg-gray-50 dark:bg-gray-800 rounded-lg">
                          <h5 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                            Productos:
                          </h5>
                          <div className="space-y-1">
                            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                            {patron.productos.map((prod: any, pidx: number) => (
                              <div key={`prod-${idx}-${pidx}-${prod.nombre}`} className="text-sm">
                                <span className="font-medium text-gray-900 dark:text-white">
                                  {prod.nombre}
                                </span>
                                <span className="text-gray-500 dark:text-gray-400 ml-2">
                                  ({prod.rol})
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Métricas */}
                        {patron.metricas && (
                          <div className="grid grid-cols-2 gap-4 mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">Ticket Actual</div>
                              <div className="text-lg font-bold text-gray-900 dark:text-white">
                                ${patron.metricas.ticket_promedio_actual?.toLocaleString('es-CL')}
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-gray-600 dark:text-gray-400">Ticket con Combo</div>
                              <div className="text-lg font-bold text-green-600 dark:text-green-400">
                                ${patron.metricas.ticket_con_combo?.toLocaleString('es-CL')}
                              </div>
                            </div>
                          </div>
                        )}

                        {/* Estrategias */}
                        {patron.estrategias && patron.estrategias.length > 0 && (
                          <div className="space-y-3">
                            <h5 className="text-sm font-semibold text-gray-700 dark:text-gray-300">
                              Estrategias Recomendadas:
                            </h5>
                            {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                            {patron.estrategias.map((estrategia: any, eidx: number) => (
                              <div key={`estrategia-${idx}-${eidx}-${estrategia.tipo}`} className="border-l-4 border-purple-500 pl-4 py-2">
                                <div className="flex items-center gap-2 mb-2">
                                  <span className="px-2 py-1 bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-200 text-xs font-medium rounded">
                                    {estrategia.tipo}
                                  </span>
                                  {estrategia.facilidad_implementacion && (() => {
                                    let facilidadClass = 'bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200';
                                    if (estrategia.facilidad_implementacion === 'fácil') {
                                      facilidadClass = 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200';
                                    } else if (estrategia.facilidad_implementacion === 'media') {
                                      facilidadClass = 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-800 dark:text-yellow-200';
                                    }
                                    return (
                                      <span className={`px-2 py-1 text-xs font-medium rounded ${facilidadClass}`}>
                                        {estrategia.facilidad_implementacion}
                                      </span>
                                    );
                                  })()}
                                </div>
                                <p className="text-sm text-gray-700 dark:text-gray-300 mb-2">
                                  {estrategia.descripcion}
                                </p>
                                {estrategia.ejemplo_frase && (
                                  <div className="bg-gray-100 dark:bg-gray-800 p-2 rounded italic text-sm text-gray-600 dark:text-gray-400">
                                    💬 &quot;{estrategia.ejemplo_frase}&quot;
                                  </div>
                                )}
                                {estrategia.ganancia_mensual_proyectada && (
                                  <div className="mt-2 text-sm font-semibold text-green-600 dark:text-green-400">
                                    💰 Ganancia proyectada: +${estrategia.ganancia_mensual_proyectada.toLocaleString('es-CL')}/mes
                                  </div>
                                )}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ))}

                    {/* Top Estrategias */}
                    {insights.top_estrategias && insights.top_estrategias.length > 0 && (
                      <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 border border-green-200 dark:border-green-800 rounded-lg p-6">
                        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4 flex items-center gap-2">
                          🏆 Top Estrategias por Impacto
                        </h3>
                        <div className="space-y-3">
                          {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                          {insights.top_estrategias.map((estrategia: any, idx: number) => (
                            <div key={`top-estrategia-${idx}-${estrategia.patron}`} className="flex items-center justify-between bg-white dark:bg-gray-800 p-3 rounded-lg">
                              <div className="flex-1">
                                <div className="font-semibold text-gray-900 dark:text-white">
                                  {idx + 1}. {estrategia.patron}
                                </div>
                                <div className="text-sm text-gray-600 dark:text-gray-400">
                                  {estrategia.estrategia}
                                </div>
                              </div>
                              <div className="text-right ml-4">
                                <div className="text-lg font-bold text-green-600 dark:text-green-400">
                                  +${estrategia.impacto.toLocaleString('es-CL')}
                                </div>
                                {(() => {
                                  let prioridadClass = 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-200';
                                  if (estrategia.prioridad === 'alta') {
                                    prioridadClass = 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-200';
                                  } else if (estrategia.prioridad === 'media') {
                                    prioridadClass = 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200';
                                  }
                                  return (
                                    <span className={`text-xs px-2 py-1 rounded ${prioridadClass}`}>
                                      Prioridad {estrategia.prioridad}
                                    </span>
                                  );
                                })()}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Render other insight types similarly... */}
                {/* For brevity, I'll add simplified versions */}
                
                {activeTab === 'canibalización' && insights.casos_detectados && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      Casos de Canibalización Detectados
                    </h3>
                    {/* eslint-disable-next-line @typescript-eslint/no-explicit-any */}
                    {insights.casos_detectados.map((caso: any, idx: number) => (
                      <div key={`caso-${idx}-${caso.producto_a?.nombre}-${caso.producto_b?.nombre}`} className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg p-6">
                        {/* Render canibalización details */}
                        <div className="mb-4">
                          <h4 className="font-bold text-gray-900 dark:text-white mb-2">
                            Producto A vs Producto B
                          </h4>
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <div className="text-sm text-gray-600 dark:text-gray-400">{caso.producto_a.nombre}</div>
                              <div className="text-lg font-semibold">{caso.producto_a.ventas} unidades</div>
                              <div className="text-sm">Margen: {caso.producto_a.margen.toFixed(1)}%</div>
                            </div>
                            <div>
                              <div className="text-sm text-gray-600 dark:text-gray-400">{caso.producto_b.nombre}</div>
                              <div className="text-lg font-semibold">{caso.producto_b.ventas} unidades</div>
                              <div className="text-sm">Margen: {caso.producto_b.margen.toFixed(1)}%</div>
                            </div>
                          </div>
                        </div>
                        {caso.recomendacion && (
                          <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                            <h5 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">Recomendación:</h5>
                            <p className="text-sm text-blue-800 dark:text-blue-200">{caso.recomendacion.accion}</p>
                            {caso.recomendacion.ganancia_proyectada && (
                              <div className="mt-2 font-semibold text-green-600 dark:text-green-400">
                                +${caso.recomendacion.ganancia_proyectada.toLocaleString('es-CL')}/mes
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
      </div>
    </div>
  );
}
