'use client';

import { useState } from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown, TrendingUp, TrendingDown } from 'lucide-react';

interface ProductRanking {
  ranking: number;
  codigo: string;
  nombre: string;
  unidades: number;
  ingresos: number;
  costo: number;
  margen: number;
  margenDinero: number;  // Beneficio bruto en $
  frecuencia: number;
  crecimiento: number;
}

interface RankingTableProps {
  productos: ProductRanking[];
  viewMode: string;
  loading?: boolean;
}

type SortColumn = 'ranking' | 'nombre' | 'unidades' | 'ingresos' | 'costo' | 'margen' | 'margenDinero' | 'frecuencia' | 'crecimiento';
type SortDirection = 'asc' | 'desc';

export default function RankingTable({ productos, viewMode, loading = false }: Readonly<RankingTableProps>) {
  const [sortColumn, setSortColumn] = useState<SortColumn>('ranking');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');

  const handleSort = (column: SortColumn) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const sortedProductos = [...productos].sort((a, b) => {
    const multiplier = sortDirection === 'asc' ? 1 : -1;
    
    if (sortColumn === 'nombre') {
      return multiplier * a.nombre.localeCompare(b.nombre);
    }
    
    return multiplier * (a[sortColumn] - b[sortColumn]);
  });

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('es-CL').format(num);
  };

  const formatCurrency = (num: number) => {
    return new Intl.NumberFormat('es-CL', {
      style: 'currency',
      currency: 'CLP',
      minimumFractionDigits: 0,
    }).format(num);
  };

  const SortIcon = ({ column }: { column: SortColumn }) => {
    if (sortColumn !== column) {
      return <ArrowUpDown className="ml-2 h-4 w-4 text-gray-400" />;
    }
    return sortDirection === 'asc' ? (
      <ArrowUp className="ml-2 h-4 w-4 text-blue-600" />
    ) : (
      <ArrowDown className="ml-2 h-4 w-4 text-blue-600" />
    );
  };

  const getViewModeTitle = () => {
    switch (viewMode) {
      case 'mas-vendidos':
        return 'Más Vendidos';
      case 'mayor-margen':
        return 'Mayor Margen';
      case 'frecuencia':
        return 'Mayor Frecuencia';
      case 'crecimiento':
        return 'Mayor Crecimiento';
      default:
        return 'Ranking de Productos';
    }
  };

  if (loading) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
        <div className="p-6">
          <div className="h-6 bg-gray-200 dark:bg-gray-700 rounded w-1/4 mb-4 animate-pulse"></div>
          <div className="space-y-3">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-16 bg-gray-100 dark:bg-gray-700 rounded animate-pulse"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (productos.length === 0) {
    return (
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow p-8 text-center">
        <p className="text-gray-500 dark:text-gray-400">
          No se encontraron productos para el período seleccionado
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow">
      <div className="p-6">
        <div className="mb-4">
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {getViewModeTitle()}
          </h2>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Vista detallada de productos según el criterio seleccionado
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead className="bg-gray-50 dark:bg-gray-900">
              <tr>
                <th scope="col" className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('ranking')}
                    className="flex items-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Ranking
                    <SortIcon column="ranking" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-left">
                  <button
                    onClick={() => handleSort('nombre')}
                    className="flex items-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Producto
                    <SortIcon column="nombre" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('unidades')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Unidades
                    <SortIcon column="unidades" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('costo')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Costo Total
                    <SortIcon column="costo" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('ingresos')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Ingresos
                    <SortIcon column="ingresos" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('margen')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Margen %
                    <SortIcon column="margen" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('margenDinero')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Margen $
                    <SortIcon column="margenDinero" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('frecuencia')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                    title="Cantidad de boletas en las que apareció este producto"
                  >
                    Frecuencia
                    <SortIcon column="frecuencia" />
                  </button>
                </th>
                <th scope="col" className="px-6 py-3 text-right">
                  <button
                    onClick={() => handleSort('crecimiento')}
                    className="flex items-center justify-end w-full text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider hover:text-gray-700 dark:hover:text-gray-200"
                  >
                    Crecimiento
                    <SortIcon column="crecimiento" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {sortedProductos.map((producto) => (
                <tr 
                  key={producto.codigo} 
                  className="hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors"
                >
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <div className={`flex items-center justify-center w-8 h-8 rounded-full ${
                        producto.ranking <= 3 
                          ? 'bg-yellow-100 dark:bg-yellow-900 text-yellow-800 dark:text-yellow-200' 
                          : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                      }`}>
                        <span className="text-sm font-bold">{producto.ranking}</span>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      {producto.nombre}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {producto.codigo}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900 dark:text-white font-medium">
                      {formatNumber(producto.unidades)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900 dark:text-white font-medium">
                      {formatCurrency(producto.costo)}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      inversión
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900 dark:text-white font-medium">
                      {formatCurrency(producto.ingresos)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      producto.margen > 50
                        ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                        : producto.margen > 30
                        ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
                        : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {producto.margen.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900 dark:text-white font-medium">
                      {formatCurrency(producto.margenDinero)}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      beneficio
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="text-sm text-gray-900 dark:text-white">
                      {formatNumber(producto.frecuencia)}
                    </div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      apariciones
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right">
                    <div className="flex items-center justify-end">
                      {producto.crecimiento >= 0 ? (
                        <TrendingUp className="h-4 w-4 text-green-500 mr-1" />
                      ) : (
                        <TrendingDown className="h-4 w-4 text-red-500 mr-1" />
                      )}
                      <span className={`text-sm font-medium ${
                        producto.crecimiento >= 0 ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {producto.crecimiento.toFixed(1)}%
                      </span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
