"use client";

import { ProductPrice } from "@/types/supplier";
import StockBadge from "./StockBadge";

interface PriceComparisonProps {
  readonly prices: ProductPrice[];
}

export default function PriceComparison({
  prices,
}: Readonly<PriceComparisonProps>) {
  const sortedPrices = [...prices].sort((a, b) => a.price - b.price);
  const lowestPrice = sortedPrices[0];
  const hasMultipleSuppliers = prices.length > 1;

  const calculateSavings = (price: number) => {
    if (!lowestPrice || price === lowestPrice.price) return null;
    const savings = price - lowestPrice.price;
    const percentage = ((savings / price) * 100).toFixed(1);
    return { amount: savings, percentage };
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
          Comparación de Precios
        </h3>
        {hasMultipleSuppliers && (
          <span className="text-sm text-gray-600 dark:text-gray-400">
            {prices.length} proveedores disponibles
          </span>
        )}
      </div>

      {/* Price Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sortedPrices.map((priceInfo, index) => {
          const isLowest = priceInfo.price === lowestPrice.price;
          const savings = calculateSavings(priceInfo.price);

          return (
            <div
              key={`${priceInfo.supplierId}-${index}`}
              className={`relative rounded-lg border-2 p-4 transition-all hover:shadow-lg ${
                isLowest
                  ? "border-green-500 bg-green-50 dark:bg-green-900/20"
                  : "border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800"
              }`}
            >
              {/* Best Price Badge */}
              {isLowest && (
                <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                  <span className="bg-green-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md">
                    🏆 Mejor Precio
                  </span>
                </div>
              )}

              {/* Supplier Name */}
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <h4 className="font-semibold text-gray-900 dark:text-white">
                    {priceInfo.supplierName}
                  </h4>
                </div>
              </div>

              {/* Price */}
              <div className="mb-3">
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-bold text-gray-900 dark:text-white">
                    {priceInfo.currency}
                    {priceInfo.price.toFixed(2)}
                  </span>
                  {savings && (
                    <span className="text-sm text-red-600 dark:text-red-400">
                      +{priceInfo.currency}
                      {savings.amount.toFixed(2)}
                    </span>
                  )}
                </div>
                {savings && (
                  <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                    {savings.percentage}% más caro que el mejor precio
                  </p>
                )}
              </div>

              {/* Stock */}
              <div className="mb-3">
                <StockBadge
                  stock={priceInfo.stock}
                  status={priceInfo.stockStatus}
                  showNumber={true}
                />
              </div>

              {/* Additional Info */}
              <div className="space-y-1 text-xs text-gray-600 dark:text-gray-400">
                {priceInfo.minOrderQuantity &&
                  priceInfo.minOrderQuantity > 1 && (
                    <div className="flex items-center gap-1">
                      <span>📦</span>
                      <span>Mín. {priceInfo.minOrderQuantity} unidades</span>
                    </div>
                  )}
                <div className="flex items-center gap-1">
                  <span>🕐</span>
                  <span>
                    Actualizado:{" "}
                    {new Date(priceInfo.lastChecked).toLocaleDateString(
                      "es-ES"
                    )}
                  </span>
                </div>
              </div>

              {/* Action Button */}
              {priceInfo.url && (
                <a
                  href={priceInfo.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`mt-3 w-full flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    isLowest
                      ? "bg-green-600 hover:bg-green-700 text-white"
                      : "bg-blue-600 hover:bg-blue-700 text-white"
                  }`}
                >
                  <span>Ver en Proveedor</span>
                  <span>→</span>
                </a>
              )}

              {!priceInfo.isAvailable && (
                <div className="mt-3 text-center text-sm font-medium text-red-600 dark:text-red-400">
                  No disponible actualmente
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Summary */}
      {hasMultipleSuppliers && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <span className="text-2xl">💡</span>
            <div className="flex-1">
              <h4 className="font-semibold text-blue-900 dark:text-blue-200 mb-1">
                Análisis de Ahorro
              </h4>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                Comprando en <strong>{lowestPrice.supplierName}</strong> ahorras
                hasta{" "}
                <strong>
                  {lowestPrice.currency}
                  {(
                    sortedPrices[sortedPrices.length - 1].price -
                    lowestPrice.price
                  ).toFixed(2)}
                </strong>{" "}
                por unidad comparado con el proveedor más caro.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
