"use client";

import {
  ProductFilters as IProductFilters,
  StockStatus,
} from "@/types/supplier";

interface ProductFiltersProps {
  readonly filters: IProductFilters;
  readonly onFilterChange: (filters: IProductFilters) => void;
}

export default function ProductFilters({
  filters,
  onFilterChange,
}: Readonly<ProductFiltersProps>) {
  const stockStatuses: (StockStatus | "Todos")[] = [
    "Todos",
    "high",
    "medium",
    "low",
    "out",
  ];

  const stockStatusLabels: Record<StockStatus | "Todos", string> = {
    Todos: "Todos",
    high: "✓ Stock Alto",
    medium: "⚠ Stock Medio",
    low: "⚠ Stock Bajo",
    out: "✕ Sin Stock",
  };

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 mb-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Búsqueda */}
        <div className="lg:col-span-2">
          <label
            htmlFor="search"
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            Buscar Producto
          </label>
          <input
            id="search"
            type="text"
            placeholder="Nombre del producto, SKU, código de barras..."
            value={filters.search}
            onChange={(e) =>
              onFilterChange({ ...filters, search: e.target.value })
            }
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          />
        </div>

        {/* Estado de Stock */}
        <div>
          <label
            htmlFor="stockStatus"
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            Estado de Stock
          </label>
          <select
            id="stockStatus"
            value={filters.stockStatus}
            onChange={(e) =>
              onFilterChange({ ...filters, stockStatus: e.target.value })
            }
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          >
            {stockStatuses.map((status) => (
              <option key={status} value={status === "Todos" ? "" : status}>
                {stockStatusLabels[status]}
              </option>
            ))}
          </select>
        </div>

        {/* Precio Mínimo */}
        <div>
          <label
            htmlFor="minPrice"
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            Precio Mínimo ($)
          </label>
          <input
            id="minPrice"
            type="number"
            min="0"
            step="0.01"
            placeholder="0.00"
            value={filters.minPrice || ""}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                minPrice: Number(e.target.value) || 0,
              })
            }
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          />
        </div>

        {/* Precio Máximo */}
        <div>
          <label
            htmlFor="maxPrice"
            className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2"
          >
            Precio Máximo ($)
          </label>
          <input
            id="maxPrice"
            type="number"
            min="0"
            step="0.01"
            placeholder="Sin límite"
            value={filters.maxPrice || ""}
            onChange={(e) =>
              onFilterChange({
                ...filters,
                maxPrice: Number(e.target.value) || 0,
              })
            }
            className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
          />
        </div>
      </div>

      {/* Checkbox para múltiples proveedores */}
      <div className="mt-4 flex items-center">
        <input
          id="hasMultipleSuppliers"
          type="checkbox"
          checked={filters.hasMultipleSuppliers}
          onChange={(e) =>
            onFilterChange({
              ...filters,
              hasMultipleSuppliers: e.target.checked,
            })
          }
          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
        />
        <label
          htmlFor="hasMultipleSuppliers"
          className="ml-2 text-sm text-gray-700 dark:text-gray-300"
        >
          Mostrar solo productos con múltiples proveedores
        </label>
      </div>
    </div>
  );
}
