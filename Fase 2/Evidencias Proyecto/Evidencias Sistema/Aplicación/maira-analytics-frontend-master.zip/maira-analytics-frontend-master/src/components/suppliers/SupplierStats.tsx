"use client";

import type { ProductStats } from "@/types/supplier";

interface ProductStatsProps {
  readonly stats: ProductStats;
}

export default function ProductStats({ stats }: Readonly<ProductStatsProps>) {
  const statCards = [
    {
      title: "Total Productos",
      value: stats.totalProducts,
      icon: "📦",
      color: "bg-blue-500",
      subtext: "en catálogo",
    },
    {
      title: "Con Múltiples Proveedores",
      value: stats.productsWithMultipleSuppliers,
      icon: "🔄",
      color: "bg-purple-500",
      subtext: "comparables",
    },
    {
      title: "Alertas Stock Bajo",
      value: stats.lowStockAlerts,
      icon: "⚠️",
      color: "bg-red-500",
      subtext: "requieren atención",
    },
    {
      title: "Sin Stock",
      value: stats.outOfStockCount,
      icon: "❌",
      color: "bg-gray-500",
      subtext: "agotados",
    },
    {
      title: "Diferencia Promedio",
      value: `${stats.averagePriceDifference?.toFixed(1) ?? "0.0"}%`,
      icon: "💰",
      color: "bg-yellow-500",
      subtext: "entre precios",
    },
    {
      title: "Total Proveedores",
      value: stats.totalSuppliers,
      icon: "🏢",
      color: "bg-green-500",
      subtext: `${stats.excelSuppliers} Excel / ${stats.webScrapingSuppliers} Web`,
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
      {statCards.map((stat) => (
        <div
          key={stat.title}
          className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 hover:shadow-lg transition-shadow"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-2xl">{stat.icon}</span>
            <span
              className={`${stat.color} text-white text-xs px-2 py-1 rounded`}
            >
              {stat.subtext}
            </span>
          </div>
          <h3 className="text-gray-600 dark:text-gray-400 text-sm mb-1">
            {stat.title}
          </h3>
          <p className="text-2xl font-bold text-gray-900 dark:text-white">
            {stat.value}
          </p>
        </div>
      ))}
    </div>
  );
}
