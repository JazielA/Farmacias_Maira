// Prueba rápida del singleton
const { dashboardFetchManager } = require('./src/lib/dashboard-fetch-manager.ts');

console.log('🧪 Probando singleton...');
console.log(dashboardFetchManager);